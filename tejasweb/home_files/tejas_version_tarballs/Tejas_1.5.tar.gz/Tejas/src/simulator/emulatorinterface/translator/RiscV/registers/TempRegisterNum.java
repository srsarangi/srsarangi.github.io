package emulatorinterface.translator.RiscV.registers;

public class TempRegisterNum {
	public int numTempIntRegister = 0;
	public int numTempFloatRegister = 0;
}
