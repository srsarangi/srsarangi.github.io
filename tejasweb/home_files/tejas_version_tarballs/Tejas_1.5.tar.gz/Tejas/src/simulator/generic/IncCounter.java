package generic;

/**
 * Created by anand.j on 4/13/17.
 */
public class IncCounter extends StatCounter {

}
