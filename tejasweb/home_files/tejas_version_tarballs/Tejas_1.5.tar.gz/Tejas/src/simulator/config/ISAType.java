package config;

public enum ISAType {
    x86,
	arm,
	riscv
}
