package emulatorinterface.translator.RiscV.objparser;

public interface Values {
	    static final int OTHERS=0;
        static final int LOAD=1;
        static final int STORE=2;
        static final int BRANCH=3;
        
}
