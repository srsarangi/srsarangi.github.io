package config;

public class ISAConfig
{
	public static ISAType isatype;
}
