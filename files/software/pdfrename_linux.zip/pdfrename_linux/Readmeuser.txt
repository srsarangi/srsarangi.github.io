Instructions for user:

-->bash install3.sh

for single file:

-->pdfrename researchpapername.pdf
	 
	 -->Do you want to use the proxy:Select no or yes
	 
	 -->If yes, do you want to use the saved proxies:select yes or no
	 
	 -->if yes,renaming will  be done.
	 
	 -->If no,you need to enter the proxy ip and port(please make sure your proxy is having internet).
	 
	 -->Renaming wiil be done.

for multiple files:

-->pdfrename *.pdf
	
	-->Do you want to use the proxy:Select no or yes
	 
	 -->If yes, do you want to use the saved proxies:select yes or no
	 
	 -->if yes,renaming will  be done.
	 
	 -->If no,you need to enter the proxy ip and port(please make sure your proxy is having internet).
	 
	 -->Renaming wiil be done.
