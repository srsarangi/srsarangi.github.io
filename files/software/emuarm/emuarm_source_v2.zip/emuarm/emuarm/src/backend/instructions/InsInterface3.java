/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package backend.instructions;

/**
 *
 * @author geetika
 */
public interface InsInterface3 {
     public void execute(String token1, String token2, String token3);

}
