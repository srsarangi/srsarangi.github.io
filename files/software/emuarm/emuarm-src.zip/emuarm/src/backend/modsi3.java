/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package backend;

/**
 *
 * @author win-7
 */
public class modsi3 {

    // to find the remainder of two numbers
}
