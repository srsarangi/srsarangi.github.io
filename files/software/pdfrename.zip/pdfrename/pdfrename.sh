#!/bin/bash
jarfileaddress="/home/srsarangi/software/pdfrename/build/jar"
deletefileone=""
deletefiletwo=""
var=$http_proxy
if [ "$var" = "" ]
then
  echo "no proxy"
  if [ $# -eq 0 ]
  then
    echo "please specify the file you want to rename"
  elif [ $# -eq 1 ]
  then
     if [ "$1" = "--print" ] || [ "$1" = "-p" ] || [ "$1" = "--help" ] || [ "$1" = "-h" ] || [ "$1" = "-v" ] || [ "$1" = "--version" ]
 		 then
 		    cd $jarfileaddress
 		    java -jar rename.jar false 0 0 "$1"
      else
        intfilename="$( cd "$( dirname "$1" )" && pwd )/$1"
        dirctaddress="$( cd "$( dirname "$1" )" && pwd )"
        finalfilename="/"${intfilename#*//}""
        cd $jarfileaddress
        java -jar rename.jar false 0 0 "$finalfilename"
        deletefileone="${finalfilename%.*}-001.pdf"
        deletefiletwo="${finalfilename%.*}-002.pdf"
        rm "$deletefiletwo"
        rm "$deletefileone"
      fi
  elif [ $# -eq 2 ]
  then
    if [ "$1" = "--delete" ] || [ "$1" = "-d" ]
    then
      cd $jarfileaddress
      java -jar rename.jar false 0 0 "$1" "$2"
    elif [ "$1" = "--force" ] || [ "$1" = "-f" ] || [ "$1" = "-c" ] || [ "$1" = "--complete" ]
    then
      intfilename="$( cd "$( dirname "$2" )" && pwd )/$2"
      dirctaddress="$( cd "$( dirname "$2" )" && pwd )"
      finalfilename="/"${intfilename#*//}""
      cd $jarfileaddress
      java -jar rename.jar false 0 0 "$1" "$finalfilename"
      deletefileone="${finalfilename%.*}-001.pdf"
      deletefiletwo="${finalfilename%.*}-002.pdf"
      rm "$deletefiletwo"
      rm "$deletefileone"
    elif [ "$1" = "--all" ] || [ "$1" = "-a" ]
    then
      current="$(pwd)"
			cd "$2" #change to the directory provided (relative to the script)
			echo "'$2'" '->' "'$(pwd)'" #show new path for demo purposes
      goback="$(pwd)"
      find "$(pwd)" -maxdepth 1 -type f -exec echo "{}" >> temp.txt \;
      while IFS='' read -r line || [ -n "$line" ]; do
        cd $jarfileaddress
        java -jar rename.jar false 0 0 "$line"
        deletefileone="${line%.*}-001.pdf"
        deletefiletwo="${line%.*}-002.pdf"
        rm "$deletefiletwo"
        rm "$deletefileone"
    done < temp.txt
    cd "$goback"
    echo "$(pwd)"
    rm temp.txt
    else
      echo "improper options or parameters"
    fi
  elif [ $# -eq 3 ]
  then
    if [ "$1" = "--update" ] || [ "$1" = "-u" ]
    then
      cd $jarfileaddress
      java -jar rename.jar false 0 0 "$1" "$2" "$3"
    elif [ \( "$1" = "--all" -o "$1" = "-a" -o "$1" = "-c" -o "$1" = "--complete" \) -a \( "$2" = "--all" -o "$2" = "-a" -o "$2" = "-c" -o "$2" = "--complete" \) ]
    then
      current="$(pwd)"
			cd "$3" #change to the directory provided (relative to the script)
			echo "'$3'" '->' "'$(pwd)'" #show new path for demo purposes
      goback="$(pwd)"
      find "$(pwd)" -maxdepth 1 -type f -exec echo "{}" >> temp.txt \;
      while IFS='' read -r line || [ -n "$line" ]; do
        cd $jarfileaddress
        java -jar rename.jar false 0 0 "$1" "$line"
        deletefileone="${line%.*}-001.pdf"
        deletefiletwo="${line%.*}-002.pdf"
        rm "$deletefiletwo"
        rm "$deletefileone"
    done < temp.txt
    cd "$goback"
    echo "$(pwd)"
    rm temp.txt
  elif [ \( "$1" = "--force" -o "$1" = "-f" -o "$1" = "-c" -o "$1" = "--complete" \) -a \( "$2" = "--force" -o "$2" = "-f" -o "$2" = "-c" -o "$2" = "--complete" \) ]
  then
      intfilename="$( cd "$( dirname "$3" )" && pwd )/$3"
      dirctaddress="$( cd "$( dirname "$3" )" && pwd )"
      finalfilename="/"${intfilename#*//}""
      cd $jarfileaddress
      java -jar rename.jar false 0 0 "$1" "$2" "$finalfilename"
      deletefileone="${finalfilename%.*}-001.pdf"
      deletefiletwo="${finalfilename%.*}-002.pdf"
      rm "$deletefiletwo"
      rm "$deletefileone"
  else
    echo "Please enter proper options and parameters"
  fi
else
  echo "Please enter proper options and parameters"
fi
else
  echo "proxy detected"
  a="${var%:*}"
  b="${a#*//}"
  port="${var##*:}"
  portf="${port%/*}"
  echo $b
  echo $portf
  if [ $# -eq 0 ]
  then
    echo "please specify the file you want to rename"
  elif [ $# -eq 1 ]
  then
     if [ "$1" = "--print" ] || [ "$1" = "-p" ] || [ "$1" = "--help" ] || [ "$1" = "-h" ]
     then
        cd $jarfileaddress
        java -jar rename.jar true "$b" "$portf" "$1"
      else
        intfilename="$( cd "$( dirname "$1" )" && pwd )/$1"
        dirctaddress="$( cd "$( dirname "$1" )" && pwd )"
        finalfilename="/"${intfilename#*//}""
        cd $jarfileaddress
        java -jar rename.jar true "$b" "$portf" "$finalfilename"
        deletefileone="${finalfilename%.*}-001.pdf"
        deletefiletwo="${finalfilename%.*}-002.pdf"
        rm "$deletefiletwo"
        rm "$deletefileone"
      fi
  elif [ $# -eq 2 ]
  then
    if [ "$1" = "--delete" ] || [ "$1" = "-d" ]
    then
      cd $jarfileaddress
      java -jar rename.jar true "$b" "$portf" "$1" "$2"
    elif [ "$1" = "--force" ] || [ "$1" = "-f" ] || [ "$1" = "-c" ] || [ "$1" = "--complete" ]
    then
      intfilename="$( cd "$( dirname "$2" )" && pwd )/$2"
      dirctaddress="$( cd "$( dirname "$2" )" && pwd )"
      finalfilename="/"${intfilename#*//}""
      cd $jarfileaddress
      java -jar rename.jar true "$b" "$portf" "$1" "$finalfilename"
      deletefileone="${finalfilename%.*}-001.pdf"
      deletefiletwo="${finalfilename%.*}-002.pdf"
      rm "$deletefiletwo"
      rm "$deletefileone"
    elif [ "$1" = "--all" ] || [ "$1" = "-a" ]
    then
      current="$(pwd)"
      cd "$2" #change to the directory provided (relative to the script)
      echo "'$2'" '->' "'$(pwd)'" #show new path for demo purposes
      goback="$(pwd)"
      find "$(pwd)" -maxdepth 1 -type f -exec echo "{}" >> temp.txt \;
      while IFS='' read -r line || [ -n "$line" ]; do
        cd $jarfileaddress
        java -jar rename.jar true "$b" "$portf" "$line"
        deletefileone="${line%.*}-001.pdf"
        deletefiletwo="${line%.*}-002.pdf"
        rm "$deletefiletwo"
        rm "$deletefileone"
    done < temp.txt
    cd "$goback"
    echo "$(pwd)"
    rm temp.txt
    else
      echo "improper options or parameters"
    fi
  elif [ $# -eq 3 ]
  then
    if [ "$1" = "--update" ] || [ "$1" = "-u" ]
    then
      cd $jarfileaddress
      java -jar rename.jar true "$b" "$portf" "$1" "$2" "$3"
    elif [ \( "$1" = "--all" -o "$1" = "-a" -o "$1" = "-c" -o "$1" = "--complete" \) -a \( "$2" = "--all" -o "$2" = "-a" -o "$2" = "-c" -o "$2" = "--complete" \) ]
    then
      current="$(pwd)"
      cd "$3" #change to the directory provided (relative to the script)
      echo "'$3'" '->' "'$(pwd)'" #show new path for demo purposes
      goback="$(pwd)"
      find "$(pwd)" -maxdepth 1 -type f -exec echo "{}" >> temp.txt \;
      while IFS='' read -r line || [ -n "$line" ]; do
        cd $jarfileaddress
        java -jar rename.jar true "$b" "$portf" "$1" "$line"
        deletefileone="${line%.*}-001.pdf"
        deletefiletwo="${line%.*}-002.pdf"
        rm "$deletefiletwo"
        rm "$deletefileone"
    done < temp.txt
    cd "$goback"
    echo "$(pwd)"
    rm temp.txt
  elif [ \( "$1" = "--force" -o "$1" = "-f" -o "$1" = "-c" -o "$1" = "--complete" \) -a \( "$2" = "--force" -o "$2" = "-f" -o "$2" = "-c" -o "$2" = "--complete" \) ]
  then
      intfilename="$( cd "$( dirname "$2" )" && pwd )/$2"
      dirctaddress="$( cd "$( dirname "$2" )" && pwd )"
      finalfilename="/"${intfilename#*//}""
      cd $jarfileaddress
      java -jar rename.jar false 0 0 "$1" "$2" "$finalfilename"
      deletefileone="${finalfilename%.*}-001.pdf"
      deletefiletwo="${finalfilename%.*}-002.pdf"
      rm "$deletefiletwo"
      rm "$deletefileone"

  else
    echo "Please enter proper options and parameters"
  fi
else
  echo "Please enter proper options and parameters"
fi
fi
