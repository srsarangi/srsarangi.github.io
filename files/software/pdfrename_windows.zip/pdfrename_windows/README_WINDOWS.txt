For single file:
  --> Right click on the file.
  --> Select the "pdfrename" option from the Right click context menu.
  --> Process execution commences, and the appropriate response will be displayed upon completion.

For multiple files:
  --> Select the files that you want to rename.
  --> Right-click and then select 'sendto' from the context menu that appears.
  --> Choose 'pdfrename' from the 'sendto' options.
  --> Process execution commences, and the appropriate response will be displayed upon completion.

Note:
  --> Uninstall the application "pdfrename windows" and its registry entry. As "pdfrename" is a new application, it cannot replace its pdfrename_windows.
  --> The command "pdfrename" has been added to the Windows command line and can be executed as follows:  pdfrename file_path.