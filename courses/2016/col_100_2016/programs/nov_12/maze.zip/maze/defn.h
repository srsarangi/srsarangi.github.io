typedef struct {
	int x;
	int y;
} coord;

#define DTYPE coord
