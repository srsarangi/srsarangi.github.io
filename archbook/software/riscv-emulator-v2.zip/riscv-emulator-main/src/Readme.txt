Here source code for the RISC-V emulator (32-bit and 64-bit support) has been stored in the form of multiple files. This emulator supports following instructions:
Arithmetic: add, addw, addi, addiw, sub, subw, mul, mulw, mulh, mulhu, mulhsu, div, divw, divu, divuw, rem, remw, remu, remuw, lui
Data Transfer: sb, sh, sw, sd, lb, lbu, lh, lhu, lw, lwu, ld
Logical: and, andi, or, ori, xor, xori
Shift: sll, sllw, slli, slliw, sra, sraw, srai, sraiw, srl, srlw, srli, srliw
Conditional Branch: beq, bne, bge, blt, bgeu, bltu
Unconditional Branch: jal, jalr
Compare: slt, slti, sltu, sltiu

Floating point:
 fmv.w.x, fmv.x.w
 fadd.s, fadd.d, fadd.q
 fsub.s, fsub.d, fsub.q
 fmul.s, fmul.d, fmul.q
 fdiv.s, fdiv.d, fdiv.q
 fmin.s, fmin.d, fmin.q
 fmax.s, fmax.d, fmax.q
 fmadd.s, fmadd.d, fmadd.q
 fmsub.s, fmsub.d, fmsub.q
 flw, fsw, fld, fsd, flq, fsq
 flt.s, flt.d, flt.q
 fle.s, fle.d, fle.q
 feq.s, feq.d, feq.q
 fsgnj.s, fsgnj.d, fsgnj.q
 fsgnjn.s, fsgnjn.d, fsgnjn.q
 fsgnjx.s, fsgnjx.d, fsgnjx.q
  
 
Instructions for printing the result:
.print => For printing the integer values
.fprint.s => For printing the single precision floating point value 
.fprint.d => For printing the double precision floating point value 
.fprint.q => For printing the quad precision floating point value 
