#ifndef REGISTER_H
#define REGISTER_H
extern void invalidInst(void);
extern int dec(char ch);
extern void Stype(char* inst, int i);
extern void Rtype(char *inst, int i);
extern void Itype(char *inst, int i);
extern void ItypeL(char *inst, int i);
extern int Btype(char *inst, int i);
extern int Utype(char *inst, int i);
extern void FRtype(char *inst, int i);
extern void Fmatype(char *inst, int i);
extern void Fmvwxtype(char *inst, int i);
extern void Fmvxwtype(char *inst, int i);
extern void FRStype(char *inst, int i); // for sqrt instruction
extern void FStype(char *inst, int i); // For store instruction
extern void FCMPtype(char *inst, int i); // for floating point compare instructions
# endif
