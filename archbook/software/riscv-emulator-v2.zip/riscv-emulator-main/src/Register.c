#include<stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include"Global_Variable.h"
#include"Register.h"
void invalidInst(void)
{
	printf("The instruction in line number %d is INVALID.\n", k);
	exit(0);	// EXIT the interpreter
}
int dec(char ch)  // returns equivalent decimal value
{
	int k;
	switch(ch)
	{
		case '0': k=0;
				   break;
		case '1': k=1;
				   break;
		case '2': k=2;
				   break;
		case '3': k=3;
				   break;
		case '4': k=4;
				   break;
		case '5': k=5;
				   break;
		case '6': k=6;
				   break;
		case '7': k=7;
				   break;
		case '8': k=8;
				   break;
		case '9': k=9;
				   break;
		case 'a':
		case 'A': k=10;
				   break;
		case 'b':
		case 'B': k=11;
				   break;
		case 'c':
		case 'C': k=12;
				   break;
		case 'd':
		case 'D': k=13;
				   break;
		case 'e':
		case 'E': k=14;
				   break;
		case 'f':
		case 'F': k=15;
				   break;
		default: invalidInst();
	}
	return k;
}
void Stype(char* inst, int i)		// instruction is of the form rs1, imm[rs2]
{
	//Code to extract register number of rs1
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		x1 = 2;
		i += 2;
	}
	else
	{
		if(inst[i] != 'x')
			invalidInst();
		++i;
		if(isdigit(inst[i]))
		{
			x1 = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				x1 = x1*10 + (inst[i] - '0');
				++i;
			}
		}
		else
			invalidInst();
	}
	if(x1 < 0 || x1 > 31)
		invalidInst();


	//Code to extract register number of rs2 and value of immediate
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != ',')
		invalidInst();
	++i;
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;

	if(inst[i] == '(')		 // if we are using just register indirect mode of addressing
		imm = 0;

	else if(inst[i] == '0' && inst[i+1] == 'x')	// if we have a hexadecimal immediate
	{
		i = i + 2;
		while(inst[i] == ' ' || inst[i] == '\t')
			++i;
		if(inst[i] == '(' || inst[i] == '\0')
			invalidInst();
		int hexIndex = 0;
		while(inst[i] != '(' && hexIndex < 3)
		{
			hexImm[hexIndex++] = dec(inst[i++]);
			while(inst[i] == ' ' || inst[i] == '\t')
				++i;
		}
		if(inst[i] != '(')
			invalidInst();
		imm = 0;
		int q = 0;
		while(q < hexIndex)
			imm = 16*imm + hexImm[q++];
		if(imm>2047)
		imm-=4096;
	}

	else if(isdigit(inst[i]))	// if we have a positive decimal immediate
	{
		imm = 0;
		while(isdigit(inst[i]))
		{
			imm = imm*10 + (inst[i] - '0');
			i++;
		}
		if(imm > 2047)
			invalidInst();		//The largest positive number in 12 bit signed numbers is 0x7FF = 2047
	}

	else if(inst[i] == '-')		// if we have a negative decimal immediate
	{
		i++;
		while(inst[i] == ' ' || inst[i] == '\t')
			++i;
		imm = 0;
		while(isdigit(inst[i]))
		{
			imm = imm*10 + (inst[i] - '0');
			i++;
		}
		imm = -imm;
		if(imm < -2048)
			invalidInst();	// Since the smallest negative number in 12 bit signed numbers is 0x800 = -2048
	}

	else
		invalidInst();

	//Code to extract register number of rs2
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != '(')
		invalidInst();
	++i;
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		x2 = 2;
		i += 2;
		isImm = 0;
	}
	else
	{
		if(inst[i] != 'x')
			invalidInst();
		++i;
		if(isdigit(inst[i]))
		{
			x2= inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				x2 = x2*10 + (inst[i] - '0');
				++i;
			}
		}
		else
			invalidInst();
	}
	if(x1 < 0 || x1 > 31)
		invalidInst();
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != ')')
		invalidInst();
}
void Rtype(char *inst, int i)
{
	//Code to extract register number of rd
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		xd = 2;
		i += 2;
	}
	
	else
	{
		if(inst[i] != 'x')
			invalidInst();
			
		++i;
		if(isdigit(inst[i]))
		{
			xd = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				xd = xd*10 + (inst[i] - '0');
				++i;
			}
		}
		else
			invalidInst();
	}
	if(xd < 0 || xd > 31)
		invalidInst();
     
	 //Code to extract register number of rs1
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != ',')
		invalidInst();
	++i;
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		x1 = 2;
		i += 2;
	}
	else
	{
		if(inst[i] != 'x')
			invalidInst();
		++i;
		if(isdigit(inst[i]))
		{
			x1 = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				x1 = x1*10 + (inst[i] - '0');
				++i;
			}
		}
		else
			invalidInst();
	}
	if(x1 < 0 || x1 > 31)
		invalidInst();

		//Code to extract register number of rs2
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != ',')
		invalidInst();
	++i;
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		x2 = 2;
		i += 2;
		isImm = 0;
	}
	else
	{
     if(inst[i] != 'x')	// if we have rs2
	 invalidInst();
		++i;
		if(isdigit(inst[i]))
		{
			x2 = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				x2 = x2*10 + (inst[i] - '0');
				++i;
			}
		}
		else
		invalidInst();
	}
	if(x2 < 0 || x2 > 31)
		invalidInst();
}



void FRtype(char *inst, int i){ //works similar to Rtype but for floating point inst.
//Code to extract register number of rd
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		xd = 2;
		i += 2;
	}
	
	else
	{
		if(inst[i] != 'f')
			invalidInst();
			
		++i;
		if(isdigit(inst[i]))
		{
			xd = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				xd = xd*10 + (inst[i] - '0');
				++i;
			}
		}
		else
			invalidInst();
	}
	if(xd < 0 || xd > 31)
		invalidInst();
     
	 //Code to extract register number of rs1
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != ',')
		invalidInst();
	++i;
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		x1 = 2;
		i += 2;
	}
	else
	{
		if(inst[i] != 'f')
			invalidInst();
		++i;
		if(isdigit(inst[i]))
		{
			x1 = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				x1 = x1*10 + (inst[i] - '0');
				++i;
			}
		}
		else
			invalidInst();
	}
	if(x1 < 0 || x1 > 31)
		invalidInst();

		//Code to extract register number of rs2
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != ',')
		invalidInst();
	++i;
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		x2 = 2;
		i += 2;
		isImm = 0;
	}
	else
	{
     if(inst[i] != 'f')	// if we have rs2
	 invalidInst();
		++i;
		if(isdigit(inst[i]))
		{
			x2 = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				x2 = x2*10 + (inst[i] - '0');
				++i;
			}
		}
		else
		invalidInst();
	}
	if(x2 < 0 || x2 > 31)
		invalidInst();
}


void FRStype(char *inst, int i){//for single source functions like FSQRT
//Code to extract register number of rd
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		xd = 2;
		i += 2;
	}
	
	else
	{
		if(inst[i] != 'f')
			invalidInst();
			
		++i;
		if(isdigit(inst[i]))
		{
			xd = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				xd = xd*10 + (inst[i] - '0');
				++i;
			}
		}
		else
			invalidInst();
	}
	if(xd < 0 || xd > 31)
		invalidInst();
     
	 //Code to extract register number of rs1
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != ',')
		invalidInst();
	++i;
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		x1 = 2;
		i += 2;
	}
	else
	{
		if(inst[i] != 'f')
			invalidInst();
		++i;
		if(isdigit(inst[i]))
		{
			x1 = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				x1 = x1*10 + (inst[i] - '0');
				++i;
			}
		}
		else
			invalidInst();
	}
	if(x1 < 0 || x1 > 31)
		invalidInst();
}




void Itype(char *inst, int i)
{
	//Code to extract register number of rd
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		xd = 2;
		i += 2;
	}
	
	else
	{
		if(inst[i] != 'x')
			invalidInst();
			
		++i;
		if(isdigit(inst[i]))
		{
			xd = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				xd = xd*10 + (inst[i] - '0');
				++i;
			}
		}
		else
			invalidInst();
	}
	if(xd < 0 || xd > 31)
		invalidInst();
     
	 //Code to extract register number of rs1
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != ',')
		invalidInst();
	++i;
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		x1 = 2;
		i += 2;
	}
	else
	{
		if(inst[i] != 'x')
			invalidInst();
		++i;
		if(isdigit(inst[i]))
		{
			x1 = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				x1 = x1*10 + (inst[i] - '0');
				++i;
			}
		}
		else
			invalidInst();
	}
	if(x1 < 0 || x1 > 31)
		invalidInst();

	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != ',')
		invalidInst();
	++i;
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
    if(inst[i] == '0' && inst[i+1] == 'x')	// if we have a hexadecimal immediate
	{
		i = i + 2;
		while(inst[i] == ' ' || inst[i] == '\t')
			++i;
		if(inst[i] == '\0')
			invalidInst();
		int hexIndex = 0;
		while(hexIndex<3&&((inst[i]>='0'&&inst[i]<='9')|| (inst[i] >= 'A' && inst[i] <= 'F')|| (inst[i] >= 'a' && inst[i] <= 'f')))
		{
			hexImm[hexIndex++] = dec(inst[i++]);
			while(inst[i] == ' ' || inst[i] == '\t')
				++i;
		}
		if(inst[i] != '\0')
			invalidInst();
		imm = 0;
		int q = 0;
		while(q < hexIndex)
			imm = 16*imm + hexImm[q++];
		if(hexIndex == 2)
		{
			if(hexImm[0] >= 8)
				imm -= 4096;
		}
	}

	else if(isdigit(inst[i]))	// if we have a positive decimal immediate
	{ 
		imm = 0;
		while(isdigit(inst[i]))
		{
			imm = imm*10 + (inst[i] - '0');
			i++;
		}
		if(imm > 2047)
		invalidInst();	//The largest positive number in 12 bit signed numbers is 0x7FF = 2047
	}

	else if(inst[i] == '-')		// if we have a negative decimal immediate
	{
		i++;
		while(inst[i] == ' ' || inst[i] == '\t')
			++i;
		imm = 0;
		while(isdigit(inst[i]))
		{
			imm = imm*10 + (inst[i] - '0');
			i++;
		}
		imm = -imm;
		if(imm < -2048)
			invalidInst();	// Since the smallest negative number in 12 bit signed numbers is 0x8000 = -2048
	}
	else
		invalidInst();
}
void ItypeL(char *inst, int i)
{
	//Code to extract register number of rd
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		xd = 2;
		i += 2;
	}
	else
	{
		if(inst[i] != 'x')
			invalidInst();
		++i;
		if(isdigit(inst[i]))
		{
			xd = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				xd = xd*10 + (inst[i] - '0');
				++i;
			}
		}
		else
			invalidInst();
	}
	if(xd < 0 || xd > 31)
		invalidInst();


	//Code to extract register number of imm
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != ',')
		invalidInst();
	++i;
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;

	if(inst[i] == '(')		 // if we are using just register indirect mode of addressing
		imm = 0;

	else if(inst[i] == '0' && inst[i+1] == 'x')	// if we have a hexadecimal immediate
	{
		i = i + 2;
		while(inst[i] == ' ' || inst[i] == '\t')
			++i;
		if(inst[i] == '(' || inst[i] == '\0')
			invalidInst();
		int hexIndex = 0;
		while(inst[i] != '(' && hexIndex < 3)
		{
			hexImm[hexIndex++] = dec(inst[i++]);
			while(inst[i] == ' ' || inst[i] == '\t')
				++i;
		}
		if(inst[i] != '(')
			invalidInst();
		imm = 0;
		int q = 0;
		while(q < hexIndex)
			imm = 16*imm + hexImm[q++];
		if(imm>2047)
		imm-=4096;
	}

	else if(isdigit(inst[i]))	// if we have a positive decimal immediate
	{
		imm = 0;
		while(isdigit(inst[i]))
		{
			imm = imm*10 + (inst[i] - '0');
			i++;
		}
		if(imm > 2047)
			invalidInst();		//The largest positive number in 16 bit signed numbers is 0x7FF = 2047
	}

	else if(inst[i] == '-')		// if we have a negative decimal immediate
	{
		i++;
		while(inst[i] == ' ' || inst[i] == '\t')
			++i;
		imm = 0;
		while(isdigit(inst[i]))
		{
			imm = imm*10 + (inst[i] - '0');
			i++;
		}
		imm = -imm;
		if(imm < -2048)
			invalidInst();	// Since the smallest negative number in 16 bit signed numbers is 0x800 = -2048
	}

	else
		invalidInst();

	//Code to extract register number of rs1
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != '(')
		invalidInst();
	++i;
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		x1 = 2;
		i += 2;
		isImm = 0;
	}
	else
	{
		if(inst[i] != 'x')
			invalidInst();
		++i;
		if(isdigit(inst[i]))
		{
			x1 = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				x1 = x1*10 + (inst[i] - '0');
				++i;
			}
		}
		else
			invalidInst();
	}
	if(x1 < 0 || x1 > 31)
		invalidInst();
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != ')')
		invalidInst();
}
int Btype(char *inst, int i)
{
	//code to extract index of source register rs1
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		x1 = 2;
		i += 2;
	}
	else
	{
	    if(inst[i] != 'x')
			invalidInst();
		++i;
		if(isdigit(inst[i])) // if immediate
		{
		    x1 = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				x1 = x1*10 + (inst[i] - '0');
				++i;
			}
		}
		else
		invalidInst();
		}
		if(x1 < 0 || x1 > 31)
		invalidInst();


		//Code to extract index of source register rs2
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != ',')
		invalidInst();
	++i;
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		x2 = 2;
		i += 2;
	}
    else 
	{
		if(inst[i] != 'x')
		invalidInst();
		++i;
	    if(isdigit(inst[i]))
	    {
		    x2 = inst[i] - '0';
		    ++i;
		    if(isdigit(inst[i]))
			{
			    x2 = x2*10 + (inst[i] - '0');
				++i;
			}
		}
	else
	invalidInst();
	}
	if(x2 < 0 || x2 > 31)
	invalidInst();
	return i;  // retuns index after both source register
}
int Utype(char *inst, int i)
{
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		xd = 2;
		i += 2;
	}
	else
	{
	    if(inst[i] != 'x')
			invalidInst();
		++i;
		if(isdigit(inst[i]))
		{
		    xd = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				xd = xd*10 + (inst[i] - '0');
				++i;
			}
		}
		else
		invalidInst();
		}
		if(xd < 0 || xd > 31)
		invalidInst();
		return i;
}




void Fmatype(char *inst, int i){ // for multiply and arithmetic inst. like fmadd and fmsub
//Code to extract register number of rd
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		xd = 2;
		i += 2;
	}
	
	else
	{
		if(inst[i] != 'f')
			invalidInst();
			
		++i;
		if(isdigit(inst[i]))
		{
			xd = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				xd = xd*10 + (inst[i] - '0');
				++i;
			}
		}
		else
			invalidInst();
	}
	if(xd < 0 || xd > 31)
		invalidInst();
     
	 //Code to extract register number of rs1
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != ',')
		invalidInst();
	++i;
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		x1 = 2;
		i += 2;
	}
	else
	{
		if(inst[i] != 'f')
			invalidInst();
		++i;
		if(isdigit(inst[i]))
		{
			x1 = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				x1 = x1*10 + (inst[i] - '0');
				++i;
			}
		}
		else
			invalidInst();
	}
	if(x1 < 0 || x1 > 31)
		invalidInst();

		//Code to extract register number of rs2
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != ',')
		invalidInst();
	++i;
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		x2 = 2;
		i += 2;
		isImm = 0;
	}
	else
	{
     if(inst[i] != 'f')	// if we have rs2
	 invalidInst();
		++i;
		if(isdigit(inst[i]))
		{
			x2 = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				x2 = x2*10 + (inst[i] - '0');
				++i;
			}
		}
		else
		invalidInst();
	}
	if(x2 < 0 || x2 > 31)
		invalidInst();

	//Code to extract register number of rs3
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != ',')
		invalidInst();
	++i;
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		x3 = 2;
		i += 2;
		isImm = 0;
	}
	else
	{
     if(inst[i] != 'f')	// if we have rs3
	 invalidInst();
		++i;
		if(isdigit(inst[i]))
		{
			x3 = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				x3 = x3*10 + (inst[i] - '0');
				++i;
			}
		}
		else
		invalidInst();
	}
	if(x3 < 0 || x3 > 31)
		invalidInst();

}

void Fmvxwtype(char *inst, int i){

//Code to extract register number of rd
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		xd = 2;
		i += 2;
	}
	
	else
	{
		if(inst[i] != 'x')
			invalidInst();
			
		++i;
		if(isdigit(inst[i]))
		{
			xd = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				xd = xd*10 + (inst[i] - '0');
				++i;
			}
		}
		else
			invalidInst();
	}
	if(xd < 0 || xd > 31)
		invalidInst();

 //Code to extract register number of rs1
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != ',')
		invalidInst();
	++i;
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		x1 = 2;
		i += 2;
	}
	else
	{
		if(inst[i] != 'f')
			invalidInst();
		++i;
		if(isdigit(inst[i]))
		{
			x1 = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				x1 = x1*10 + (inst[i] - '0');
				++i;
			}
		}
		else
			invalidInst();
	}
	if(x1 < 0 || x1 > 31)
		invalidInst();
     

}


void Fmvwxtype(char *inst, int i){

//Code to extract register number of rd
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		xd = 2;
		i += 2;
	}
	
	else
	{
		if(inst[i] != 'f')
			invalidInst();
			
		++i;
		if(isdigit(inst[i]))
		{
			xd = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				xd = xd*10 + (inst[i] - '0');
				++i;
			}
		}
		else
			invalidInst();
	}
	if(xd < 0 || xd > 31)
		invalidInst();

 //Code to extract register number of rs1
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != ',')
		invalidInst();
	++i;
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		x1 = 2;
		i += 2;
	}
	else
	{
		if(inst[i] != 'x')
			invalidInst();
		++i;
		if(isdigit(inst[i]))
		{
			x1 = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				x1 = x1*10 + (inst[i] - '0');
				++i;
			}
		}
		else
			invalidInst();
	}
	if(x1 < 0 || x1 > 31)
		invalidInst();
}
     

void FStype(char *inst, int i){                // instruction is of the form rs1, imm[rs2]  rs1 is floating point register

//Code to extract register number of rs1
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		x1 = 2;
		i += 2;
	}
	else
	{
		if(inst[i] != 'f')
			invalidInst();
		++i;
		if(isdigit(inst[i]))
		{
			x1 = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				x1 = x1*10 + (inst[i] - '0');
				++i;
			}
		}
		else
			invalidInst();
	}
	if(x1 < 0 || x1 > 31)
		invalidInst();

//Code to extract register number of rs2 and value of immediate
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != ',')
		invalidInst();
	++i;
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;

	if(inst[i] == '(')		 // if we are using just register indirect mode of addressing
		imm = 0;

	else if(inst[i] == '0' && inst[i+1] == 'x')	// if we have a hexadecimal immediate
	{
		i = i + 2;
		while(inst[i] == ' ' || inst[i] == '\t')
			++i;
		if(inst[i] == '(' || inst[i] == '\0')
			invalidInst();
		int hexIndex = 0;
		while(inst[i] != '(' && hexIndex < 3)
		{
			hexImm[hexIndex++] = dec(inst[i++]);
			while(inst[i] == ' ' || inst[i] == '\t')
				++i;
		}
		if(inst[i] != '(')
			invalidInst();
		imm = 0;
		int q = 0;
		while(q < hexIndex)
			imm = 16*imm + hexImm[q++];
		if(imm>2047)
		imm-=4096;
	}

	else if(isdigit(inst[i]))	// if we have a positive decimal immediate
	{
		imm = 0;
		while(isdigit(inst[i]))
		{
			imm = imm*10 + (inst[i] - '0');
			i++;
		}
		if(imm > 2047)
			invalidInst();		//The largest positive number in 12 bit signed numbers is 0x7FF = 2047
	}

	else if(inst[i] == '-')		// if we have a negative decimal immediate
	{
		i++;
		while(inst[i] == ' ' || inst[i] == '\t')
			++i;
		imm = 0;
		while(isdigit(inst[i]))
		{
			imm = imm*10 + (inst[i] - '0');
			i++;
		}
		imm = -imm;
		if(imm < -2048)
			invalidInst();	// Since the smallest negative number in 12 bit signed numbers is 0x800 = -2048
	}

	else
		invalidInst();

	//Code to extract register number of rs2
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != '(')
		invalidInst();
	++i;
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		x2 = 2;
		i += 2;
		isImm = 0;
	}
	else
	{
		if(inst[i] != 'x')
			invalidInst();
		++i;
		if(isdigit(inst[i]))
		{
			x2= inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				x2 = x2*10 + (inst[i] - '0');
				++i;
			}
		}
		else
			invalidInst();
	}
	if(x1 < 0 || x1 > 31)
		invalidInst();
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != ')')
		invalidInst();
}




void FCMPtype(char *inst, int i){     //instruction is of the form frd, rs1, rs2 
 
//Code to extract register number of rd
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		xd = 2;
		i += 2;
	}
	
	else
	{
		if(inst[i] != 'x')
			invalidInst();
			
		++i;
		if(isdigit(inst[i]))
		{
			xd = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				xd = xd*10 + (inst[i] - '0');
				++i;
			}
		}
		else
			invalidInst();
	}
	if(xd < 0 || xd > 31)
		invalidInst();
     
	 //Code to extract register number of rs1
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != ',')
		invalidInst();
	++i;
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		x1 = 2;
		i += 2;
	}
	else
	{
		if(inst[i] != 'f')
			invalidInst();
		++i;
		if(isdigit(inst[i]))
		{
			x1 = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				x1 = x1*10 + (inst[i] - '0');
				++i;
			}
		}
		else
			invalidInst();
	}
	if(x1 < 0 || x1 > 31)
		invalidInst();

		//Code to extract register number of rs2
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != ',')
		invalidInst();
	++i;
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] == 's' && inst[i+1] == 'p')
	{
		x2 = 2;
		i += 2;
		isImm = 0;
	}
	else
	{
     if(inst[i] != 'f')	// if we have rs2
	 invalidInst();
		++i;
		if(isdigit(inst[i]))
		{
			x2 = inst[i] - '0';
			++i;
			if(isdigit(inst[i]))
			{
				x2 = x2*10 + (inst[i] - '0');
				++i;
			}
		}
		else
		invalidInst();
	}
	if(x2 < 0 || x2 > 31)
		invalidInst();
}







