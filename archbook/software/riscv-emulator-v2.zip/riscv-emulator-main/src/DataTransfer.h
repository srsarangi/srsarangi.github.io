#ifndef DATATRANSFER_H
#define DATATRANSFER_H
extern void STOREB(char *inst, int i); // function to store byte in memory
extern void STOREH(char *inst, int i); // function to store halfword in memory
extern void STOREW(char *inst, int i);// function to store word in memory
extern void STORED(char *inst, int i); // function to store doubleword in memory
extern void LOADB(char *inst, int i);  // function to load byte from memory to register		
extern void LOADH(char *inst, int i);  // function to load halfword from memory to register
extern void LOADW(char *inst, int i);  // function to load word from memory to register
extern void LOADD(char *inst, int i); // function to load doubleword from memory to register
extern void LOADBU(char *inst, int i); // function to load unsigned byte from memory to register
extern void LOADHU(char *inst, int i);  // function to load unsigned halfword from memory to register
extern void LOADWU(char *inst, int i); // function to load unsigned word from memory to register
extern void FSTORE(char *inst, int i);  //function to store a floating point value in memory
extern void FLOAD(char *inst, int i); //function to load a floating point value from memory to register

# endif
