#ifndef EXECUTION_H
#define EXECUTION_H
extern void PRINT(char *inst, int i); // extract index of specified register and  prints value stored in them
extern void executeInstruction(void); // function to execute instruction of specified pc. it takes beginning and ending index of instruction as arguments.
extern void FPRINTS(char *inst , int i); // extract index of specified register and  prints value stored in them upto 1 digit after decimal 
extern void FPRINTD(char *inst , int i);  // extract index of specified register and  prints value stored in them upto 2 digit after decimal 
extern void FPRINTQ(char *inst , int i);  // extract index of specified register and  prints value stored in them upto 4 digit after decimal 
#endif

