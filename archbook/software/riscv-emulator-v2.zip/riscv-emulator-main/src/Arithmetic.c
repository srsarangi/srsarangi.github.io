#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include "Global_Variable.h"
#include "Register.h"
#include "Arithmetic.h"

void ADD(char *inst, int i)  // function that perform addition on content of two register and stores in destination register
{
    Rtype(inst, i);  // calls Rtype() function that is present in Register.h header file
	xreg[xd] = xreg[x1] + xreg[x2];
}


void FADD(char *inst, int i)   // function that perform addition on content of two floating point register and stores in destination register
{

    FRtype(inst, i);   // calls FRtype() function that is present in Register.h header file
     freg[xd] = freg[x1]  + freg[x2];

}


void ADDI(char *inst, int i) // function that perform addition on content of first source register and immediate and stores in destination register
{
    Itype(inst, i);  // calls Itype() function that is present in Register.h header file
	xreg[xd] = xreg[x1]+imm;
}


void SUB(char *inst, int i) //function that perform subtraction on content of two register and stores in destination register
{
    Rtype(inst, i); // calls Rtype() function that is present in Register.h header file
	xreg[xd] = xreg[x1]-xreg[x2];
}

void FSUB(char *inst, int i) //function that perform subtraction on content of two floating point register and stores in destination register
{
       FRtype(inst, i); // calls FRtype() function that is present in Register.h header file
       freg[xd] = freg[x1] - freg[x2];

}

void MUL(char *inst, int i)  //function that perform multiplication on content of two source registers and stores in destination register
{
    Rtype(inst, i);  //calls Rtype() function that is present in Register.h header file
	xreg[xd] = xreg[x1]*xreg[x2];
}


void FMUL(char *inst, int i)  //function that perform multiplication on content of two floating point source registers and stores in destination register
{

FRtype(inst, i);    // calls FRtype() function that is present in Register.h header file
freg[xd] = freg[x1] * freg[x2];

}


void FMADD(char *inst, int i)  //function that performs multiplication on content of first two floating point source registers and adds it with the content of third register,finally stores in destination register
{

Fmatype(inst, i); // calls Fmatype() function that is present in Register.h header file
freg[xd] = (freg[x1]*freg[x2]) + freg[x3];

}

void FMSUB(char *inst, int i)  //function that performs multiplication on content of first two floating point source registers and subtracts the content of third register from it,finally stores in destination register
{

Fmatype(inst, i);   // calls Fmatype() function that is present in Register.h header file
freg[xd] = (freg[x1]* freg[x2]) - freg[x3];

}


void MULH(char *inst, int i)  //function that perform multiplication on content of two source registers and stores upper 64-bits in destination register
{
    Rtype(inst, i);  //calls Rtype() function that is present in Register.h header file
	xreg[xd]=(xreg[x1]/4294967296)*(xreg[x2]/4294967296);
}
void MULHU(char *inst, int i)  //function that perform multiplication on unsigned content of two source registers and stores upper 64-bits in destination register
{
    Rtype(inst, i);  //calls Rtype() function that is present in Register.h header file
	xreg[xd] = ((unsigned long long)xreg[x1]/4294967296)*((unsigned long long)xreg[x2]/4294967296);
}
void MULHSU(char *inst, int i)  //function that perform multiplication on content of two source registers and stores upper 64-bit in destination register
{
    Rtype(inst, i);  //calls Rtype() function that is present in Register.h header file
	xreg[xd] = (xreg[x1]/4294967296)*((unsigned long long)xreg[x2]/4294967296);
}
void DIV(char *inst, int i)  //function that perform division on content of two source registers and stores in destination register
{
    Rtype(inst, i);  //calls Rtype() function that is present in Register.h header file
	xreg[xd] = xreg[x1]/xreg[x2];
}

void FDIV(char *inst, int i)  //function that perform division on content of two floating point source registers and stores in destination register
{

    FRtype(inst, i);  //calls FRtype() function that is present in Register.h header file
     freg[xd] = freg[x1]/freg[x2];

}


void DIVU(char *inst, int i)  //function that perform division on unsigned content of two source registers and stores in destinstion register
{
    Rtype(inst, i);  //calls Rtype() function that is present in Register.h header file
	xreg[xd] = (unsigned long long)xreg[x1]/(unsigned long long)xreg[x2];
}
void REM(char *inst, int i)  //function that provide remainder
{
    Rtype(inst, i);  //calls Rtype() function that is present in Register.h header file
	xreg[xd] = xreg[x1]%xreg[x2];
}
void REMU(char *inst, int i)  //function that provide remainder for unsigned division
{
    Rtype(inst, i);  //calls Rtype() function that is present in Register.h header file
	xreg[xd] = (unsigned long long)xreg[x1]%(unsigned long long)xreg[x2];
}
void ADDW(char *inst, int i)  // function that perform addition on content of two register and stores in destinstion register : only on lower 32-bits
{
    Rtype(inst, i);  // calls Rtype() function that is present in Register.h header file
	xreg[xd] =(int)(xreg[x1]+xreg[x2]);
}
void ADDIW(char *inst, int i) // function that perform addition on content of first source register and immediate and stores in destinstion register : only on lower 32-bits
{
    Itype(inst, i);  // calls Itype() function that is present in Register.h header file
	xreg[xd] = (int)(xreg[x1]+imm);
}
void SUBW(char *inst, int i) //function that perform substraction on content of two register and stores in destinstion register : only on lower 32-bits
{
    Rtype(inst, i); // calls Rtype() function that is present in Register.h header file
	xreg[xd] = (int)(xreg[x1]-xreg[x2]);
}
void MULW(char *inst, int i)  //function that perform multiplication on content of two source registers and stores in destinstion register : only on lower 32-bits
{
    Rtype(inst, i);  //calls Rtype() function that is present in Register.h header file
	xreg[xd] = (int)xreg[x1]*(int)xreg[x2];
}
void DIVW(char *inst, int i)  //function that perform division for lower 32-bit
{
    Rtype(inst, i);  //calls Rtype() function that is present in Register.h header file
	xreg[xd] = (int)xreg[x1]/(int)xreg[x2];
}
void DIVUW(char *inst, int i)  //function that perform division for unsigned lower 32-bit
{
    Rtype(inst, i);  //calls Rtype() function that is present in Register.h header file
	xreg[xd] = (unsigned int)xreg[x1]/(unsigned int)xreg[x2];
}
void REMW(char *inst, int i)  //function that provide remainder for lower 32-bit
{
    Rtype(inst, i);  //calls Rtype() function that is present in Register.h header file
	xreg[xd] = (int)xreg[x1]%(int)xreg[x2];
}
void REMUW(char *inst, int i)  //function that provides remainder for unsigned lower 32-bit
{
    Rtype(inst, i);  //calls Rtype() function that is present in Register.h header file
	xreg[xd] = (unsigned int)xreg[x1]%(unsigned int)xreg[x2];
}

void LUI(char *inst, int i)
{
	i=Utype(inst, i);

	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
	if(inst[i] != ',')
		invalidInst();
	++i;
	while(inst[i] == ' ' || inst[i] == '\t')
		i++;
    if(inst[i] == '0' && inst[i+1] == 'x')	// if we have a hexadecimal immediate
	{
		i = i + 2;
		while(inst[i] == ' ' || inst[i] == '\t')
			++i;
		if(inst[i] == '\0')
			invalidInst();
		int hexIndex = 0;
		while((inst[i]>='0'&&inst[i]<='9')|| (inst[i] >= 'A' && inst[i] <= 'F')|| (inst[i] >= 'a' && inst[i] <= 'f'))
		{
			hexImm[hexIndex++] = dec(inst[i++]);
			while(inst[i] == ' ' || inst[i] == '\t')
				++i;
		}
		if(inst[i] != '\0')
			invalidInst();
		imm = 0;
		int q = 0;
		while(q < hexIndex)
			imm = 16*imm + hexImm[q++];
		if(hexIndex == 4)
		{
			if(hexImm[0] >= 8)
				imm -= 1048576;
		}
	}

	else if(isdigit(inst[i]))	// if we have a positive decimal immediate
	{ 
		imm = 0;
		while(isdigit(inst[i]))
		{
			imm = imm*10 + (inst[i] - '0');
			i++;
		}
		if(imm > 524287)
		invalidInst();	//The largest positive number in 12 bit signed numbers is 0x7FF = 2047
	}

	else if(inst[i] == '-')		// if we have a negative decimal immediate
	{
		i++;
		while(inst[i] == ' ' || inst[i] == '\t')
			++i;
		imm = 0;
		while(isdigit(inst[i]))
		{
			imm = imm*10 + (inst[i] - '0');
			i++;
		}
		imm = -imm;
		if(imm < -524288)
			invalidInst();	// Since the smallest negative number in 12 bit signed numbers is 0x8000 = -2048
	}
	else
		invalidInst();
	xreg[xd]=imm<<12;
}



void FMIN(char *inst, int i) //function that stores the minimum of the values stored in two floating point source registers and stores in destination register

{
  FRtype(inst, i); //calls the function FRtype that is defined in the header file Register.h
 freg[xd] = (freg[x1]<freg[x2]) ? freg[x1] : freg[x2] ;

}

void FMAX(char *inst, int i)//function that stores the maximum of the values stored in two floating point source registers and stores in destination register
{
 FRtype(inst, i);   //calls the function FRtype that is defined in the header file Register.h
 freg[xd] = (freg[x1]>freg[x2]) ? freg[x1] : freg[x2] ;

}


void FMVXW(char *inst, int i) //function that moves the value in floating-point register rs1 to the lower 32 bits of integer register rd.
{
Fmvxwtype(inst, i);   // calls the function Fmvxwtype defined in the Register.h header file
xreg[xd] = freg[x1];

}

void FMVWX(char *inst, int i) //function that moves the lower 32 bits of the value in integer register rs1 to the floating point register rd.
{ 
Fmvwxtype(inst, i);  // calls the function Fmvwxtype defined in the Register.h header file
freg[xd] = xreg[x1];
}


void FSQRT(char *inst, int i) //function that computes the square root of the floating point number stored in source register and stores the result in destination register
{
FRStype(inst, i);
for(freg[xd]=0.01; freg[xd]*freg[xd]<freg[x1]; freg[xd] = freg[xd] + 0.01);

}


void FSGNJ(char *inst, int i)  //function for sign injection instructions
{
FRtype(inst, i);
int ressign = freg[x2]< 0 ? -1 : 1  ;
freg[xd] = fabs(freg[x1])*ressign ;
}


void FSGNJN(char *inst, int i)  //function for sign injection instructions
{
FRtype(inst, i);
int ressign = freg[x2]< 0 ? 1 : -1  ;
freg[xd] = fabs(freg[x1])*ressign ;
}


void FSGNJX(char *inst, int i)  //function for sign injection instructions
{
FRtype(inst, i);
int ressign ;
if((freg[x1]<0 && freg[x2]>0) || (freg[x1]>0 && freg[x2]<0))
ressign = -1;
else ressign =1;

freg[xd] = fabs(freg[x1])*ressign ;

}












