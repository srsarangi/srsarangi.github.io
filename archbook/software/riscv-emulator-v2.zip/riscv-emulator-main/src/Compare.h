#ifndef COMPARE_H
#define COMPARE_H

extern void SLT(char *inst, int i); // function to set if less than (two source register)
extern void SLTI(char *inst, int i);  // function to set if less than (one source register one immediate)
extern void SLTU(char *inst, int i); // function to set if less than unsigned (two source registers)
extern void SLTIU(char *inst, int i);   // function to set if less than unsigned (one source register and immediate)
extern void FLT(char *inst, int i);    //function to set if less than
extern void FLE(char *inst, int i);  //function to set if less than or equal
extern void FEQ(char *inst, int i); //function to set if equal
# endif
