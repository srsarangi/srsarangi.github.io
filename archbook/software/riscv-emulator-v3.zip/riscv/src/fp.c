#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <stdlib.h>
#include "parser.h"
#include "insts.h"
#include "global.h"

void FADD(struct inst* ins) {
    global.fpregs[ins->rd] = global.fpregs[ins->rs1] + global.fpregs[ins->rs2];
}
void FSUB(struct inst* ins) {
    global.fpregs[ins->rd] = global.fpregs[ins->rs1] - global.fpregs[ins->rs2];
}
void FMUL(struct inst* ins) {
    global.fpregs[ins->rd] = global.fpregs[ins->rs1] * global.fpregs[ins->rs2];
} 
void FDIV(struct inst* ins) {
    global.fpregs[ins->rd] = global.fpregs[ins->rs1] / global.fpregs[ins->rs2];
}
void FMIN(struct inst* ins) {
    float a = global.fpregs[ins->rs1];
    float b = global.fpregs[ins->rs2];
    global.fpregs[ins->rd] = (a < b)? a : b ;
} 
void FMAX(struct inst* ins) {
   float a = global.fpregs[ins->rs1];
   float b = global.fpregs[ins->rs2];
   global.fpregs[ins->rd] = (a > b)? a : b ;
}

void FSQRT(struct inst* ins) {
   float a = global.fpregs[ins->rs1];
   global.fpregs[ins->rd] = sqrt(a) ;
}

void FMADDS(struct inst* ins) {
    global.fpregs[ins->rd] = global.fpregs[ins->rs1] * global.fpregs[ins->rs2] + global.fpregs[ins->rs3] ;
} 

void FMSUBS(struct inst* ins) {
    global.fpregs[ins->rd] = global.fpregs[ins->rs1] * global.fpregs[ins->rs2] - global.fpregs[ins->rs3] ;
}

void FCVTSW(struct inst* ins) {
    global.fpregs[ins->rd] =  (float) global.xregs[ins->rs1];
}

void FCVTWS(struct inst* ins) {
    global.xregs[ins->rd] = (int) global.fpregs[ins->rs1];
}

void FLTS(struct inst* ins) {
    if (global.fpregs[ins->rs1] < global.fpregs[ins->rs2])
        global.xregs[ins->rd] = 1;
    else
        global.xregs[ins->rd] = 0;
}

void FLES(struct inst* ins) {
    if (global.fpregs[ins->rs1] <= global.fpregs[ins->rs2])
        global.xregs[ins->rd] = 1;
    else
        global.xregs[ins->rd] = 0;
}
void FEQS(struct inst* ins) {
    if (global.fpregs[ins->rs1] == global.fpregs[ins->rs2])
        global.xregs[ins->rd] = 1;
    else
        global.xregs[ins->rd] = 0;
}
