#include "parser.h"

#ifndef GLOBAL_H 
#define GLOBAL_H 

#define MEMSIZE 4096

typedef struct {
	char *var;
	int is_int;
	union value {
		int i;
		float f;
	};
	int addr; 
} data_constant; 

struct global {
	int xregs[32];
        float fpregs[32];
	char mem[MEMSIZE];
	struct program *program;
	int next_pc; 
	int taken_branch;
	data_constant constants[32]; 
	int num_constants;
};
extern struct global global; 
extern void execute();
#endif
