#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <stdlib.h>
#include "parser.h"
#include "insts.h"
#include "global.h"

void END (struct inst* ins) {
	exit(0);
}

void PRINT (struct inst* ins){
    if (ins->reg_types[RS1] == INT_REG)
	    printf ("x%d(%s) = %d, %x\n", ins->rs1, get_mnemonic(ins->rs1), global.xregs[ins->rs1], global.xregs[ins->rs1]); 
    else
        printf ("f%d(%s) = %f\n", ins->rs1, get_fp_mnemonic(ins->rs1), global.fpregs[ins->rs1]); 
}

void ADD(struct inst* ins)  
{
    global.xregs[ins->rd] = global.xregs[ins->rs1] + global.xregs[ins->rs2];
}

void MUL(struct inst* ins)  
{
    global.xregs[ins->rd] = global.xregs[ins->rs1] * global.xregs[ins->rs2];
}

void MULH(struct inst* ins)  
{
    long long int v1 = global.xregs[ins->rs1];
    long long int v2 = global.xregs[ins->rs2];
    long long int v3 = (v1 * v2) >> 32; // FIXME: arith shift right 
    global.xregs[ins->rd] = (int) v3;
}

void MULHU(struct inst* ins)  
{
    unsigned long long int v1 = global.xregs[ins->rs1];
    unsigned long long int v2 = global.xregs[ins->rs2];
    unsigned long long int v3 = (v1 * v2) >> 32; // FIXME: arith shift right 
    global.xregs[ins->rd] = (unsigned int) v3;
}

void MULHSU(struct inst* ins)  
{
    long long int v1 = global.xregs[ins->rs1];
    unsigned long long int v2 = global.xregs[ins->rs2];
    long long int v3 = (v1 * v2) >> 32; // FIXME: arith shift right 
    global.xregs[ins->rd] = (int) v3;
}


void DIV(struct inst* ins)  
{
    global.xregs[ins->rd] = global.xregs[ins->rs1] / global.xregs[ins->rs2];
}

void DIVU(struct inst* ins)  
{
	global.xregs[ins->rd] = ((unsigned int) global.xregs[ins->rs1]) / ((unsigned int) global.xregs[ins->rs2]);

}

void REM(struct inst* ins)  
{
    global.xregs[ins->rd] = global.xregs[ins->rs1] % global.xregs[ins->rs2];
}

void REMU(struct inst* ins)  
{
	global.xregs[ins->rd] = ((unsigned int) global.xregs[ins->rs1]) % ((unsigned int) global.xregs[ins->rs2]);

}

void ADDI(struct inst *ins) 
{
	global.xregs[ins->rd] = global.xregs[ins->rs1] + ins->imm;
}

void SUB(struct inst* ins) 
{
    global.xregs[ins->rd] = global.xregs[ins->rs1] - global.xregs[ins->rs2];
}

void LUI (struct inst* ins) 
{
    global.xregs[ins->rd] = ins->imm << 12; 
}

/* load full 32-bit immediate */
void LI (struct inst* ins) 
{
    global.xregs[ins->rd] = ins->imm; 
}

/* load address */
void LA (struct inst* ins) 
{
    global.xregs[ins->rd] = ins->imm; 
}
