#ifndef UTIL_H 
#define UTIL_H 

extern REG_TYPE extract_reg(char* inst, int *i, int *p);
extern int extract_imm (char *inst, int *idx);
extern char* find_lbl_point (char *line, char** col_pt);
extern void skip_spaces(char *inst, int *idx);
extern void skip_spaces_comma(char *inst, int *idx);
extern void left_paren_check(char *inst, int *idx);
extern char* extract_pc(char *inst, int* idx, int *imm);
extern char* extract_term (char* line);
extern int is_imm(char *inst, int i);
extern int is_empty(char *line);
extern int is_comment (char *line);
extern int is_constant (char *line);
extern void lower_case (char *line);
#endif
