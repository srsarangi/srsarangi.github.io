#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <unistd.h>
#include <string.h>
#include <assert.h>
#include "parser.h"
#include "insts.h"
#include "global.h"
#include "util.h"

#define MAXCHARS 128
#define MAXINSTCODES 64

/* global variables for this file */
static int line_count = 1;
static int current_pc = 0;
static char* old_label = NULL;
static int INST_CNT = 0;

/* main table that stores the details of all the RISC-V instructions */
inst_type allinsts [MAXINSTCODES]; 

static void add_inst_type(char* op, TYPE type, void (*func)(struct inst*)){
	inst_type it;
	it.op = op;
	it.code = INST_CNT;
	it.type = type;
	it.func = func;
	allinsts[INST_CNT++] = it;

}

void parser_init() {
	add_inst_type("end", T_END, END);  /* code = 0 */
	add_inst_type(".print",  T_P, PRINT);
	add_inst_type("add", T_R, ADD);
  	add_inst_type("addi", T_I, ADDI);
	add_inst_type("sub", T_R, SUB); 
	add_inst_type("bge",  T_B, BGE);	
	add_inst_type("beq",  T_B, BEQ);
 	add_inst_type("bne",  T_B, BNE);
   	add_inst_type("blt", T_B, BLT);
	add_inst_type("bgeu", T_B, BGEU);
	add_inst_type("bltu", T_B, BLTU);
	add_inst_type("jal", T_U, JAL);
   	add_inst_type("jalr", T_IL, JALR);
   	add_inst_type("lw", T_IL, LOADW);
   	add_inst_type("sw", T_S, STOREW);
	add_inst_type("mul", T_R, MUL);
	add_inst_type("div", T_R, DIV);
	add_inst_type("rem", T_R, REM);
	
	add_inst_type("lui", T_U, LUI);
   	add_inst_type("li", T_U, LI);
	add_inst_type("la", T_L, LA);
	add_inst_type("remu", T_R, REMU);
	add_inst_type("divu", T_R, DIVU); 
	add_inst_type("mulhsu", T_R, MULHSU);
	add_inst_type("mulhu", T_R, MULHU);
	add_inst_type("mulh", T_R, MULH);

	add_inst_type("loadb",T_IL, LOADB);
	add_inst_type("loadh",T_IL, LOADH); 
	add_inst_type("storeb",T_S, STOREB);
	add_inst_type("storeh",T_S, STOREH); 	

	add_inst_type ("xor", T_R, XOR);
	add_inst_type ("xori", T_I, XORI); 
   	add_inst_type ("or", T_R, OR);
	add_inst_type ("ori", T_I, ORI);  
	add_inst_type ("and", T_R, AND);  
	add_inst_type ("andi", T_I, ANDI);  

	add_inst_type ("slt", T_R, SLT); 
	add_inst_type ("slti", T_I, SLTI);
	add_inst_type ("sltu", T_R, SLTU); 
	add_inst_type ("sltiu", T_I, SLTIU); 

	add_inst_type ("sll", T_R, SLL); 
	add_inst_type ("slli", T_I, SLLI); 
	add_inst_type ("sra", T_R, SRA);
	add_inst_type ("srai", T_I, SRAI);
	add_inst_type ("srl", T_R, SRL); 
	add_inst_type ("srli", T_I, SRLI); 

   	add_inst_type ("flw", T_ILF, FLW); 
	add_inst_type ("fsw", T_SF, FSW); 

   	add_inst_type ("fadd.s", T_R, FADD);  
   	add_inst_type ("fsub.s", T_R, FSUB);
   	add_inst_type ("fmul.s", T_R, FMUL);  
   	add_inst_type ("fdiv.s", T_R, FDIV);
   	add_inst_type ("fmin.s", T_R, FMIN);  
   	add_inst_type ("fmax.s", T_R, FMAX);
   	add_inst_type ("fsqrt.s", T_C, FSQRT);
   	add_inst_type ("fmadd.s", T_FR, FMADDS);  
   	add_inst_type ("fmsub.s", T_FR, FMSUBS);
   	add_inst_type ("fcvt.s.w", T_C, FCVTSW);
   	add_inst_type ("fcvt.w.s", T_C, FCVTWS);
   	add_inst_type ("flt.s", T_R, FLTS);
   	add_inst_type ("fle.s", T_R, FLES);
   	add_inst_type ("feq.s", T_R, FEQS);
}

void invalidInst()
{
	printf("The instruction at line number %d is INVALID.\n", line_count);
	exit(1);
}

static inst_type get_inst_type (char *s){
	for (int i=0; i < INST_CNT; i++){
		inst_type it = allinsts[i];
		if (!strcmp(it.op,s)) 
			return it;
	}
	printf("Invalid operation type %s\n",s);
	invalidInst();
}

inst_type get_inst_by_code(int code){
	if (code < 0 || code > INST_CNT) {
		printf("Invalid code %d\n",code);
		invalidInst();
	}
	return allinsts[code];
}

void print_all_constants(){
	for (int i=0; i < global.num_constants; i++) {
		data_constant dc = global.constants[i];
		if(dc.is_int) printf ("%s, val = %d, addr = %d\n",
				dc.var, dc.i, dc.addr); 
		else
			printf("%s, val = %f, addr = %d\n", 
					dc.var, dc.f, dc.addr);
	}
}

int find_pc (char *jump_label, struct program *prog, int idx){
	for(int i=0; i < prog->numlabels; i++) {
		labelpc lpc = prog->labelpcs[i];
		if (!strcmp(lpc.label, jump_label)) {
			/* match found */
			return lpc.pc;
		}
	}
	printf ("Could not find label %s\n",jump_label);
	invalidInst();
}

static void process_constant(char *line){
	static int const_mem_ptr = 0;
	char *rest, *endptr;
	char *var = find_lbl_point(line, &rest);	
	char *ptr;
	float num; int val;
	data_constant dc;
	dc.var = var;
	dc.addr = const_mem_ptr;
	int flag = 0;

	if ((ptr = strstr(rest, ".float")) != NULL) {
		ptr = ptr + 6;
		num = strtof(ptr, &endptr);
		if (ptr == endptr) {
			printf("Invalid constant specifier %s\n",rest);
			invalidInst();
		}
		float *x = (float *) &(global.mem[const_mem_ptr]);
		*x = num;
		dc.f = num;
		dc.is_int = 0;
		flag = 1;
	} else if ((ptr = strstr(rest, ".word")) != NULL) {
		ptr = ptr + 5; 
		int i = 0;
		val = extract_imm(ptr, &i);
		int *x = (int *) &(global.mem[const_mem_ptr]);
		*x = val;
		dc.i = val;
		dc.is_int = 1;
		flag = 1;
	} 
	if (flag == 0) {
		printf("Invalid constant specification line %s\n",line);
		invalidInst();  /* exit */
	}

	global.constants[global.num_constants] = dc;
	global.num_constants++;
	const_mem_ptr += 4;
}

/* register related */

char* mnems[] = {"zero", "ra", "sp", "gp", "tp", "t0", "t1", "t2", "s0",
    "s1", "a0", "a1", "a2", "a3", "a4", "a5", "a6", "a7", "s2", "s3", "s4", "s5",
    "s6", "s7", "s8", "s9", "s10", "s11", "t3", "t4", "t5", "t6"};

char *fnems[] = {"ft0", "ft1", "ft2", "ft3", "ft4", "ft5", "ft6", "ft7", "fs0", "fs1", "fa0", "fa1", 
    "fa2", "fa3", "fa4", "fa5", "fa6", "fa7", "fs2", "fs3", "fs4", "fs5", "fs6", "fs7", "fs8", "fs9", "fs10", "fs11",
    "ft8", "ft9", "ft10", "ft11"}; 

char * get_mnemonic(int id){
	if (id == -1) return "";
	else return mnems[id];
}

char * get_fp_mnemonic(int id){
	if (id == -1) return "";
	else return fnems[id];
}

int find_address (char *var) {
	for(int i=0; i < global.num_constants; i++){
		data_constant dc = global.constants[i];
		if(!(strcmp(dc.var,var)))
			return dc.addr;
	}
	printf("Could not find the value of the variable %s\n",var);
	invalidInst();
}

/* instruction related */
static struct inst* create_inst() {
	struct inst* ins = (struct inst*) malloc (sizeof(struct inst));
	ins->code = -1;
	ins->rs1 = -1;
	ins->rs2 = -1;
    ins->rs3 = -1;
	ins->rd = -1;
	ins->imm = -1;
	ins->pc = -1;
	ins->label = NULL;
	ins->jump_label = NULL;
    for (int i=0; i < 4; i++)
        ins->reg_types[i] = INT_REG; 

	return ins;
}

void print_inst (struct inst* ins) {
	inst_type it = get_inst_by_code(ins->code);

	printf ("code = %d(%s), ", ins->code, it.op);

    if (ins->reg_types[RS1] == INT_REG)
        printf ("rs1 = x%d(%s), ",ins->rs1, get_mnemonic(ins->rs1));
    else 
        printf ("rs1 = f%d(%s), ",ins->rs1, get_fp_mnemonic(ins->rs1));

    if (ins->reg_types[RS2] == INT_REG)
        printf ("rs2 = x%d(%s), ", ins->rs2, get_mnemonic(ins->rs2));
    else
        printf ("rs2 = f%d(%s), ", ins->rs2, get_fp_mnemonic(ins->rs2));

    if (ins->reg_types[RD] == INT_REG)
        printf ("rd = x%d(%s), ", ins->rd, get_mnemonic(ins->rd));
    else
        printf ("rd = f%d(%s), ", ins->rd, get_fp_mnemonic(ins->rd));

    if (ins->reg_types[RS3] == FP_REG)
        printf ("rs3 = f%d(%s), ", ins->rs3, get_fp_mnemonic(ins->rs3));

    printf("imm = %d, pc = %d ", ins->imm, ins->pc);

    /* label and jump_label */

    if (ins->label != NULL)
		printf ("label = %s ",ins->label);
	if (ins->jump_label != NULL)
		printf ("jump label = %s ", ins->jump_label); 
	printf ("\n");
}

/* instruction operand parsing */

/* instruction is of the form rs1, imm(rs2) */
static void Sformat(char* inst, struct inst* ins)	
{
    int i = 0, rs1, rs2, imm;
    REG_TYPE ts1, ts2;

    /* Extract rs1 */
    ts1 = extract_reg (inst, &i, &rs1);
    skip_spaces_comma(inst, &i);

    /* find the immediate */
    imm = extract_imm(inst, &i);
    left_paren_check(inst, &i);
    
    /* extract rs2 */
    ts2 = extract_reg (inst, &i, &rs2); 

    /* fill the instruction */
    ins->rs1 = rs1;
    ins->imm = imm;
    ins->rs2 = rs2; 

    if (ts2 != INT_REG) {
        printf ("1. We expect only integer registers. \n");
        invalidInst();
    }

    /* fill in the instruction types */
    ins->reg_types[RS1] = ts1;
    ins->reg_types[RS2] = ts2;
}

static void Rformat(char *inst, struct inst *ins)  // rd, rs1, rs2
{
    int i = 0,rd,rs1,rs2;
    REG_TYPE td, ts1, ts2;

    /* Extract rd */
    td = extract_reg (inst, &i, &rd);
    skip_spaces_comma(inst, &i);

     /* Extract rs1 */
    ts1 = extract_reg (inst, &i, &rs1);
    skip_spaces_comma(inst, &i);
    
    // extract rs2
    ts2 = extract_reg (inst, &i, &rs2);

    // fill the instruction
    ins->rs1 = rs1;
    ins->rs2 = rs2; 
    ins->rd = rd;

    // fill the register types
    ins->reg_types[RS1] = ts1;
    ins->reg_types[RS2] = ts2;
    ins->reg_types[RD] = td;
}

static void Cformat(char *inst, struct inst *ins)  // rd, rs1
{
    int i = 0,rd,rs1;
    REG_TYPE td, ts1;

    /* Extract rd */
    td = extract_reg (inst, &i, &rd);
    skip_spaces_comma(inst, &i);

     /* Extract rs1 */
    ts1 = extract_reg (inst, &i, &rs1);
    
    /* fill the instruction */
    ins->rs1 = rs1;
    ins->rd = rd;

    /* fill the reg types */
    ins->reg_types[RS1] = ts1;
    ins->reg_types[RD] = td;
}


static void FRformat(char *inst, struct inst *ins)  // rd, rs1, rs2, rs3
{
    int i = 0,rd,rs1,rs2, rs3;
    REG_TYPE td, ts1, ts2, ts3;

    /* Extract rd */
    td = extract_reg (inst, &i, &rd);
    skip_spaces_comma(inst, &i);

     /* Extract rs1 */
    ts1 = extract_reg (inst, &i, &rs1);
    skip_spaces_comma(inst, &i);
    
    // extract rs2
    ts2 = extract_reg (inst, &i, &rs2);
    skip_spaces_comma(inst, &i);

    // extract rs3
    ts3 = extract_reg (inst, &i, &rs3);

    // fill the instruction
    ins->rs1 = rs1;
    ins->rs2 = rs2; 
    ins->rs3 = rs3;
    ins->rd = rd;

    if (td == FP_REG && ts1 == FP_REG && ts2 == FP_REG && ts3 == FP_REG) return;
    else {
        printf ("2. We expect only integer registers. \n");
        invalidInst();
    }

    ins->reg_types[RD] = td;
    ins->reg_types[RS1] = ts1;
    ins->reg_types[RS2] = ts2;
    ins->reg_types[RS3] = ts3;
}

static void Iformat(char *inst, struct inst* ins)  // rd, rs1, imm
{
    int i = 0, rd, rs1, imm;
    REG_TYPE td, ts1;

    /* Extract rd */
    td = extract_reg (inst, &i, &rd);
    skip_spaces_comma(inst, &i);

     /* Extract rs1 */
    ts1 = extract_reg (inst, &i, &rs1);
    skip_spaces_comma(inst, &i);
    
    /* extract rs2 */
    imm = extract_imm (inst, &i); 

    /* fill the instruction */
    ins->rs1 = rs1;
    ins->imm = imm; 
    ins->rd = rd;

    if (td != INT_REG && ts1 != INT_REG) {
        printf ("3. We expect only integer registers. \n");
        invalidInst();
    }

    /* fill the types */
    ins->reg_types[RD] = td;
    ins->reg_types[RS1] = ts1;
}

static void ILformat (char *inst, struct inst* ins)  // rd, imm(rs1)
{
    int i = 0, rd, imm, rs1;
    REG_TYPE td, ts1;

    /* Extract rd */
    td = extract_reg (inst, &i, &rd);
    skip_spaces_comma(inst, &i);

    /* find the immediate */
    imm = extract_imm(inst, &i);
    left_paren_check(inst, &i);

    /* Extract rs1 */
    ts1 = extract_reg (inst, &i, &rs1);

    /* fill the instruction */
    ins->rs1 = rs1;
    ins->imm = imm; 
    ins->rd = rd;

    if (ts1 != INT_REG) {
        printf ("4. We expect only integer registers. \n");
        invalidInst();
    }

    /* fill the types */
    ins->reg_types[RD] = td;
    ins->reg_types[RS1] = ts1; 
}

static void Uformat (char *inst, struct inst* ins)   // rd, imm/label
{
    int i = 0,rd, imm;
    REG_TYPE td;

    /* Extract rd */
    td = extract_reg (inst, &i, &rd);
    skip_spaces_comma(inst, &i);

    /* Extract PC */
    char *label = extract_pc(inst, &i, &imm); 

    /* pack in the instruction */
    ins->rd = rd;
    if (label == NULL) ins->imm = imm;
    else ins->jump_label = label;

    if (td != INT_REG) {
        printf ("5. We expect only integer registers. \n");
        invalidInst();
    }

    /* fill reg types */
    ins->reg_types[RD] = td;
}

static void Bformat (char *inst, struct inst* ins)  // rs1, rs2, imm/label
{
    int i = 0, rs1, rs2, imm;
    REG_TYPE ts1, ts2;

    /* Extract rs1 */
    ts1 = extract_reg (inst, &i, &rs1);
    skip_spaces_comma(inst, &i);

    /* Extract rs2 */
    ts2 = extract_reg (inst, &i, &rs2);
    skip_spaces_comma(inst, &i);

    /* Extract PC */
    char* label = extract_pc(inst, &i, &imm); 

    /* pack in the instruction */
    ins->rs1 = rs1;
    ins->rs2 = rs2;
    if(label == NULL) ins->imm = imm;
    else ins->jump_label = label;

    if (ts1 != INT_REG && ts2 != INT_REG) {
        printf ("6. We expect only integer registers. \n");
        invalidInst();
    }

    /* fill reg types */
    ins->reg_types[RS1] = ts1;
    ins->reg_types[RS2] = ts2;
}

static void Lformat (char *inst, struct inst* ins) {  /* rd, label */
	/* Extract rd */
	int rd, i = 0; REG_TYPE td;

    	td = extract_reg (inst, &i, &rd);
    	ins->rd = rd; 
	
	if (td != INT_REG) {
		printf ("7. Expect an integer register here.\n");
		invalidInst();
	}

    	/* go to the variable */	
	skip_spaces_comma(inst, &i);

	/* extract the variable's address */
	char *var = extract_term(inst+i);
	int imm = find_address(var);
	ins->imm = imm;

	/* fill reg types */
	ins->reg_types[RD] = td;
}

static void Pformat (char *inst, struct inst* ins) {  /* rs1 */
    int rs1,i=0; 
    REG_TYPE ts1;

    /* Extract rs1 */
    ts1 = extract_reg (inst, &i, &rs1);
    ins->rs1 = rs1; 

    /* set the type */
    ins->reg_types[RS1] = ts1;
}

/* main parsing routines */
static struct inst* parse_line (char line[MAXCHARS]){
	if (is_empty(line)) return NULL;
	if (is_comment(line)) return NULL;
	if (is_constant(line)) {
		process_constant(line);
		return NULL;
	}
	char *rest = line;


	char *label = find_lbl_point(line, &rest);
	if (label != NULL) { 
	 	if (old_label != NULL) {
			printf("You cannot have two consecutive labels with no instructions: %s and %s\n",label, old_label); 
			invalidInst();
		}
	        rest++;
	}
	if (is_empty(rest)) {
		old_label = label; /* save to be used later */
	        return NULL;
	}
	
	/* find the instruction opcode */
	int idx = 0,cnt=0;
	char op[16];
	int SPACE = 1, OP = 2;
	int state = SPACE;

	for (idx=0; idx < strlen (rest); idx++){
		if (isspace(rest[idx]) && (state == SPACE))
			continue;
		else if (!isspace(rest[idx]) && (state == SPACE)) {
			state = OP;
			op[cnt++] = rest[idx]; 
		}
		else if(state == OP){
			if (isspace(rest[idx])) break;
			op[cnt++] = rest[idx];
		}
	}

	rest = rest + idx;
	op[cnt] = '\0';
	lower_case(op); 
	inst_type it = get_inst_type(op); 

	/* create the instruction */
	struct inst* ins = create_inst();
	ins->code = it.code; 
	ins->pc = current_pc; 
	current_pc += 4; /* 4-byte instruction */

	/* tag an instruction with the label */
	assert( (label == NULL) || (old_label == NULL)); /* both cannot be non-null */  
	int flag = 0;
	if (label != NULL) { /* current instruction */
		ins->label = label;
		label = NULL; 
		flag = 1;
	} else if (old_label != NULL) {
		ins->label = old_label; 
		old_label = NULL;
		flag = 1;
	} 
	if (flag) {
		labelpc lpc = {ins->label, ins->pc};
		global.program->labelpcs[global.program->numlabels++] = lpc;
	}

	/* Take a decision based on the instruction type */
	switch (it.type){
	case T_R: 
		Rformat(rest, ins);
		break;
    case T_C:
        Cformat (rest, ins);
        break;
    case T_FR:
        FRformat (rest, ins);
		break;
	case T_S: 
    case T_SF:
	    Sformat(rest,ins);
	    break;
	case T_I: 
	    Iformat(rest,ins); 
	    break;
	case T_IL:
    case T_ILF:
		  ILformat (rest,ins);
		  break;
	case T_U: 
		  Uformat(rest, ins);
		  break;
	case T_B:
		  Bformat (rest, ins);
		  break;
	case T_END: break;
	case T_P: 
		    Pformat (rest, ins); 
		    break;
	case T_L:
		    Lformat(rest, ins);
		    break;
	default: 
	      printf ("Invalid type %d\n",it.type);
	      invalidInst();
	}

	/* return the instruction */
	return ins;
}

/* function that is called from outside */
void parse(FILE *fptr) {
	/* initialize the program */
	struct program* prog = global.program;

	/* parse the text file */
	char line[MAXCHARS];
	while (fgets(line, sizeof(line), fptr)) {
        	struct inst* ins = parse_line(line);
		line_count++;
		if (ins != NULL) {
			prog->insts[prog->numinsts++] = ins;		
		}
	}
}

void print_program() {
	struct program* prog = global.program;

	printf("main pc = %d\n",prog->mainpc);
	for (int i=0; i < prog->numinsts ; i++){
		print_inst(prog->insts[i]);
	}
}

void fix_end() {
	struct program* prog = global.program;
	if (prog->numinsts == 0) return;
	struct inst *ins = prog->insts[prog->numinsts - 1]; /* last instruction */
	int code = ins->code; 
	inst_type it = allinsts[code]; 
	if ( (it.type != T_END) || (old_label != NULL) ) {
		/* insert new instruction */
		printf ("inserting end\n");
		struct inst *ninst = create_inst();
		ninst->code = 0; 
		if (old_label != NULL) ninst->label = old_label; 

		prog->insts[prog->numinsts++] = ninst;
	}
}

void fix_labels() {
	struct program* prog = global.program;
	int main_set = 0;

	/* fix all the labels */
	for (int i=0; i < prog->numinsts; i++) {
		struct inst* ins = prog->insts[i]; 

		if (ins->label != NULL) {	
			if (!strcmp(ins->label, ".main")) { 
				prog->mainpc = ins->pc; 
				main_set++;
			}
		}

		if (ins->jump_label == NULL) continue;
		else  ins->imm = find_pc(ins->jump_label, prog, i) - ins->pc;  /* offset */
	}

	if (!main_set) {
		printf("Could not find the .main label in the program. The execution starts from there. \n");
		exit(1);
	} else if (main_set > 1) {
		printf("Multiple .main labels. This is not allowed. Only one. \n");
		exit(1);

	}
}