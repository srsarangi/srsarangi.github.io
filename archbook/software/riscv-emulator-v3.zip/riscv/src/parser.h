#include <stdio.h>

#ifndef PARSER_H 
#define PARSER_H 

#define END_CODE 0

typedef enum {
    INT_REG, 
    FP_REG 
} REG_TYPE;

typedef enum {
    RS1=0, 
    RS2=1,
    RS3=2,
    RD=2
} REG_NUM;

struct inst {
	int code;   /* opcode of the instruction */
    	REG_TYPE reg_types [4]; 
	int rs1; 
	int rs2; 
    	int rs3;
	int rd; 
	int imm;
	int pc;    /* pc */
	char *label; /* label associated with the instruction */
	char *jump_label; /* label to jump to */
};

#define MAXINSTS 512
typedef struct {
	char *label;
	int pc;
} labelpc;

struct program {
	int numinsts; 
	int numlabels;
	int mainpc;
	struct inst* insts[MAXINSTS]; 
	labelpc labelpcs[MAXINSTS]; 
}; 

typedef enum {
	T_END, 
	T_R,
	T_S,
	T_I,
	T_IL,
	T_U,
	T_B,
	T_FR,
	T_P,
    	T_SF,
    	T_ILF,
    	T_C,    
	T_L
} TYPE; 

typedef struct {
	char *op;
	int code;
	TYPE type;
	void (*func) (struct inst* inst);
} inst_type;


extern void parse();
extern char* get_mnemonic(int id);
extern char* get_fp_mnemonic(int id);
extern void parser_init();
extern void fix_end();
extern void fix_labels();
extern void print_program(); 
extern void print_inst(struct inst*);
extern inst_type get_inst_by_code(int code);
extern void print_all_constants();
extern void invalidInst();
#endif
