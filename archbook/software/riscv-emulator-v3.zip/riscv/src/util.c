#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <unistd.h>
#include <string.h>
#include <assert.h>
#include "parser.h"
#include "util.h"

#define LABELMAX 32

/* line parsing related, utility functions */
void skip_spaces(char *inst, int *idx){
	while(inst[*idx] == ' ' || inst[*idx] == '\t')
		*idx = *idx + 1;
}
void skip_spaces_comma(char *inst, int *idx){
	skip_spaces(inst,idx);
	if (inst[*idx] != ',') {
        printf("Could not find a comma in line: %s\n",inst);
		invalidInst();
    }
	*idx = *idx + 1;
	skip_spaces(inst,idx);
}

int is_imm(char *inst, int i){
	return isdigit(inst[i]); 
}

int is_empty(char *line){
	int i;
	for (i=0; i < strlen(line); i++){
		if(! isspace(line[i])) return 0;
	}
	return 1;
}

int is_comment (char *line){
	int i;
	for (i=0; i < strlen(line); i++){
		if(isspace(line[i])) continue;
		if(line[i] == '#') return 1;
		else if(line[i] == '@') return 1;
		else return 0;
	}
	return 0;
}

int is_constant (char *line){
	if(strstr(line,".word")) return 1;
	if(strstr(line,".float")) return 1;
	return 0;
}

void left_paren_check(char *inst, int *idx){
    skip_spaces(inst, idx);

    if (inst[*idx] != '(')  {
        printf("Could not find the left parenthesis: %s\n",inst);
	    invalidInst();
    }
    *idx = *idx + 1; 
}

void lower_case (char *line){
	int i = 0;
	for (i=0; i < strlen(line); i++){
		line[i] = tolower(line[i]); 
	}
}

/* Extract term, label, register, immediate and PC */
char* find_lbl_point (char *line, char** col_pt){
	char *cpt = strchr(line, ':');
	if (cpt == NULL) return NULL;
	char* label = (char*) malloc(LABELMAX);
	int lblpt=0;
	
	/* extract the label */
	int cnt = 0;
	for (char *ptr = line; ptr < cpt; ptr++) {
		if (isspace(*ptr)) continue;
		label[lblpt++] = *ptr;
	}
	label[lblpt] = '\0';

	*col_pt = cpt;
	return label;
}

char* extract_term (char* line){
	int i=0;
	skip_spaces(line,&i);
	line = line + i;

	char* label = (char *) malloc(LABELMAX);
	int cnt = 0;
	char c;
	while(1){
		c = *(line + cnt);
		if(isspace(c))
			break;
		label[cnt++] = c;
	}
	label[cnt] = '\0';
	return label;
}

REG_TYPE extract_reg(char* inst, int *i, int *p){
    skip_spaces(inst, i); 
    char c, d, e;

    /* fp */
    if (!strncmp(&inst[*i], "fp", 2)){
        *p = 8;
        *i = *i + 2;
        return INT_REG;
    }

    /* x0 to x31 */
    if(inst[*i] == 'x') {
	    c = inst[*i + 1];
	    d = inst[*i + 2];
	    if (!isdigit(c)) {
            printf("Expected a digit here %s\n",inst);
		    invalidInst();
        }
	    int cnt = (isdigit(d))? 1:0 ;

	    if(cnt)
		    *p = (c - '0')*10 + (d-'0');
	    else
		    *p = (c - '0');

	    if (*p < 0 || *p > 31) {
            printf("Invalid register number %d\n",*p);
		    invalidInst();
        }

    	*i = *i + 2 + cnt; 
    	return INT_REG;
    }

    /* f0 to f31 */
    if(inst[*i] == 'f'){
        c = inst[*i+1];
        d = inst[*i+2];
        e = inst[*i+3];
        int n, cnt = 0;

        if (isdigit(c)){
            n = c - '0';       /* first digit */
            if (isdigit(d)) {        /* second digit is also a number */
                n = 10*n + d - '0';
                cnt = 1;
            }
            *p = n;

	        if (*p < 0 || *p > 31) {   /* check */
                printf("Invalid register number %d\n",*p);
		        invalidInst();
            }

    	    *i = *i + 2 + cnt; 
    	    return FP_REG;             /* it is an fp */
        } else {
            if (c != 'a' && c != 's' && c != 't') { 
                printf("Invalid register character specifier %c \n",c);
                invalidInst();
            }

            /* find the number */
            if (!isdigit(d)) { 
                printf("1. Invalid floating point register in line: %s\n",inst);
                invalidInst();
            }
            n = d - '0'; 
            if (isdigit(e)){
                n = 10 * n + e - '0';
                cnt = 1;
            }
            if (n < 0){ 
                printf("2. Invalid floating point register in line: %s\n",inst);
                invalidInst();
            }

            /* move the pointer */
            *i = *i + 3 + cnt; 

            /* process the number */
            if (c == 't' && n <= 7) *p = n; 
            else if (c == 's' && n <= 1) *p = 8 + n; 
            else if (c == 'a' && n <= 7) *p = 10 + n; 
            else if (c == 's' && n <= 11) *p = 18 + n - 2;
            else if (c == 't' && n <= 11)  *p = 28 + n - 8; 
            else { 
                printf("3. Invalid floating point register %s\n",inst);
                invalidInst();
            }

            return FP_REG;
        }
    }

    /* zero */
    if(!strncmp(&inst[*i], "zero", 4)) {
            *p = 0; 
            *i = *i + 4; 
            return INT_REG;
    }

    /* ra */
    if(!strncmp(&inst[*i], "ra", 2)) {
        *p = 1;
        *i = *i + 2;
        return INT_REG;
    }

    /* sp */
    if(!strncmp(&inst[*i], "sp", 2)) {
        *p = 2;
        *i = *i + 2;
        return INT_REG;
    }

    /* gp */
    if(!strncmp(&inst[*i], "gp", 2)) {
        *p = 3;
        *i = *i + 2;
        return INT_REG;
    }

    /* tp */
    if(!strncmp(&inst[*i], "tp", 2)) {
        *p = 4;
        *i = *i + 2;
        return INT_REG;
    }

    /* t0-2 */
    if(inst[*i] == 't' && (inst[*i+1] == '0' || inst[*i+1] == '1' || inst[*i+1] == '2')) {
        *p = 5 + (inst[*i+1] - '0');
        *i = *i + 2;
        return INT_REG;
    }

    /* s0/s1 */
    if( (inst[*i] == 's') && ((inst[*i+1] == '0') || (inst[*i+1] == '1'))) {
        *p = 8 + (inst[*i+1] - '0');
        *i = *i + 2;
        return INT_REG;
    }

   /* a0-7 */ 
    if(inst[*i] == 'a') {
        *p = 10 + (inst[*i+1] - '0');
        *i = *i + 2;
        if (*p < 10 || *p > 17) {
            printf("1. Invalid integer register number (a series) %d\n",*p);
            invalidInst();
        }
        return INT_REG;
    }


    /* s2-11 */
    if(inst[*i] == 's' && (inst[*i+1] - '2' >= 0)) {
        *p = 18 + (inst[*i+1] - '2');
        *i = *i + 2;
        if (*p < 18 || *p > 27){
            printf("2. Invalid integer register number (s series) %d\n",*p);
            invalidInst();
        }
        return INT_REG;
    }

    /* t3-6 */
    if(inst[*i] == 't' && (inst[*i+1] - '3' >= 0)) {
        *p = 28 + (inst[*i+1] - '3');
        *i = *i + 2;
        if (*p < 28 || *p > 31) {
            printf("3. Invalid integer register number (t series) %d\n",*p);
            invalidInst();
        }
        return INT_REG;
    }

    /* should not come here */
    printf("Could not resolve integer register %s\n",inst);
    invalidInst();
}

int extract_imm (char *inst, int *idx) { 
	skip_spaces(inst, idx);

	char* s = inst + *idx;
	if (s[0] == '(') return 0;
	int base = 10;
	if (s[0] == '0') {
	    if(tolower(s[1]) == 'x') {
		base = 16;
		*idx = *idx + 2;
	    }
	    else {
		    base = 8;
		    *idx = *idx + 1;
	    }
	}
	if (s[0] == '-')
		*idx = *idx + 1;
	
	/* go till the end */
	while (isdigit(inst[*idx])) 
            *idx = *idx + 1; 	

	int val = (int) strtol(s, NULL, base);
	return val;
}

char* extract_pc(char *inst, int* idx, int *imm){
    if (is_imm (inst, *idx)) {
	   *imm = extract_imm(inst, idx);
	   return NULL;
    }
    else {
          char* label = (char*) malloc(LABELMAX);
	  int cnt = 0;
	  skip_spaces(inst, idx);
	  while(1) {
		if(isspace(inst[*idx])) break;
		label[cnt++] = inst[*idx];  /* fill the characters in label */
		*idx = *idx + 1;	
	  }
	  label[cnt] = '\0';
	  return label;
    }
}
