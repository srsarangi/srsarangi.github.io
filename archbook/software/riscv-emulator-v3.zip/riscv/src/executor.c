#include "global.h"
#include <assert.h>
#include <stdlib.h>

void execute(){
	struct program *prog = global.program;
	int pc = prog->mainpc; /* start from the main func */

	int dyn_inst_cnt = 0;
	while(1){
		dyn_inst_cnt++;
	
		/* fetch the instruction */
		int num = pc / 4;
		struct inst* ins = prog->insts[num]; 
		inst_type it = get_inst_by_code(ins->code);
		
		/* execute it */
		it.func(ins); 

		/* set the pc */
		if (global.taken_branch) {
			global.taken_branch = 0;
			pc = global.next_pc;
		} else {
			pc = pc + 4;
		}
	}
}
