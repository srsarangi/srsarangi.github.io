#include "parser.h"
#include "insts.h"
#include "global.h"

void BGE(struct inst* ins)  
{
	int newpc = ins->pc + ins->imm; 
	if(global.xregs[ins->rs1] >= global.xregs[ins->rs2]) {
		global.taken_branch = 1;
		global.next_pc = newpc;
	}
}

void BEQ(struct inst* ins)  
{
	int newpc = ins->pc + ins->imm; 
	if(global.xregs[ins->rs1] == global.xregs[ins->rs2]) {
		global.taken_branch = 1;
		global.next_pc = newpc;
	}
}

void BNE(struct inst* ins)  
{
	int newpc = ins->pc + ins->imm; 
	if(global.xregs[ins->rs1] != global.xregs[ins->rs2]) {
		global.taken_branch = 1;
		global.next_pc = newpc;
	}
}

void BLT(struct inst* ins)  
{
	int newpc = ins->pc + ins->imm; 
	if(global.xregs[ins->rs1] < global.xregs[ins->rs2]){
		global.taken_branch = 1;
		global.next_pc = newpc;
	}

}

void BGEU(struct inst* ins)  
{
	int newpc = ins->pc + ins->imm; 
	if( ((unsigned) global.xregs[ins->rs1]) >=  ((unsigned)global.xregs[ins->rs2])) {
		global.taken_branch = 1;
		global.next_pc = newpc;
	}
}

void BLTU(struct inst* ins)  
{
	int newpc = ins->pc + ins->imm; 
	if( ((unsigned) global.xregs[ins->rs1]) < ((unsigned) global.xregs[ins->rs2])) {
		global.taken_branch = 1;
		global.next_pc = newpc;
	}

}

void JAL(struct inst* ins)  
{
	int newpc = ins->pc + ins->imm; 
	if (ins->rd != 0) 
		global.xregs[ins->rd] = ins->pc + 4;
	global.taken_branch = 1;
	global.next_pc = newpc;
}

void JALR(struct inst* ins)  
{
	if(ins->rd != 0) {
		global.xregs[ins->rd] = ins->pc + 4;
	}
	global.taken_branch = 1;
	global.next_pc = global.xregs[ins->rs1] + ins->imm;
}
