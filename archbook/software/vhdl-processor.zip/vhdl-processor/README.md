Processor
=========

Single cycle processor design in VHDL that implements simpleRisc ISA. 

SimpleRisc ISA is a reduced instruction set which is similar to ARM ISA.

to run, type `$ ./run.sh <input_machine_code_file>` in your command line