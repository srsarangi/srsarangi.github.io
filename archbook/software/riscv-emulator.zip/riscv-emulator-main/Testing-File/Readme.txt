Here some assembly programs are stored for testing purposes.
