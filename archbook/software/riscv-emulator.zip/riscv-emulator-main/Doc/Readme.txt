Here details about the riscem emulator are stored in multiple files.
