#include "parser.h"

#ifndef INSTS_H 
#define INSTS_H 

extern void ADD (struct inst* ins);
extern void ADDI (struct inst* ins);
extern void SUB (struct inst* ins);
extern void MUL (struct inst* ins);
extern void DIV (struct inst* ins);
extern void REM (struct inst* ins);
extern void END (struct inst* ins);
extern void PRINT (struct inst* ins);
extern void BGE (struct inst* ins);
extern void BEQ (struct inst* ins);
extern void BNE (struct inst* ins);
extern void BLT (struct inst* ins);
extern void BGEU (struct inst* ins);
extern void BLTU (struct inst* ins);
extern void JAL (struct inst* ins);
extern void JALR (struct inst* ins);
extern void LOADW (struct inst* ins);
extern void STOREW (struct inst* ins);

extern void LUI (struct inst *ins);
extern void LI (struct inst *ins);
extern void LA (struct inst *ins);
extern void REMU(struct inst* ins);  
extern void DIVU(struct inst* ins);  
extern void MULHSU(struct inst* ins);
extern void MULHU(struct inst* ins);
extern void MULH(struct inst* ins);  

extern void LOADB(struct inst* ins);  
extern void LOADH(struct inst* ins);
extern void STOREB(struct inst* ins);
extern void STOREH(struct inst* ins);  

extern void XOR(struct inst* ins);  
extern void XORI (struct inst* ins);  
extern void OR(struct inst* ins);  
extern void ORI (struct inst* ins);  
extern void AND(struct inst* ins);  
extern void ANDI (struct inst* ins);  

extern void SLT(struct inst* ins);
extern void SLTI(struct inst* ins);
extern void SLTU(struct inst* ins);
extern void SLTIU(struct inst* ins);
extern void SLL(struct inst* ins);
extern void SLLI(struct inst* ins);
extern void SRA(struct inst* ins);
extern void SRAI(struct inst* ins);
extern void SRL(struct inst* ins);
extern void SRLI(struct inst* ins);

extern void FLW(struct inst* ins);  
extern void FSW(struct inst* ins);

extern void FADD(struct inst* ins);  
extern void FSUB(struct inst* ins);
extern void FMUL(struct inst* ins);  
extern void FDIV(struct inst* ins);
extern void FMIN(struct inst* ins);  
extern void FMAX(struct inst* ins);
extern void FSQRT(struct inst* ins);
extern void FMADDS(struct inst* ins);  
extern void FMSUBS(struct inst* ins);
extern void FCVTSW(struct inst* ins);
extern void FCVTWS(struct inst* ins);
extern void FLTS(struct inst* ins);
extern void FLES(struct inst* ins);
extern void FEQS(struct inst* ins);


#endif
