#include "parser.h"
#include "insts.h"
#include "global.h"

void XOR(struct inst* ins)  {
    global.xregs[ins->rd] = global.xregs[ins->rs1] ^ global.xregs[ins->rs2];
}
void OR(struct inst* ins)  {
    global.xregs[ins->rd] = global.xregs[ins->rs1] | global.xregs[ins->rs2];
}
void AND(struct inst* ins)  {
    global.xregs[ins->rd] = global.xregs[ins->rs1] & global.xregs[ins->rs2];
}


void XORI(struct inst* ins) {
    global.xregs[ins->rd] = global.xregs[ins->rs1] ^ ins->imm;
}
void ORI(struct inst* ins) {
    global.xregs[ins->rd] = global.xregs[ins->rs1] | ins->imm;
}
void ANDI(struct inst* ins) {
    global.xregs[ins->rd] = global.xregs[ins->rs1] & ins->imm;
}

void SLT(struct inst* ins){
    if(global.xregs[ins->rs1] < global.xregs[ins->rs2])
        global.xregs[ins->rd] = 1;
    else 
        global.xregs[ins->rd] = 0;
}

void SLTI(struct inst* ins){
    if(global.xregs[ins->rs1] < ins->imm)
        global.xregs[ins->rd] = 1;
    else 
        global.xregs[ins->rd] = 0;
}

void SLTU(struct inst* ins){
    if( ((unsigned) global.xregs[ins->rs1]) < ((unsigned)global.xregs[ins->rs2]))
        global.xregs[ins->rd] = 1;
    else 
        global.xregs[ins->rd] = 0;

}
void SLTIU(struct inst* ins){
    if(((unsigned)global.xregs[ins->rs1]) < ((unsigned) ins->imm))
        global.xregs[ins->rd] = 1;
    else 
        global.xregs[ins->rd] = 0;

}

void SLL(struct inst* ins){
    global.xregs[ins->rd] = global.xregs[ins->rs1] << global.xregs[ins->rs2];
}

void SLLI(struct inst* ins){
    global.xregs[ins->rd] = global.xregs[ins->rs1] << ins->imm;
}

void SRA(struct inst* ins){
    global.xregs[ins->rd] = global.xregs[ins->rs1] >> global.xregs[ins->rs2];
}

void SRAI(struct inst* ins){
    global.xregs[ins->rd] = global.xregs[ins->rs1] >> ins->imm;
}

void SRL(struct inst* ins){
    unsigned int x = global.xregs[ins->rs1];
    global.xregs[ins->rd] = (unsigned) (x  >> global.xregs[ins->rs2]);
}

void SRLI(struct inst* ins){
    unsigned int x = global.xregs[ins->rs1];
    global.xregs[ins->rd] = (unsigned) (x  >> ins->imm);
}
