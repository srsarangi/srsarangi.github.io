#include "parser.h"
#include "insts.h"
#include "global.h"

void LOADW (struct inst* ins)  
{
	int addr = ins->imm + global.xregs[ins->rs1]; 
	int* val = (int*) &(global.mem[addr]);
	global.xregs[ins->rd] = *val; 
}

void FLW (struct inst* ins) {
	int addr = ins->imm + global.xregs[ins->rs1]; 
	float* ptr = (float*) &(global.mem[addr]);
	global.fpregs[ins->rd] = *ptr; 
}

void LOADB (struct inst* ins)  
{
	int addr = ins->imm + global.xregs[ins->rs1]; 
	char* val = (char*) &(global.mem[addr]);
	global.xregs[ins->rd] = (char) *val; 
}
void LOADH (struct inst* ins)  
{
	int addr = ins->imm + global.xregs[ins->rs1]; 
	short* val = (short*) &(global.mem[addr]);
	global.xregs[ins->rd] = (short) *val; 
}

void STOREW (struct inst* ins)  
{
	int addr = ins->imm + global.xregs[ins->rs1]; 
	int* val = (int*) &(global.mem[addr]);
	*val = global.xregs[ins->rs2];
}

void FSW(struct inst* ins)  
{
	int addr = ins->imm + global.xregs[ins->rs1]; 
	float* ptr = (float*) &(global.mem[addr]);
	*ptr = global.fpregs[ins->rs2];
}

void STOREB (struct inst* ins)  
{
	int addr = ins->imm + global.xregs[ins->rs1]; 
	char* val = (char*) &(global.mem[addr]);
	*val = (char) (global.xregs[ins->rs2] & 0xFF);
}

void STOREH (struct inst* ins)  
{
	int addr = ins->imm + global.xregs[ins->rs1]; 
	short* val = (short*) &(global.mem[addr]);
	*val = (short) (global.xregs[ins->rs2] & 0xFFFF);
}
