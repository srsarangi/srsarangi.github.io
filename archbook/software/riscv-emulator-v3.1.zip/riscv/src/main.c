#include <stdio.h>
#include <stdlib.h>
#include "parser.h"
#include "global.h"

struct global global; 

void init_global(){
	int i;

	/* initialize the global state */
	for(i=0; i < 32; i++) {
		global.xregs[i] = 0;
        global.fpregs[i] = 0;
    }
	for(i=0; i < MEMSIZE; i++)
		global.mem[i] = 0;

	/* set the stack pointer */
	global.xregs[2] = MEMSIZE - 4; /* multiple of 4 */

	/* set the program */
	global.program = (struct program *) malloc(sizeof(struct program)); 
	global.program->numinsts = 0;
	global.program->numlabels = 0; 
	global.program->mainpc = -1;
	global.next_pc = -1;
	global.taken_branch = 0;
	global.num_constants = 0;
}

int main(int argc, char* argv[]) {
	/* initialize the global state */
	init_global();
	parser_init();

	/* verify and parse the file */
	FILE* fptr = fopen(argv[1], "r");		
	if(fptr == NULL)
	{
		printf("Could not read the file %s \n",argv[1]);
		exit(0);
	}
	parse(fptr);        /* parse */
	fclose(fptr);

	/* make fixes to the parsed output */
	fix_end();      /* add an end instruction (if not there) */
	fix_labels();   /* resolve all labels */

	/* execute */
	execute();
}
