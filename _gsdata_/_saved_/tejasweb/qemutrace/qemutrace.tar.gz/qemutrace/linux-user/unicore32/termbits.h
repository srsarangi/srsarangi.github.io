/* NOTE: exactly the same as i386 */
#include "../i386/termbits.h"
