/*
 * Copyright (C) 2010-2011 GUAN Xue-tao
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 */
#ifndef UNICORE32_TARGET_SIGNAL_H
#define UNICORE32_TARGET_SIGNAL_H

/* this struct defines a stack used during syscall handling */
typedef struct target_sigaltstack {
    abi_ulong ss_sp;
    abi_ulong ss_flags;
    abi_ulong ss_size;
} target_stack_t;

/*
 * sigaltstack controls
 */
#define TARGET_SS_ONSTACK               1
#define TARGET_SS_DISABLE               2

static inline abi_ulong get_sp_from_cpustate(CPUUniCore32State *state)
{
    return state->regs[29];
}


#endif /* UNICORE32_TARGET_SIGNAL_H */
