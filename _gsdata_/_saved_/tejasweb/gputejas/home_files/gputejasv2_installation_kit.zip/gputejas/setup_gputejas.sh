#!/bin/bash

echo ""
#echo "This will guide you through the installation of GPU Ocelot required to run GPU Tejas"
#echo ""

#--- validating the arguments
if [ $# -lt 1 ];
then
	echo "ERROR: Missing arguments"
	echo "Usage: ./setup_gputejas.sh setup/genTrace/run/clean/make-jar [benchmark .o files path]"
	echo "exiting..."
	echo ""
	exit 1	
fi


if [ $1 = 'make-jar' ]
then
	echo "ANT BUILD"
	echo "- - - - - - - - - - - - - - - -"
	echo ""

	echo "cd gputejas"
	cd gputejas

	echo ""
	echo "ant clean"
	ant clean
	
	echo ""
	echo "ant"
	ant
	
	echo ""
	echo "ant make-jar"
	ant make-jar
	
	echo "ant make-tracesimplifier"
	ant make-tracesimplifier

	echo ""
	echo "--- Done with making the jar ---"
	exit 0
fi

if [ $1 = 'setup' ]
then
	echo ""
	echo "SETTING UP THE RESOURCES"
	echo "- - - - - - - - - - - - - - - -"

	echo ""
	echo "Please make sure you meet the following requirements:"
	echo "GPU with SM compute capability: >= 3.5 && <= 8.6"
	echo "OS: Linux"
	echo "Java: version >=8.x"
	echo "GCC version: >= 5.3.0"
	echo "CUDA version: >= 8.0 && <= 11.x"
	echo "nvcc version for tool compilation >= 10.2"
	echo "press enter to continue: "
	read key

	gccVers=`gcc --version | head -n 1 | cut -d ' ' -f4 | cut -d '.' -f1`
	echo "GCC major version on system: $gccVers"

	if [[ $gccVers -lt 6 ]]
	then
		echo "Version not compatible: gcc"
		exit 1
	fi

	computeCap=`nvidia-smi --query-gpu=compute_cap --format=csv | tail -n 1 | cut -d '.' -f1`
	echo "GPU compute capability: $computeCap"

	if [[ $computeCap -lt 4 ]]
	then
		echo "Version not compatible: compute capability"
		exit 1
	fi

	nvccVer=`nvcc --version | head -n 4 | tail -n 1 | cut -d ' ' -f5 | cut -d '.' -f1`
	echo "CUDA major Compiler version: $nvccVer"

	if [[ $nvccVer -lt 10 ]]
	then
		echo "Version not compatible: nvcc "
		exit 1
	fi

	# exit 1

    cd nvbit_tools/tools
    make
    cd ../..
	
	echo "cd gputejas"
	cd gputejas

	echo "ant clean"
	ant clean

	echo "ant"
	ant

	echo "ant make-jar"
	ant make-jar
	
	echo "ant make-tracesimplifier"
	ant make-tracesimplifier


	echo ""
	echo "--- Done with the setup!!! ---"
	exit 0
fi

if [ $1 = 'make-example' ]
then
		cd nvbit_tools/test-apps/vectoradd/
        make clean
        make
        cd ../..
fi

if [ $1 = 'genTrace' ]
then

	echo ""
	echo "GENERATING THE TRACES"
	echo "- - - - - - - - - - - - - - - -"
	
	echo ""
	echo "-----------------Cleaning the temporary files-----------"
    rm -rf traces

	CWD="$(pwd)"
    echo "Current working dir : $CWD"

	echo "Path to benchmark executable : $2"
	read bench_path
	echo $bench_path
	# bench_path=/home/yashashwee/OtherProgs/gputejas/nvbit_tools/test-apps/vectoradd/vectoradd
	
	echo "Enter the full path of config file: "
	read configPath
	echo $configPath
    # configPath=/home/yashashwee/OtherProgs/gputejas/gputejas/src/simulator/config/config.xml
	
    threadNum=`grep -o '<MaxNumJavaThreads>.*</MaxNumJavaThreads>' $configPath | cut -d'<' -f 2 | cut -d'>' -f 2`

	#--- removing the $threadNum directory if present
	rm -rf $threadNum 2>/dev/null 
	
   	echo "Please enter the arguments to run the benchmark"
   	read args	
    echo $args

    cmdTracerTool="LD_PRELOAD=$CWD/nvbit_tools/tools/tracer_tool/tracer_tool.so $bench_path $args"
    echo "$cmdTracerTool"
    echo "$cmdTracerTool" | bash

    rm -rf "traces/$threadNum"
    mkdir "traces/$threadNum"
    noKerns=$(wc -l < traces/stats.csv)
    noKerns="$(($noKerns - 1))"
    # echo $noKerns   
    
    cmdProcessTrace="./nvbit_tools/tools/tracer_tool/traces-processing/post-traces-processing traces/kernelslist"
    echo $cmdProcessTrace | bash

    #Split traces into threads
    cmdSplitTrace="./nvbit_tools/tools/tracer_tool/traces-processing/split_trace traces $threadNum"
    echo $cmdSplitTrace | bash

    mv "traces/$threadNum" .

    cd gputejas

    echo "java -jar jars/Tracesimplifier.jar $configPath tmp $CWD $noKerns"
    
    if !(java -jar jars/Tracesimplifier.jar $configPath tmp $CWD $noKerns) then
		echo "Problem with simplifying the traces, please try again, exiting..."
		echo ""
		exit 1
	fi
    
    cd ..
	
fi



if [ $1 = 'run' ]
then
	echo "RUNNING THE BENCHMARK"
	echo "- - - - - - - - - - - - - - - -"
	echo ""

	echo "Enter the path of config file (absolute path): "
	read configPath
	echo $configPath
	
	# configPath=/home/yashashwee/gputejas/gputejas/src/simulator/config/config.xml
	echo "Enter the path of output file: "
	read outputFile
	echo $outputFile

	#configPath=gputejas/src/simulator/config/config.xml
	# outputFile=output.txt
	threadNum=`grep -o '<MaxNumJavaThreads>.*</MaxNumJavaThreads>' $configPath | cut -d'<' -f 2 | cut -d'>' -f 2`

	kernels=`ls $threadNum/hashfile_* | wc -l`

	echo "java -jar jars/GPUTejas.jar $configPath $outputFile . $kernels"
	
	if !(java -jar gputejas/jars/GPUTejas.jar $configPath $outputFile . $kernels) then
		echo "Problem with running the benchmark, try generating the traces again, exiting..."
		echo ""
		exit 1
	fi

	exit 0
fi


if [ $1 = 'clean' ]
then
    echo "CLEANING..."
    # echo "rm *.txt *.o tracegen"
    # rm *.txt *.o tmp tracegen 2>/dev/null
    rm *.txt
    rm -rf traces
    cd nvbit_tools/tools
    make clean
    cd ../..


    cd gputejas
	ant clean
    
    
    echo "---- Done ---"
    exit 0
fi
