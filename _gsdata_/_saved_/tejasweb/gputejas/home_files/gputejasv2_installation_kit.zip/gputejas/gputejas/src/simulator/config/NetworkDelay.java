/**
 * 
 */
package config;

/**
 * @author Gantavya
 *
 */
public class NetworkDelay {
	public static int networkDelay;
	public NetworkDelay(int networkDelay) {
		this.networkDelay= networkDelay;
	}
}
