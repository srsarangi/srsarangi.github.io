package config;

public class RegConfig {
	public static int num_banks;
	public static int num_collector_units;
	public static int num_dispatch_units;
}
