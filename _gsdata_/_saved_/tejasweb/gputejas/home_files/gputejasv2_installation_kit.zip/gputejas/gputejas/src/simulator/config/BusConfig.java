package config;

public class BusConfig {
	int latency;
	
	public BusConfig() {
	}
	
	public int getLatency() {
		return latency;
	}

	public void setLatency(int latency) {
		this.latency = latency;
	}
}
