package config;

public class OperationEnergyConfig {
	public static int loadEnergy;
	public static int storeEnergy;
	public static int addressEnergy;
	public static int intALUEnergy;
	public static int intMULEnergy;
	public static int intDIVEnergy;
	public static int floatALUEnergy;
	public static int floatMULEnergy;
	public static int floatDIVEnergy;
	public static int predicateEnergy;
	public static int branchEnergy;
	public static int callEnergy;
	public static int returnEnergy;
	public static int exitEnergy;
}
