package config;

public enum CommunicationType {
	sharedMemory,
	network,
	file
}
