#!/bin/bash
if [ $1 = 'GPUTejas' ] || [ $1 = 'all' ]
then
	echo "Entering GPUTejasPowerPack Directory..."
	cd GPUTejasPowerPack/UpdateConfig/
	cd cacti/
	echo "Building cacti ... "
	make
	cd ../
	cp -r $(pwd)/cacti/obj_opt/ $(pwd)/obj_opt/

	g++ -m32 -c main.cc
	cp $(pwd)/main.o $(pwd)/obj_opt/main.o
	echo "Building mcpat ... "	
	make

	g++ -c -I/opt/include updateGPUParameters.cpp
	g++ -o updateGPUParameters updateGPUParameters.o -L/opt/lib -lxerces-c 
	echo "Updating the config file with expected config... "
	./updateGPUParameters $(pwd)/config.xml

	g++ -c -I/opt/include UpdateConfig.cpp
	g++ -o updateConfig UpdateConfig.o -L/opt/lib -lxerces-c 
	echo "Configuring the mcpat input file with GPUTejas config file... "
	./updateConfig $(pwd)/config.xml

	echo "Running mcpat to generate power numbers "
	./mcpat -infile input.xml -print_level 5 > /dev/null

	g++ -c -I/opt/include UpdatePower.cpp
	g++ -o updatePower UpdatePower.o -L/opt/lib -lxerces-c 

	echo "Creating new GPUTejas config file..."
	cp -v $(pwd)/config.xml $(pwd)/config_Gtpp.xml

	echo "Updating new GPUTejas config file with the power numbers.."
	./updatePower $(pwd)/config_Gtpp.xml
	rm -rf output_power.txt
	
	echo "Exiting GPUTejas Power Pack directory..."
	cd ../../
	cp -v  $(pwd)/GPUTejasPowerPack/UpdateConfig/config_Gtpp.xml $(pwd)/config_gputejas.xml
	echo "GPUTejas config file config_gputejas.xml is ready..."

fi

if [ $1 = 'Tejas' ] || [ $1 = 'all' ]
then
	echo "Entering TejasPowerPack Directory..."
	cd Tejaspowerpack/UpdateConfig/
	cd cacti/
	echo "Building cacti ... "
	make
	cd ../
	cp -r $(pwd)/cacti/obj_opt/ $(pwd)/obj_opt/

	g++ -m32 -c main.cc
	cp $(pwd)/main.o $(pwd)/obj_opt/main.o
	echo "Building mcpat ... "	
	make

	g++ -c -I/opt/include UpdateConfig.cpp
	g++ -o updateConfig UpdateConfig.o -L/opt/lib -lxerces-c 
	echo "Configuring the mcpat input file with GPUTejas config file... "
	./updateConfig $(pwd)/config.xml

	echo "Running mcpat to generate power numbers "
	./mcpat -infile input.xml -print_level 5 >/dev/null

	echo "Entering Orion directory.."
	cd orion_2.0/
	
	g++ -c -I/opt/include updateNoCStats.cpp
	g++ -o updateNoCStats updateNoCStats.o -L/opt/lib -lxerces-c
	echo "Configuring the Orion stats file with the Tejas config file..."
	./updateNoCStats config.xml
	make clean

	echo "Building Orion with new configuration set..."	
	make

	echo "Running Orion router power to get power of the router..."
	./orion_router_power -e router1

	echo "Running Orion link to get power of the link..."
	./orion_link 100 1
	echo "Exiting Orion directory"
	cd ../

	g++ -c -I/opt/include UpdatePower.cpp
	g++ -o updatePower UpdatePower.o -L/opt/lib -lxerces-c 

	echo "Creating new Tejas config file..."
	cp -v $(pwd)/config.xml $(pwd)/config_tpp.xml

	echo "Updating new Tejas config file with the power numbers.."
	./updatePower $(pwd)/config_tpp.xml
	rm -rf output_power.txt

	echo "Exiting Tejas Power Pack directory..."
	cd ../../

	cp -v  $(pwd)/Tejaspowerpack/UpdateConfig/config_tpp.xml $(pwd)/config_tejas.xml
	echo "Tejas config file config_tejas.xml is ready..."

fi

