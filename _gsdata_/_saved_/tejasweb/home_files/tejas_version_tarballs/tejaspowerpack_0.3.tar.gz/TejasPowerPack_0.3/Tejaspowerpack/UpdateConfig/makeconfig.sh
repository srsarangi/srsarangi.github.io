cd cacti/
make
cd ../
cp -r $(pwd)/cacti/obj_opt/ $(pwd)/obj_opt/
g++ -m32 -c main.cc
cp $(pwd)/main.o $(pwd)/obj_opt/main.o	
make
g++ -c -I/opt/include UpdateConfig.cpp
g++ -o updateConfig UpdateConfig.o -L/opt/lib -lxerces-c 
./updateConfig $(pwd)/config.xml
./mcpat -infile input.xml -print_level 5 > output1.txt
cp -v $(pwd)/config.xml $(pwd)/orion_2.0/config.xml
cd orion_2.0/
g++ -c -I/opt/include updateNoCStats.cpp
g++ -o updateNoCStats updateNoCStats.o -L/opt/lib -lxerces-c
./updateNoCStats config.xml
make clean
make
./orion_router_power -e router1
./orion_link 100 1
cd ../
g++ -c -I/opt/include UpdatePower.cpp
g++ -o updatePower UpdatePower.o -L/opt/lib -lxerces-c 
cp -v $(pwd)/config.xml $(pwd)/config_tpp.xml
./updatePower $(pwd)/config_tpp.xml
rm -rf output_power.txt
