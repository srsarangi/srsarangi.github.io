#include <string>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <list>
#include <vector>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <xercesc/framework/LocalFileFormatTarget.hpp>

#include <xercesc/dom/DOM.hpp>
#include <xercesc/dom/DOMDocument.hpp>
#include <xercesc/dom/DOMDocumentType.hpp>
#include <xercesc/dom/DOMElement.hpp>
#include <xercesc/dom/DOMImplementation.hpp>
#include <xercesc/dom/DOMImplementationLS.hpp>
#include <xercesc/dom/DOMNodeIterator.hpp>
#include <xercesc/dom/DOMNodeList.hpp>
#include <xercesc/dom/DOMText.hpp>

#include <xercesc/parsers/XercesDOMParser.hpp>
#include <xercesc/util/XMLUni.hpp>

#include <fstream>
#include <stdexcept>
#include <typeinfo>
#include <cmath>
#include <cstdlib>

using namespace xercesc;
using namespace std;

const XMLCh* getValue(const XMLCh* tagName, DOMElement* parent) // Get the immediate string value of a particular tag name under a particular parent tag
{
		DOMNodeList* nodeLst = parent->getElementsByTagName(tagName);
		if (nodeLst->item(0) == NULL)
		{
			return NULL;
			//XERCES_STD_QUALIFIER cerr<<"XML Configuration error : Item \"" << tagName << "\" not found inside the \""
			//<< parent->getTagName()<< "\" tag in the configuration file!!"<< XERCES_STD_QUALIFIER endl;
		}
	    DOMElement* NodeElmnt = (DOMElement*) nodeLst->item(0);
	    DOMNodeList* resultNode = NodeElmnt->getChildNodes();
	    return ((DOMNode*) resultNode->item(0))->getNodeValue();
}

string to_string(double x)
{
  ostringstream ss;
  ss << x;
  return ss.str();
}

void setValue(const XMLCh* tagName, DOMElement* parent, double val) // Get the immediate string value of a particular tag name under a particular parent tag
{
		string str = to_string(val);
		const XMLCh* value=XMLString::transcode(str.c_str());
		DOMNodeList* nodeLst = parent->getElementsByTagName(tagName);
		if (nodeLst->item(0) == NULL)
		{
			XERCES_STD_QUALIFIER cerr<<"XML Configuration error : Item \"" << tagName << "\" not found inside the \""
			<< parent->getTagName()<< "\" tag in the configuration file!!"<< XERCES_STD_QUALIFIER endl;
		}
	    DOMElement* NodeElmnt = (DOMElement*) nodeLst->item(0);
	    DOMNodeList* resultNode = NodeElmnt->getChildNodes();
	    return ((DOMNode*) resultNode->item(0))->setNodeValue(value);
}


int noc_operating_freq;
int noc_techpoint;
int noc_access_ports;

void getConfigValues(DOMDocument* doc)
{

	doc->normalize();

	DOMNodeList* systemLst = doc->getElementsByTagName(XMLString::transcode("System"));
	DOMElement* systemElement = (DOMElement*)systemLst->item(0);

	DOMNodeList* nocLst = systemElement->getElementsByTagName(XMLString::transcode("NOC"));
	DOMElement* nocElement = (DOMElement*)nocLst->item(0);
	noc_access_ports = XMLString::parseInt(getValue(XMLString::transcode("NocAccessPorts"),nocElement));
	noc_operating_freq = XMLString::parseInt(getValue(XMLString::transcode("NocOperatingFreq"),nocElement));
	noc_techpoint = XMLString::parseInt(getValue(XMLString::transcode("TechPoint"),nocElement));
}

void setInputValues()
{
	ifstream myfile ("SIM_port.h");
	string line;
	string noc_techpoint1 = to_string(noc_techpoint);
	string noc_operating_freq1 = to_string(noc_operating_freq*1e6);
	string noc_access_ports1 = to_string(noc_access_ports/2);

	vector<std::string> lines_tobe_stored;
	while (getline(myfile, line)) 
			lines_tobe_stored.push_back(line);
		
	for (int i=0; i<lines_tobe_stored.size();i++){
			string str = "#define PARM_TECH_POINT       ";
			if ( lines_tobe_stored[i].find(str)!= string::npos) {
				string replacewith = str + noc_techpoint1;
				lines_tobe_stored[i].replace(lines_tobe_stored[i].find(str),str.length()+3,replacewith);
			}
			str = "#define PARM_Freq             ";
			if ( lines_tobe_stored[i].find(str)!= string::npos) {
				string replacewith = str + noc_operating_freq1;
				lines_tobe_stored[i].replace(lines_tobe_stored[i].find(str),str.length()+10,replacewith);
			}
			str = "#define PARM_in_port 		";
			if ( lines_tobe_stored[i].find(str)!= string::npos) {
				string replacewith = str + noc_access_ports1;
				lines_tobe_stored[i].replace(lines_tobe_stored[i].find(str),str.length()+2,replacewith);
			}
			str = "#define PARM_out_port		";
			if ( lines_tobe_stored[i].find(str)!= string::npos) {
				string replacewith = str + noc_access_ports1;
				lines_tobe_stored[i].replace(lines_tobe_stored[i].find(str),str.length()+2,replacewith);
			}
		     
	}
	myfile.close();
	ofstream my_outfile ("SIM_port.h");
	for (int i=0; i<lines_tobe_stored.size();i++)
		my_outfile << lines_tobe_stored[i] << '\n';


	  
	cout<<"Done Writing!"<<endl;
}

int main(int argC, char* argV[]) throw( std::runtime_error )
{
	cout<<"Updating orion2 stats file!"<<endl;
	try
   	{
      	XMLPlatformUtils::Initialize();  // Initialize Xerces infrastructure
   	}
   	catch( XMLException& e )
   	{
	    char* message = XMLString::transcode( e.getMessage() );
     	cerr << "XML toolkit initialization error: " << message << endl;
      	XMLString::release( &message );
   		// throw exception here to return ERROR_XERCES_INIT
   	}
	//cout<<"Done 1"<<endl;

	if (argC < 2)
   	{
	//  usage();
       	XMLPlatformUtils::Terminate();
       	return 1;
    }
	string configFile=argV[1];
   	xercesc::XercesDOMParser *ConfigFileParser=new xercesc::XercesDOMParser;

	ConfigFileParser->setValidationScheme( XercesDOMParser::Val_Auto );
   	ConfigFileParser->setDoNamespaces( false );
   	ConfigFileParser->setDoSchema( false );

	try
   	{
      		ConfigFileParser->parse( configFile.c_str() );
	}
   	catch( xercesc::XMLException& e )
   	{
	      	char* message = xercesc::XMLString::transcode( e.getMessage() );
	      	ostringstream errBuf;
	    	errBuf << "Error parsing file: " << message << flush;
	      	XMLString::release( &message );
   	}
    DOMDocument* doc = ConfigFileParser->getDocument();
	cout<<"Getting values from config file!"<<endl;
	getConfigValues(doc);
	cout<<"Setting values in orion stats file!"<<endl;	
	
	setInputValues();
//	cout<<"try Writing!"<<endl;

	XMLCh tempStr[3] = {chLatin_L, chLatin_S, chNull};
	    delete ConfigFileParser;
    XMLPlatformUtils::Terminate();
	return 0;
}


