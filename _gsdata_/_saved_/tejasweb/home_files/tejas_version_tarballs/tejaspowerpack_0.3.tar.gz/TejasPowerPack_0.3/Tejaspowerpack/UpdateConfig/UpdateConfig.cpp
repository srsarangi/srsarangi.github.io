#include <string>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <list>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <xercesc/framework/LocalFileFormatTarget.hpp>

#include <xercesc/dom/DOM.hpp>
#include <xercesc/dom/DOMDocument.hpp>
#include <xercesc/dom/DOMDocumentType.hpp>
#include <xercesc/dom/DOMElement.hpp>
#include <xercesc/dom/DOMImplementation.hpp>
#include <xercesc/dom/DOMImplementationLS.hpp>
#include <xercesc/dom/DOMNodeIterator.hpp>
#include <xercesc/dom/DOMNodeList.hpp>
#include <xercesc/dom/DOMText.hpp>

#include <xercesc/parsers/XercesDOMParser.hpp>
#include <xercesc/util/XMLUni.hpp>

#include <fstream>
#include <stdexcept>
#include <typeinfo>
#include <cmath>
#include <cstdlib>

using namespace xercesc;
using namespace std;

const XMLCh* getValue(const XMLCh* tagName, DOMElement* parent) // Get the immediate string value of a particular tag name under a particular parent tag
{
		DOMNodeList* nodeLst = parent->getElementsByTagName(tagName);
		if (nodeLst->item(0) == NULL)
		{
			return NULL;
			//XERCES_STD_QUALIFIER cerr<<"XML Configuration error : Item \"" << tagName << "\" not found inside the \""
			//<< parent->getTagName()<< "\" tag in the configuration file!!"<< XERCES_STD_QUALIFIER endl;
		}
	    DOMElement* NodeElmnt = (DOMElement*) nodeLst->item(0);
	    DOMNodeList* resultNode = NodeElmnt->getChildNodes();
	    return ((DOMNode*) resultNode->item(0))->getNodeValue();
}

string to_string(double x)
{
  ostringstream ss;
  ss << x;
  return ss.str();
}

void setValue(const XMLCh* tagName, DOMElement* parent, double val) // Get the immediate string value of a particular tag name under a particular parent tag
{
		string str = to_string(val);
		const XMLCh* value=XMLString::transcode(str.c_str());
		DOMNodeList* nodeLst = parent->getElementsByTagName(tagName);
		if (nodeLst->item(0) == NULL)
		{
			XERCES_STD_QUALIFIER cerr<<"XML Configuration error : Item \"" << tagName << "\" not found inside the \""
			<< parent->getTagName()<< "\" tag in the configuration file!!"<< XERCES_STD_QUALIFIER endl;
		}
	    DOMElement* NodeElmnt = (DOMElement*) nodeLst->item(0);
	    DOMNodeList* resultNode = NodeElmnt->getChildNodes();
	    return ((DOMNode*) resultNode->item(0))->setNodeValue(value);
}
	
int pipeline_type;
char* pipeline_type_str;
int no_of_cores;
int baseline_technology;
int core_frequency;
int lsq_size;
int tlb_size;
int fetch_width;
int decode_width;
int issue_width;
int rob_size;
int instruction_window;
int int_reg_filesize;
int float_reg_filesize;
int int_arch_reg_num;
int float_arch_reg_num; 
int reg_file_ports;
int int_alu_num;
int int_mul_num;
int int_div_num;
int float_alu_num;
int float_mul_num;
int float_div_num;

int pc_bits;
int bhr_size;
int saturating_bits;

int noc_operating_freq;

int dir_blocksize;
int dir_assoc;
int dir_size;
int dir_latency;

int icache_blocksize;
int icache_assoc;
int icache_size;
int icache_latency;

int dcache_blocksize;
int dcache_assoc;
int dcache_size;
int dcache_latency;

int l2cache_blocksize;
int l2cache_assoc;
int l2cache_size;
int l2cache_latency;

int l3cache_blocksize;
int l3cache_assoc;
int l3cache_size;
int l3cache_latency;

void getConfigValues(DOMDocument* doc)
{
	doc->normalize();
	DOMNodeList* simulationLst = doc->getElementsByTagName(XMLString::transcode("Simulation"));
	DOMElement* simulationElement = (DOMElement*)simulationLst->item(0);
	
	no_of_cores = XMLString::parseInt(getValue(XMLString::transcode("NumCores"),simulationElement));
	baseline_technology = XMLString::parseInt(getValue(XMLString::transcode("baseline_technology"),simulationElement));
	DOMNodeList* systemLst = doc->getElementsByTagName(XMLString::transcode("System"));
	DOMElement* systemElement = (DOMElement*)systemLst->item(0);
	DOMNodeList* coreLst = systemElement->getElementsByTagName(XMLString::transcode("Core"));
	DOMElement* coreElement = (DOMElement*)coreLst->item(0);
	core_frequency = XMLString::parseInt(getValue(XMLString::transcode("CoreFrequency"),coreElement));
	pipeline_type_str = XMLString::transcode(getValue(XMLString::transcode("PipelineType"),coreElement));
	if(strcmp(pipeline_type_str, "outOfOrder") ==0)
		pipeline_type=0;
	else
		pipeline_type=1;
	DOMNodeList* predictorLst = coreElement->getElementsByTagName(XMLString::transcode("BranchPredictor"));
	DOMElement* predictorElement = (DOMElement*)predictorLst->item(0);
	pc_bits = XMLString::parseInt(getValue(XMLString::transcode("PCBits"),predictorElement));
	bhr_size = XMLString::parseInt(getValue(XMLString::transcode("BHRsize"),predictorElement));
	saturating_bits = XMLString::parseInt(getValue(XMLString::transcode("SaturatingBits"),predictorElement));
	DOMNodeList* LSQLst = coreElement->getElementsByTagName(XMLString::transcode("LSQ"));
	DOMElement* LSQElement = (DOMElement*)LSQLst->item(0);
	lsq_size = XMLString::parseInt(getValue(XMLString::transcode("LSQSize"),LSQElement));
	DOMNodeList* TLBLst = coreElement->getElementsByTagName(XMLString::transcode("ITLB"));
	DOMElement* TLBElement = (DOMElement*)TLBLst->item(0);
	tlb_size = XMLString::parseInt(getValue(XMLString::transcode("Size"),TLBElement));
	DOMNodeList* DecodeLst = coreElement->getElementsByTagName(XMLString::transcode("Decode"));
	DOMElement* DecodeElement = (DOMElement*)DecodeLst->item(0);
	fetch_width = XMLString::parseInt(getValue(XMLString::transcode("FetchWidth"),DecodeElement));
	decode_width = XMLString::parseInt(getValue(XMLString::transcode("Width"),DecodeElement));
	DOMNodeList* IWLst = coreElement->getElementsByTagName(XMLString::transcode("InstructionWindow"));
	DOMElement* IWElement = (DOMElement*)IWLst->item(0);
	issue_width = XMLString::parseInt(getValue(XMLString::transcode("IssueWidth"),IWElement));
	instruction_window = XMLString::parseInt(getValue(XMLString::transcode("IWSize"),IWElement));
	DOMNodeList* ROBLst = coreElement->getElementsByTagName(XMLString::transcode("ROB"));
	DOMElement* ROBElement = (DOMElement*)ROBLst->item(0);
	rob_size = XMLString::parseInt(getValue(XMLString::transcode("ROBSize"),ROBElement));
	DOMNodeList* RFLst = coreElement->getElementsByTagName(XMLString::transcode("RegisterFile"));
	DOMElement* RFElement = (DOMElement*)RFLst->item(0);
	DOMNodeList* RFIntLst = RFElement->getElementsByTagName(XMLString::transcode("Integer"));
	DOMElement* RFIntElement = (DOMElement*)RFIntLst->item(0);
	int_reg_filesize = XMLString::parseInt(getValue(XMLString::transcode("IntRegFileSize"),RFIntElement));
	int_arch_reg_num = XMLString::parseInt(getValue(XMLString::transcode("IntArchRegNum"),RFIntElement));
	DOMNodeList* RFFltLst = RFElement->getElementsByTagName(XMLString::transcode("Float"));
	DOMElement* RFFltElement = (DOMElement*)RFFltLst->item(0);
	float_reg_filesize = XMLString::parseInt(getValue(XMLString::transcode("FloatRegFileSize"),RFFltElement));
	float_arch_reg_num = XMLString::parseInt(getValue(XMLString::transcode("FloatArchRegNum"),RFFltElement));
	reg_file_ports = XMLString::parseInt(getValue(XMLString::transcode("ExecutionCoreNumPorts"),coreElement));
	DOMNodeList* IntALULst = coreElement->getElementsByTagName(XMLString::transcode("IntALU"));
	DOMElement* IntALUElement = (DOMElement*)IntALULst->item(0);
	int_alu_num = XMLString::parseInt(getValue(XMLString::transcode("Num"),IntALUElement));
	DOMNodeList* IntMulLst = coreElement->getElementsByTagName(XMLString::transcode("IntMul"));
	DOMElement* IntMulElement = (DOMElement*)IntMulLst->item(0);
	int_mul_num = XMLString::parseInt(getValue(XMLString::transcode("Num"),IntMulElement));
	DOMNodeList* IntDivLst = coreElement->getElementsByTagName(XMLString::transcode("IntDiv"));
	DOMElement* IntDivElement = (DOMElement*)IntDivLst->item(0);
	int_div_num = XMLString::parseInt(getValue(XMLString::transcode("Num"),IntDivElement));
	DOMNodeList* FloatALULst = coreElement->getElementsByTagName(XMLString::transcode("FloatALU"));
	DOMElement* FloatALUElement = (DOMElement*)FloatALULst->item(0);
	float_alu_num = XMLString::parseInt(getValue(XMLString::transcode("Num"),FloatALUElement));
	DOMNodeList* FloatMulLst = coreElement->getElementsByTagName(XMLString::transcode("FloatMul"));
	DOMElement* FloatMulElement = (DOMElement*)FloatMulLst->item(0);
	float_mul_num = XMLString::parseInt(getValue(XMLString::transcode("Num"),FloatMulElement));
	DOMNodeList* FloatDivLst = coreElement->getElementsByTagName(XMLString::transcode("FloatDiv"));
	DOMElement* FloatDivElement = (DOMElement*)FloatDivLst->item(0);
	float_div_num = XMLString::parseInt(getValue(XMLString::transcode("Num"),FloatDivElement));
	
	
	
	
	DOMNodeList* nocLst = systemElement->getElementsByTagName(XMLString::transcode("NOC"));
	DOMElement* nocElement = (DOMElement*)nocLst->item(0);
	noc_operating_freq = XMLString::parseInt(getValue(XMLString::transcode("NocOperatingFreq"),nocElement));
		
	DOMNodeList* libLst = doc->getElementsByTagName(XMLString::transcode("Library"));
	DOMElement* libElement = (DOMElement*)libLst->item(0);
	
	DOMNodeList* InstCacheLst = libElement->getElementsByTagName(XMLString::transcode("ICache_32K_8"));
	DOMElement* InstCacheElement = (DOMElement*)InstCacheLst->item(0);
	icache_blocksize = XMLString::parseInt(getValue(XMLString::transcode("BlockSize"),InstCacheElement));
	icache_assoc = XMLString::parseInt(getValue(XMLString::transcode("Associativity"),InstCacheElement));
	icache_size = XMLString::parseInt(getValue(XMLString::transcode("Size"),InstCacheElement));
	icache_latency = XMLString::parseInt(getValue(XMLString::transcode("Latency"),InstCacheElement));
	
	DOMNodeList* L1CacheLst = libElement->getElementsByTagName(XMLString::transcode("L1Cache_32K_8"));
	DOMElement* L1CacheElement = (DOMElement*)L1CacheLst->item(0);
	dcache_blocksize = XMLString::parseInt(getValue(XMLString::transcode("BlockSize"),L1CacheElement));
	dcache_assoc = XMLString::parseInt(getValue(XMLString::transcode("Associativity"),L1CacheElement));
	dcache_size = XMLString::parseInt(getValue(XMLString::transcode("Size"),L1CacheElement));
	dcache_latency = XMLString::parseInt(getValue(XMLString::transcode("Latency"),L1CacheElement));
	
	DOMNodeList* L2CacheLst = libElement->getElementsByTagName(XMLString::transcode("L2Cache_256K_8"));
	DOMElement* L2CacheElement = (DOMElement*)L2CacheLst->item(0);
	l2cache_blocksize = XMLString::parseInt(getValue(XMLString::transcode("BlockSize"),L2CacheElement));
	l2cache_assoc = XMLString::parseInt(getValue(XMLString::transcode("Associativity"),L2CacheElement));
	l2cache_size = XMLString::parseInt(getValue(XMLString::transcode("Size"),L2CacheElement));
	l2cache_latency = XMLString::parseInt(getValue(XMLString::transcode("Latency"),L2CacheElement));
	
	DOMNodeList* L3CacheLst = libElement->getElementsByTagName(XMLString::transcode("L3Cache_4M_8"));
	DOMElement* L3CacheElement = (DOMElement*)L3CacheLst->item(0);
	l3cache_blocksize = XMLString::parseInt(getValue(XMLString::transcode("BlockSize"),L3CacheElement));
	l3cache_assoc = XMLString::parseInt(getValue(XMLString::transcode("Associativity"),L3CacheElement));
	l3cache_size = XMLString::parseInt(getValue(XMLString::transcode("Size"),L3CacheElement));
	l3cache_latency = XMLString::parseInt(getValue(XMLString::transcode("Latency"),L3CacheElement));
	
	DOMNodeList* dirLst = libElement->getElementsByTagName(XMLString::transcode("Directory1"));
	DOMElement* dirElement = (DOMElement*)dirLst->item(0);
	dir_blocksize = XMLString::parseInt(getValue(XMLString::transcode("BlockSize"),dirElement));
	dir_assoc = XMLString::parseInt(getValue(XMLString::transcode("Associativity"),dirElement));
	dir_size = XMLString::parseInt(getValue(XMLString::transcode("NumEntries"),dirElement));
	dir_latency = XMLString::parseInt(getValue(XMLString::transcode("Latency"),dirElement));

}

void setInputValues(DOMDocument* doc)
{
	string str = "value";
	const XMLCh* attr=XMLString::transcode(str.c_str());
	
	DOMNodeList* inputLst = doc->getElementsByTagName(XMLString::transcode("component"));
	DOMElement* rootElement = (DOMElement*)inputLst->item(0);
	DOMNodeList* systemLst = rootElement->getElementsByTagName(XMLString::transcode("component"));
	DOMElement* systemElement = (DOMElement*)systemLst->item(0);
	DOMNodeList* paramLst = systemElement->getElementsByTagName(XMLString::transcode("param"));
	
	DOMElement* noofCoresElement = (DOMElement*)paramLst->item(0);
	noofCoresElement->setAttribute(attr,XMLString::transcode(to_string(no_of_cores).c_str()));
	
	DOMElement* techElement = (DOMElement*)paramLst->item(14);
	techElement->setAttribute(attr,XMLString::transcode(to_string(baseline_technology).c_str()));
	
	DOMElement* coreFreqElement = (DOMElement*)paramLst->item(15);
	coreFreqElement->setAttribute(attr,XMLString::transcode(to_string(core_frequency).c_str()));
	
	DOMNodeList* componentLst = systemElement->getElementsByTagName(XMLString::transcode("component"));
	DOMElement* component0Element = (DOMElement*)componentLst->item(0);
	
	paramLst = component0Element->getElementsByTagName(XMLString::transcode("param"));
	coreFreqElement = (DOMElement*)paramLst->item(0);
	coreFreqElement->setAttribute(attr,XMLString::transcode(to_string(core_frequency).c_str()));
	
	DOMElement* machinetypeElement = (DOMElement*)paramLst->item(8);
	machinetypeElement->setAttribute(attr,XMLString::transcode(to_string(pipeline_type).c_str()));
	
	DOMElement* noofThreadsElement = (DOMElement*)paramLst->item(9);
	noofThreadsElement->setAttribute(attr,XMLString::transcode(to_string(no_of_cores).c_str()));
	
	DOMElement* fetchwidthElement = (DOMElement*)paramLst->item(10);
	fetchwidthElement->setAttribute(attr,XMLString::transcode(to_string(fetch_width).c_str()));
	
	DOMElement* decodewidthElement = (DOMElement*)paramLst->item(12);
	decodewidthElement->setAttribute(attr,XMLString::transcode(to_string(decode_width).c_str()));
	
	DOMElement* issuewidthElement = (DOMElement*)paramLst->item(13);
	issuewidthElement->setAttribute(attr,XMLString::transcode(to_string(issue_width).c_str()));
	
	DOMElement* commitwidthElement = (DOMElement*)paramLst->item(15);
	commitwidthElement->setAttribute(attr,XMLString::transcode(to_string(reg_file_ports).c_str()));
	
	DOMElement* aluPerCoreElement = (DOMElement*)paramLst->item(20);
	aluPerCoreElement->setAttribute(attr,XMLString::transcode(to_string(int_alu_num).c_str()));
	
	DOMElement* mulPerCoreElement = (DOMElement*)paramLst->item(21);
	mulPerCoreElement->setAttribute(attr,XMLString::transcode(to_string(int_mul_num + int_div_num).c_str()));
	
	DOMElement* floatPerCoreElement = (DOMElement*)paramLst->item(22);
	floatPerCoreElement->setAttribute(attr,XMLString::transcode(to_string(float_alu_num + float_mul_num + float_div_num).c_str()));
	
	DOMElement* iwElement = (DOMElement*)paramLst->item(26);
	iwElement->setAttribute(attr,XMLString::transcode(to_string(instruction_window).c_str()));
	
	DOMElement* fiwElement = (DOMElement*)paramLst->item(27);
	fiwElement->setAttribute(attr,XMLString::transcode(to_string(instruction_window).c_str()));
	
	DOMElement* robElement = (DOMElement*)paramLst->item(28);
	robElement->setAttribute(attr,XMLString::transcode(to_string(rob_size).c_str()));
	
	DOMElement* archintregfileElement = (DOMElement*)paramLst->item(29);
	archintregfileElement->setAttribute(attr,XMLString::transcode(to_string(int_arch_reg_num).c_str()));
	
	DOMElement* archfloatregfileElement = (DOMElement*)paramLst->item(30);
	archfloatregfileElement->setAttribute(attr,XMLString::transcode(to_string(float_arch_reg_num).c_str()));
	
	DOMElement* phyintregfile = (DOMElement*)paramLst->item(31);
	phyintregfile->setAttribute(attr,XMLString::transcode(to_string(int_reg_filesize).c_str()));
	
	DOMElement* phyfloatregfile = (DOMElement*)paramLst->item(32);
	phyfloatregfile->setAttribute(attr,XMLString::transcode(to_string(float_reg_filesize).c_str()));
	
	DOMElement* storebuffersize = (DOMElement*)paramLst->item(37);
	storebuffersize->setAttribute(attr,XMLString::transcode(to_string(lsq_size/2).c_str()));
	
	DOMElement* loadbuffersize = (DOMElement*)paramLst->item(38);
	loadbuffersize->setAttribute(attr,XMLString::transcode(to_string(lsq_size/2).c_str()));
	
	DOMNodeList* subcomponent0Lst = component0Element->getElementsByTagName(XMLString::transcode("component"));
	DOMElement* predictorElement = (DOMElement*)subcomponent0Lst->item(0);
	
	/*paramLst = predictorElement->getElementsByTagName(XMLString::transcode("param"));
	DOMElement* lpsElement = (DOMElement*)paramLst->item(0);
	lpsElement->setAttribute(attr,XMLString::transcode((to_string(bhr_size) + "," + to_string(saturating_bits)).c_str()));
	
	DOMElement* lpeElement = (DOMElement*)paramLst->item(1);
	lpeElement->setAttribute(attr,XMLString::transcode(to_string(pow(2.0,bhr_size)).c_str()));
	
	DOMElement* gpeElement = (DOMElement*)paramLst->item(2);
	gpeElement->setAttribute(attr,XMLString::transcode(to_string(pow(2.0,bhr_size+2)).c_str()));
	
	DOMElement* gpbElement = (DOMElement*)paramLst->item(3);
	gpbElement->setAttribute(attr,XMLString::transcode(to_string(saturating_bits).c_str()));
	
	DOMElement* cpeElement = (DOMElement*)paramLst->item(4);
	cpeElement->setAttribute(attr,XMLString::transcode(to_string(pow(2.0,bhr_size+2)).c_str()));
	
	DOMElement* cpbElement = (DOMElement*)paramLst->item(5);
	cpbElement->setAttribute(attr,XMLString::transcode(to_string(2).c_str()));*/
	
	DOMElement* itlbElement = (DOMElement*)subcomponent0Lst->item(1);
	paramLst = itlbElement->getElementsByTagName(XMLString::transcode("param"));
	DOMElement* numberentriesElement = (DOMElement*)paramLst->item(0);
	numberentriesElement->setAttribute(attr,XMLString::transcode(to_string(tlb_size).c_str()));

	DOMElement* icacheElement = (DOMElement*)subcomponent0Lst->item(2);
	paramLst = icacheElement->getElementsByTagName(XMLString::transcode("param"));
	DOMElement* icacheconfigElement = (DOMElement*)paramLst->item(0);
	icacheconfigElement->setAttribute(attr,XMLString::transcode((to_string(icache_size)+"," + to_string(icache_blocksize) + "," + to_string(icache_assoc) + ",1,8," + to_string(icache_latency) + ",32,0").c_str()));
	
	DOMElement* dtlbElement = (DOMElement*)subcomponent0Lst->item(3);
	paramLst = dtlbElement->getElementsByTagName(XMLString::transcode("param"));
	numberentriesElement = (DOMElement*)paramLst->item(0);
	numberentriesElement->setAttribute(attr,XMLString::transcode(to_string(tlb_size).c_str()));
	
	DOMElement* dcacheElement = (DOMElement*)subcomponent0Lst->item(4);
	paramLst = dcacheElement->getElementsByTagName(XMLString::transcode("param"));
	DOMElement* dcacheconfigElement = (DOMElement*)paramLst->item(0);
	dcacheconfigElement->setAttribute(attr,XMLString::transcode((to_string(dcache_size)+"," + to_string(dcache_blocksize) + "," + to_string(dcache_assoc) + ",1,3," + to_string(dcache_latency) + ",16,1").c_str()));
	
	componentLst = systemElement->getElementsByTagName(XMLString::transcode("component"));
	
	DOMElement* component1Element = (DOMElement*)componentLst->item(7);
	paramLst = component1Element->getElementsByTagName(XMLString::transcode("param"));
	DOMElement* l1dirconfigElement = (DOMElement*)paramLst->item(1);
	l1dirconfigElement->setAttribute(attr,XMLString::transcode((to_string(dir_size)+"," + to_string(dir_blocksize) + "," + to_string(dir_assoc) + ",1,100," + to_string(dir_latency) + ",8").c_str()));
	
	componentLst = systemElement->getElementsByTagName(XMLString::transcode("component"));
	DOMElement* component9Element = (DOMElement*)componentLst->item(9);
	paramLst = component9Element->getElementsByTagName(XMLString::transcode("param"));
	DOMElement* l2configElement = (DOMElement*)paramLst->item(0);
	l2configElement->setAttribute(attr,XMLString::transcode((to_string(l2cache_size)+"," + to_string(l2cache_blocksize) + "," + to_string(l2cache_assoc) + ",8,8," + to_string(l2cache_latency) + ",32,1").c_str()));

	componentLst = systemElement->getElementsByTagName(XMLString::transcode("component"));
	DOMElement* component10Element = (DOMElement*)componentLst->item(10);
	paramLst = component10Element->getElementsByTagName(XMLString::transcode("param"));
	DOMElement* l3configElement = (DOMElement*)paramLst->item(0);
	l3configElement->setAttribute(attr,XMLString::transcode((to_string(l3cache_size)+"," + to_string(l3cache_blocksize) + "," + to_string(l3cache_assoc) + ",16,16," + to_string(l3cache_latency) + ",1").c_str()));
	
	componentLst = systemElement->getElementsByTagName(XMLString::transcode("component"));
	DOMElement* component11Element = (DOMElement*)componentLst->item(11);
	paramLst = component11Element->getElementsByTagName(XMLString::transcode("param"));
	DOMElement* nocconfigElement = (DOMElement*)paramLst->item(0);
	nocconfigElement->setAttribute(attr,XMLString::transcode(to_string(noc_operating_freq).c_str()));
	
	//setValue(XMLString::transcode("total_power"),noofCoresElement,no_of_cores);
}

int main(int argC, char* argV[]) throw( std::runtime_error )
{
	cout<<"Updating mcpat input file!"<<endl;
	try
   	{
      	XMLPlatformUtils::Initialize();  // Initialize Xerces infrastructure
   	}
   	catch( XMLException& e )
   	{
	    char* message = XMLString::transcode( e.getMessage() );
     	cerr << "XML toolkit initialization error: " << message << endl;
      	XMLString::release( &message );
   		// throw exception here to return ERROR_XERCES_INIT
   	}
	//cout<<"Done 1"<<endl;

	if (argC < 2)
   	{
	//  usage();
       	XMLPlatformUtils::Terminate();
       	return 1;
    }
	string configFile=argV[1];
   	xercesc::XercesDOMParser *ConfigFileParser=new xercesc::XercesDOMParser;
   	xercesc::XercesDOMParser *InputFileParser=new xercesc::XercesDOMParser;

	//cout<<"Done 2"<<endl;

   // Configure DOM parser.

   	ConfigFileParser->setValidationScheme( XercesDOMParser::Val_Auto );
   	ConfigFileParser->setDoNamespaces( false );
   	ConfigFileParser->setDoSchema( false );
   
   	InputFileParser->setValidationScheme( XercesDOMParser::Val_Auto );
   	InputFileParser->setDoNamespaces( false );
   	InputFileParser->setDoSchema( false );
//   ConfigFileParser->setLoadExternalDTD( false );
	//cout<<"Done 3"<<endl;

   	try
   	{
      	ConfigFileParser->parse( configFile.c_str() );
      	InputFileParser->parse( "input.xml");
   	}
   	catch( xercesc::XMLException& e )
   	{
      	char* message = xercesc::XMLString::transcode( e.getMessage() );
      	ostringstream errBuf;
    	errBuf << "Error parsing file: " << message << flush;
      	XMLString::release( &message );
   	}

    // no need to free this pointer - owned by the parent parser object
    DOMDocument* doc = ConfigFileParser->getDocument();
    DOMDocument* input = InputFileParser->getDocument();

	cout<<"Getting values from config file!"<<endl;
	getConfigValues(doc);
	cout<<"Setting values in input file!"<<endl;	
	setInputValues(input);
		
      
	XMLCh tempStr[3] = {chLatin_L, chLatin_S, chNull};
	DOMImplementation *impl          = DOMImplementationRegistry::getDOMImplementation(tempStr);
    DOMLSSerializer   *theSerializer = ((DOMImplementationLS*)impl)->createLSSerializer();
    DOMLSOutput       *theOutputDesc = ((DOMImplementationLS*)impl)->createLSOutput();
	XMLFormatTarget *myFormTarget;
	
	string str = "input.xml";
    myFormTarget=new LocalFileFormatTarget(str.c_str());
    theOutputDesc->setByteStream(myFormTarget);
	
	theSerializer->write(input, theOutputDesc);
	cout<<"Done Writing!"<<endl;
	theOutputDesc->release();
	theSerializer->release();
	//cout<<"Add Done 8"<<endl;
		
    delete myFormTarget;
    delete ConfigFileParser;
    XMLPlatformUtils::Terminate();
	return 0;
}
