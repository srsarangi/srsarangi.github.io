#include <string>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <list>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <xercesc/framework/LocalFileFormatTarget.hpp>

#include <xercesc/dom/DOM.hpp>
#include <xercesc/dom/DOMDocument.hpp>
#include <xercesc/dom/DOMDocumentType.hpp>
#include <xercesc/dom/DOMElement.hpp>
#include <xercesc/dom/DOMImplementation.hpp>
#include <xercesc/dom/DOMImplementationLS.hpp>
#include <xercesc/dom/DOMNodeIterator.hpp>
#include <xercesc/dom/DOMNodeList.hpp>
#include <xercesc/dom/DOMText.hpp>

#include <xercesc/parsers/XercesDOMParser.hpp>
#include <xercesc/util/XMLUni.hpp>
#include <string.h>
#include <fstream>
#include <stdexcept>
#include <typeinfo>
#include <cmath>
#include <cstdlib>


using namespace xercesc;
using namespace std;

const XMLCh* getValue(const XMLCh* tagName, DOMElement* parent) // Get the immediate string value of a particular tag name under a particular parent tag
{
		DOMNodeList* nodeLst = parent->getElementsByTagName(tagName);
		if (nodeLst->item(0) == NULL)
		{
			return NULL;
			//XERCES_STD_QUALIFIER cerr<<"XML Configuration error : Item \"" << tagName << "\" not found inside the \""
			//<< parent->getTagName()<< "\" tag in the configuration file!!"<< XERCES_STD_QUALIFIER endl;
		}
	    DOMElement* NodeElmnt = (DOMElement*) nodeLst->item(0);
	    DOMNodeList* resultNode = NodeElmnt->getChildNodes();
	    return ((DOMNode*) resultNode->item(0))->getNodeValue();
}

string to_string(double x)
{
  ostringstream ss;
  ss << x;
  return ss.str();
}

void setValue(const XMLCh* tagName, DOMElement* parent, double val) // Get the immediate string value of a particular tag name under a particular parent tag
{
		string str = to_string(val);
		const XMLCh* value=XMLString::transcode(str.c_str());
		DOMNodeList* nodeLst = parent->getElementsByTagName(tagName);
		if (nodeLst->item(0) == NULL)
		{
			XERCES_STD_QUALIFIER cerr<<"XML Configuration error : Item \"" << tagName << "\" not found inside the \""
					<< parent->getTagName()<< "\" tag in the configuration file!!"<< XERCES_STD_QUALIFIER endl;
		}
	    DOMElement* NodeElmnt = (DOMElement*) nodeLst->item(0);
	    DOMNodeList* resultNode = NodeElmnt->getChildNodes();
	    return ((DOMNode*) resultNode->item(0))->setNodeValue(value);
}


long total_instructions;
long int_instructions;
long fp_instructions;
long branch_instructions;
long load_instructions;
long rename_accesses;
long store_instructions;
long committed_instructions;
long committed_fp_instructions;
long committed_int_instructions;
long ROB_reads;
long ROB_writes;
long rename_reads;
long rename_writes;
long fp_rename_reads;
long fp_rename_writes;
long inst_window_reads;
long inst_window_writes;
long fp_inst_window_reads;
long fp_inst_window_writes;
long fp_inst_window_wakeup_accesses;
long inst_window_wakeup_accesses;
long int_regfile_reads;
long int_regfile_writes;
long float_regfile_reads;
long float_regfile_writes;
long ialu_accesses;
long fpu_accesses;
long mul_accesses;
long cdb_ialu_accesses;
long cdb_fpu_accesses;
long cdb_mul_accesses;
long itlb_accesses;
long dtlb_accesses;
long icache_accesses;
long mc_accesses;
long noc_accesses;
long dcache_readaccesses;
long dcache_writeaccesses;
long dir1_readaccesses;
long dir1_writeaccesses;
long btb_readaccesses;
long btb_writeaccesses;
long l2_readaccesses;
long l2_writeaccesses;
long l3_readaccesses;
long l3_writeaccesses;
char const* temp;

void getAccessValues(DOMDocument* doc)
{
	doc->normalize();
	DOMNodeList* inputLst = doc->getElementsByTagName(XMLString::transcode("component"));
	DOMElement* rootElement = (DOMElement*)inputLst->item(0);
	DOMNodeList* systemLst = rootElement->getElementsByTagName(XMLString::transcode("component"));
	DOMElement* systemElement = (DOMElement*)systemLst->item(0);

	DOMNodeList* componentLst = systemElement->getElementsByTagName(XMLString::transcode("component"));
	DOMElement* component0Element = (DOMElement*)componentLst->item(0);
	
	DOMNodeList* statLst = component0Element->getElementsByTagName(XMLString::transcode("stat"));
	
	DOMElement* statElement = (DOMElement*)statLst->item(0);
	if( statElement){
		temp = "total_instructions";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			total_instructions = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));

	}
	statElement = (DOMElement*)statLst->item(1);
	if( statElement){
		temp = "int_instructions";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			int_instructions = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));

	}
	statElement = (DOMElement*)statLst->item(2);
	if( statElement){
		temp = "fp_instructions";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			fp_instructions = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(3);
	if( statElement){
		temp = "branch_instructions";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			branch_instructions = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(5);
	if( statElement){
		temp = "load_instructions";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			load_instructions = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(6);
	if( statElement){
		temp = "store_instructions";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			store_instructions = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(7);
	if( statElement){
		temp = "committed_instructions";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			committed_instructions = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(8);
	if( statElement){
		temp = "committed_int_instructions";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			committed_int_instructions = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(9);
	if( statElement){
		temp = "committed_fp_instructions";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			committed_int_instructions = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(14);
	if( statElement){
		temp = "ROB_reads";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			ROB_reads = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(15);
	if( statElement){
		temp = "ROB_writes";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			ROB_writes = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));};
	statElement = (DOMElement*)statLst->item(16);
	if( statElement){	
		temp = "rename_reads";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			rename_reads = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}

	statElement = (DOMElement*)statLst->item(17);
	if( statElement){
		temp = "rename_writes";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			rename_writes = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(18);
	if( statElement){
		temp = "fp_rename_reads";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			fp_rename_reads = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(19);
	if( statElement){
		temp = "fp_rename_writes";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			fp_rename_writes = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(20);
	if( statElement){
		temp = "inst_window_reads";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			inst_window_reads = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(21);
	if( statElement){
		temp = "inst_window_writes";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			inst_window_writes = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(23);
	if( statElement){
		temp = "fp_inst_window_reads";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			fp_inst_window_reads= (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(24);
	if( statElement){
		temp = "fp_inst_window_writes";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			fp_inst_window_writes = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(25);
	if( statElement){
		temp = "fp_inst_window_wakeup_accesses";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			inst_window_wakeup_accesses = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(22);
	if( statElement){
		temp = "inst_window_wakeup_accesses";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			fp_inst_window_wakeup_accesses = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(26);
	if( statElement){
		temp = "int_regfile_reads";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			int_regfile_reads = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(28);
	if( statElement){
		temp = "int_regfile_writes";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			int_regfile_writes = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(27);
	if( statElement){
		temp = "float_regfile_reads";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			float_regfile_reads = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(29);
	if( statElement){
		temp = "float_regfile_writes";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			float_regfile_writes = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(32);
	if( statElement){
		temp = "ialu_accesses";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			ialu_accesses = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(34);
	if( statElement){
		temp = "mul_accesses";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			mul_accesses = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(33);
	if( statElement){
		temp = "fpu_accesses";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			fpu_accesses = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(35);
	if( statElement){
		temp = "cdb_ialu_accesses";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			cdb_ialu_accesses = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(36);
	if( statElement){
		temp = "cdb_mul_accesses";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			cdb_mul_accesses = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}
	statElement = (DOMElement*)statLst->item(37);
	if( statElement){
		temp = "cdb_fpu_accesses";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			cdb_fpu_accesses = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));}


		
	

	DOMNodeList* subcomponent0Lst = component0Element->getElementsByTagName(XMLString::transcode("component"));

	DOMElement* itlbElement = (DOMElement*)subcomponent0Lst->item(1);
	DOMNodeList* statitlbLst = itlbElement->getElementsByTagName(XMLString::transcode("stat"));
	DOMElement* statitlbElement = (DOMElement*)statitlbLst->item(0);
	if(statitlbElement){
		temp = "total_accesses";
		if(strcmp(XMLString::transcode(statitlbElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			itlb_accesses = (long) XMLString::parseInt(statitlbElement->getAttribute(XMLString::transcode("value")));
	}

	DOMElement* icacheElement = (DOMElement*)subcomponent0Lst->item(2);
	DOMNodeList* staticacheLst = icacheElement->getElementsByTagName(XMLString::transcode("stat"));
	DOMElement* staticacheElement = (DOMElement*)staticacheLst->item(0);
	if(staticacheElement){
		temp = "read_accesses";
		if(strcmp(XMLString::transcode(staticacheElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			icache_accesses = (long) XMLString::parseInt(staticacheElement->getAttribute(XMLString::transcode("value")));
	}
	 
	DOMElement* dtlbElement = (DOMElement*)subcomponent0Lst->item(3);
	DOMNodeList* statdtlbLst = dtlbElement->getElementsByTagName(XMLString::transcode("stat"));
	DOMElement* statdtlbElement = (DOMElement*)statdtlbLst->item(0);
	if(statdtlbElement){
		temp = "total_accesses";
		if(strcmp(XMLString::transcode(statdtlbElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			dtlb_accesses = (long) XMLString::parseInt(statdtlbElement->getAttribute(XMLString::transcode("value")));
	}
	

	DOMElement* dcacheElement = (DOMElement*)subcomponent0Lst->item(4);
	DOMNodeList* statdcacheLst = dcacheElement->getElementsByTagName(XMLString::transcode("stat"));
	DOMElement* statdcacheElement = (DOMElement*)statdcacheLst->item(0);
	if(statdcacheElement){
		temp = "read_accesses";
		if(strcmp(XMLString::transcode(statdcacheElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			dcache_readaccesses = (long) XMLString::parseInt(statdcacheElement->getAttribute(XMLString::transcode("value")));
		temp = "write_accesses";
		if(strcmp(XMLString::transcode(statdcacheElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			dcache_writeaccesses = (long) XMLString::parseInt(statdcacheElement->getAttribute(XMLString::transcode("value")));
	}

	DOMElement* btbElement = (DOMElement*)subcomponent0Lst->item(5);
	DOMNodeList* statbtbLst = btbElement->getElementsByTagName(XMLString::transcode("stat"));
	DOMElement* statbtbElement = (DOMElement*)statbtbLst->item(0);
	if(statbtbElement){
		temp = "read_accesses";
		if(strcmp(XMLString::transcode(statbtbElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			btb_readaccesses = (long) XMLString::parseInt(statbtbElement->getAttribute(XMLString::transcode("value")));
		temp = "write_accesses";
		if(strcmp(XMLString::transcode(statbtbElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			btb_writeaccesses = (long) XMLString::parseInt(statbtbElement->getAttribute(XMLString::transcode("value")));
	}
	

	DOMNodeList* dir1Lst = systemElement->getElementsByTagName(XMLString::transcode("component"));
	DOMElement* dir1Element = (DOMElement*)dir1Lst->item(7);
	DOMNodeList* statdir1Lst = dir1Element->getElementsByTagName(XMLString::transcode("stat"));
	DOMElement* statdir1Element = (DOMElement*)statdir1Lst->item(0);
	if(statdir1Element){
		temp = "read_accesses";
		if(strcmp(XMLString::transcode(statdir1Element->getAttribute(XMLString::transcode("name"))),temp)==0)
			dir1_readaccesses = (long) XMLString::parseInt(statdir1Element->getAttribute(XMLString::transcode("value")));
		temp = "write_accesses";
		if(strcmp(XMLString::transcode(statdir1Element->getAttribute(XMLString::transcode("name"))),temp)==0)
			dir1_writeaccesses = (long) XMLString::parseInt(statdir1Element->getAttribute(XMLString::transcode("value")));
	}

	DOMNodeList* l2Lst = systemElement->getElementsByTagName(XMLString::transcode("component"));
	DOMElement* l2Element = (DOMElement*)l2Lst->item(9);
	DOMNodeList* statl2Lst = l2Element->getElementsByTagName(XMLString::transcode("stat"));
	DOMElement* statl2Element = (DOMElement*)statl2Lst->item(0);
	if(statl2Element){
		temp = "read_accesses";
		if(strcmp(XMLString::transcode(statl2Element->getAttribute(XMLString::transcode("name"))),temp)==0)
			l2_readaccesses = (long) XMLString::parseInt(statl2Element->getAttribute(XMLString::transcode("value")));
		temp = "write_accesses";
		if(strcmp(XMLString::transcode(statl2Element->getAttribute(XMLString::transcode("name"))),temp)==0)
			l2_writeaccesses = (long) XMLString::parseInt(statl2Element->getAttribute(XMLString::transcode("value")));
	}
	

	DOMNodeList* l3Lst = systemElement->getElementsByTagName(XMLString::transcode("component"));
	DOMElement* l3Element = (DOMElement*)l3Lst->item(10);
	DOMNodeList* statl3Lst = l3Element->getElementsByTagName(XMLString::transcode("stat"));
	DOMElement* statl3Element = (DOMElement*)statl3Lst->item(0);
	if(statl3Element){
		temp = "read_accesses";
		if(strcmp(XMLString::transcode(statl3Element->getAttribute(XMLString::transcode("name"))),temp)==0)
			l3_readaccesses = (long) XMLString::parseInt(statl3Element->getAttribute(XMLString::transcode("value")));
		temp = "write_accesses";
		if(strcmp(XMLString::transcode(statl3Element->getAttribute(XMLString::transcode("name"))),temp)==0)
			l3_writeaccesses = (long) XMLString::parseInt(statl3Element->getAttribute(XMLString::transcode("value")));
	}

	DOMNodeList* nocLst = systemElement->getElementsByTagName(XMLString::transcode("component"));
	DOMElement* nocElement = (DOMElement*)nocLst->item(11);
	DOMNodeList* statnocLst = nocElement->getElementsByTagName(XMLString::transcode("stat"));
	DOMElement* statnocElement = (DOMElement*)statnocLst->item(0);
	if(statnocElement){
		temp = "total_accesses";
		if(strcmp(XMLString::transcode(statnocElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			noc_accesses = (long) XMLString::parseInt(statnocElement->getAttribute(XMLString::transcode("value")));
	}

	DOMNodeList* mcLst = systemElement->getElementsByTagName(XMLString::transcode("component"));
	DOMElement* mcElement = (DOMElement*)mcLst->item(12);
	DOMNodeList* statmcLst = mcElement->getElementsByTagName(XMLString::transcode("stat"));
	DOMElement* statmcElement = (DOMElement*)statmcLst->item(0);
	if(statmcElement){
		temp = "memory_accesses";
		if(strcmp(XMLString::transcode(statmcElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			mc_accesses = (long) XMLString::parseInt(statmcElement->getAttribute(XMLString::transcode("value")));
	}

	
}
void setConfigValues(DOMDocument* doc)
{
	string  str;
	ifstream rf;
	int core_frequency;
	double load_dynamicenergy,store_dynamicenergy,load_leakagepower,store_leakagepower,int_IW_dynamicenergy,flt_IW_dynamicenergy,int_IW_leakagepower,flt_IW_leakagepower;
	double link_dynamicenergy,link_leakagepower,router_dynamicenergy,router_leakagepower;
	double factor =1E+9;
	double factor1 = 1E+3;
	double total_power=0.0,b_pred=0.0,dummy;
	char *ch=NULL;
	

	doc->normalize();
	DOMNodeList* powerLst = doc->getElementsByTagName(XMLString::transcode("Power"));
	DOMElement* powerElement = (DOMElement*)powerLst->item(0);
	DOMNodeList* systemLst = doc->getElementsByTagName(XMLString::transcode("System"));
	DOMElement* systemElement = (DOMElement*)systemLst->item(0);
	DOMNodeList* libLst = doc->getElementsByTagName(XMLString::transcode("Library"));
	DOMElement* libElement = (DOMElement*)libLst->item(0);
	DOMNodeList* MainMemLst = systemElement->getElementsByTagName(XMLString::transcode("MainMemory"));
	DOMElement* MainMemElement = (DOMElement*)MainMemLst->item(0);
	DOMNodeList* ClockLst = systemElement->getElementsByTagName(XMLString::transcode("GlobalClock"));
	DOMElement* ClockElement = (DOMElement*)ClockLst->item(0);
	DOMNodeList* coreLst = systemElement->getElementsByTagName(XMLString::transcode("Core"));
	DOMElement* coreElement = (DOMElement*)coreLst->item(0);
	DOMNodeList* busLst = systemElement->getElementsByTagName(XMLString::transcode("BUS"));
	DOMElement* busElement = (DOMElement*)busLst->item(0);
	DOMNodeList* NOCLst = systemElement->getElementsByTagName(XMLString::transcode("NOC"));
	DOMElement* NOCElement = (DOMElement*)NOCLst->item(0);
	core_frequency = XMLString::parseInt(getValue(XMLString::transcode("CoreFrequency"),coreElement));
	DOMNodeList* PredictorLst = coreElement->getElementsByTagName(XMLString::transcode("BranchPredictor"));
	DOMElement* PredictorElement = (DOMElement*)PredictorLst->item(0);
	DOMNodeList* LSQLst = coreElement->getElementsByTagName(XMLString::transcode("LSQ"));
	DOMElement* LSQElement = (DOMElement*)LSQLst->item(0);
	DOMNodeList* ITLBLst = coreElement->getElementsByTagName(XMLString::transcode("ITLB"));
	DOMElement* ITLBElement = (DOMElement*)ITLBLst->item(0);
	DOMNodeList* DTLBLst = coreElement->getElementsByTagName(XMLString::transcode("DTLB"));
	DOMElement* DTLBElement = (DOMElement*)DTLBLst->item(0);
	DOMNodeList* DecodeLst = coreElement->getElementsByTagName(XMLString::transcode("Decode"));
	DOMElement* DecodeElement = (DOMElement*)DecodeLst->item(0);
	DOMNodeList* RenameLst = coreElement->getElementsByTagName(XMLString::transcode("Rename"));
	DOMElement* RenameElement = (DOMElement*)RenameLst->item(0);
	DOMNodeList* RATLst = RenameElement->getElementsByTagName(XMLString::transcode("RAT"));
	DOMElement* RATElement = (DOMElement*)RATLst->item(0);
	DOMNodeList* RATintLst = RATElement->getElementsByTagName(XMLString::transcode("Integer"));
	DOMElement* RATintElement = (DOMElement*)RATintLst->item(0);
	DOMNodeList* RATfltLst = RATElement->getElementsByTagName(XMLString::transcode("Float"));
	DOMElement* RATfltElement = (DOMElement*)RATfltLst->item(0);
	DOMNodeList* FreeLst = RenameElement->getElementsByTagName(XMLString::transcode("FreeList"));
	DOMElement* FreeElement = (DOMElement*)FreeLst->item(0);
	DOMNodeList* FreeintLst = FreeElement->getElementsByTagName(XMLString::transcode("Integer"));
	DOMElement* FreeintElement = (DOMElement*)FreeintLst->item(0);
	DOMNodeList* FreefltLst = FreeElement->getElementsByTagName(XMLString::transcode("Float"));
	DOMElement* FreefltElement = (DOMElement*)FreefltLst->item(0);
	DOMNodeList* IWLst = coreElement->getElementsByTagName(XMLString::transcode("InstructionWindow"));
	DOMElement* IWElement = (DOMElement*)IWLst->item(0);
	DOMNodeList* ROBLst = coreElement->getElementsByTagName(XMLString::transcode("ROB"));
	DOMElement* ROBElement = (DOMElement*)ROBLst->item(0);
	DOMNodeList* RFLst = coreElement->getElementsByTagName(XMLString::transcode("RegisterFile"));
	DOMElement* RFElement = (DOMElement*)RFLst->item(0);
	DOMNodeList* RFintLst = RFElement->getElementsByTagName(XMLString::transcode("Integer"));
	DOMElement* RFintElement = (DOMElement*)RFintLst->item(0);
	DOMNodeList* RFfltLst = RFElement->getElementsByTagName(XMLString::transcode("Float"));
	DOMElement* RFfltElement = (DOMElement*)RFfltLst->item(0);
	DOMNodeList* IntALULst = coreElement->getElementsByTagName(XMLString::transcode("IntALU"));
	DOMElement* IntALUElement = (DOMElement*)IntALULst->item(0);
	DOMNodeList* IntMulLst = coreElement->getElementsByTagName(XMLString::transcode("IntMul"));
	DOMElement* IntMulElement = (DOMElement*)IntMulLst->item(0);
	DOMNodeList* FltALULst = coreElement->getElementsByTagName(XMLString::transcode("FloatALU"));
	DOMElement* FltALUElement = (DOMElement*)FltALULst->item(0);
	DOMNodeList* IntDivLst = coreElement->getElementsByTagName(XMLString::transcode("IntDiv"));
	DOMElement* IntDivElement = (DOMElement*)IntDivLst->item(0);
	DOMNodeList* FltMulLst = coreElement->getElementsByTagName(XMLString::transcode("FloatMul"));
	DOMElement* FltMulElement = (DOMElement*)FltMulLst->item(0);
	DOMNodeList* FltDivLst = coreElement->getElementsByTagName(XMLString::transcode("FloatDiv"));
	DOMElement* FltDivElement = (DOMElement*)FltDivLst->item(0);
	DOMNodeList* JmpLst = coreElement->getElementsByTagName(XMLString::transcode("Jump"));
	DOMElement* JmpElement = (DOMElement*)JmpLst->item(0);
	DOMNodeList* MemLst = coreElement->getElementsByTagName(XMLString::transcode("Memory"));
	DOMElement* MemElement = (DOMElement*)MemLst->item(0);
	DOMNodeList* ResultsBroadcastBusLst = coreElement->getElementsByTagName(XMLString::transcode("ResultsBroadcastBus"));
	DOMElement* ResultsBroadcastBusElement = (DOMElement*)ResultsBroadcastBusLst->item(0);
	DOMNodeList* ICacheLst = libElement->getElementsByTagName(XMLString::transcode("ICache_32K_8"));
	DOMElement* ICacheElement = (DOMElement*)ICacheLst->item(0);
	DOMNodeList* L1CacheLst = libElement->getElementsByTagName(XMLString::transcode("L1Cache_32K_8"));
	DOMElement* L1CacheElement = (DOMElement*)L1CacheLst->item(0);
	DOMNodeList* L2CacheLst = libElement->getElementsByTagName(XMLString::transcode("L2Cache_256K_8"));
	DOMElement* L2CacheElement = (DOMElement*)L2CacheLst->item(0);
	DOMNodeList* L3CacheLst = libElement->getElementsByTagName(XMLString::transcode("L3Cache_4M_8"));
	DOMElement* L3CacheElement = (DOMElement*)L3CacheLst->item(0);
	DOMNodeList* D1Lst = libElement->getElementsByTagName(XMLString::transcode("Directory1"));
	DOMElement* D1Element = (DOMElement*)D1Lst->item(0);
	
	rf.open("output_power.txt");
	getline(rf,str);
	
	while(rf){
		char* buf=(char *)str.c_str();
		if(str.find("ICache Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("ReadDynamicEnergy"),ICacheElement,(atof(ch)*factor)/icache_accesses );
			setValue(XMLString::transcode("WriteDynamicEnergy"),ICacheElement,(atof(ch)*factor)/icache_accesses  );
			total_power +=atof(ch)*factor;
		}
		
		else if(str.find("ICache Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("icache_leakagepower"),powerElement,atof(ch));
			setValue(XMLString::transcode("LeakageEnergy"),ICacheElement,(atof(ch)*factor1)/core_frequency);
			
		}
		else if(str.find("BTB Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			b_pred = atof(ch);
			setValue(XMLString::transcode("btb_dynamicenergy"),powerElement,(atof(ch)*factor)/(btb_readaccesses+btb_writeaccesses) );
			total_power +=atof(ch)*factor;
		}
		else if(str.find("BTB Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			b_pred = atof(ch);
			setValue(XMLString::transcode("btb_leakagepower"),powerElement,atof(ch) );
			
		}
		else if(str.find("BPT Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("DynamicEnergy"),PredictorElement,(atof(ch)*factor)/branch_instructions  );
			total_power +=atof(ch)*factor;
		}
		else if(str.find("BPT Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("bpred_leakagepower"),powerElement,atof(ch));
			setValue(XMLString::transcode("LeakageEnergy"),PredictorElement,(atof(ch)*factor1)/core_frequency  );
			
		}
		else if(str.find("Decode Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("DynamicEnergy"),DecodeElement,(atof(ch)*factor)/total_instructions );
		}
		else if(str.find("Decode Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("Decodeleakagepower"),powerElement,atof(ch) );
			setValue(XMLString::transcode("LeakageEnergy"),DecodeElement,(atof(ch)*factor1)/core_frequency );
		}
		else if(str.find("Total RAT power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("rat_power"),powerElement,atof(ch) );
			total_power +=atof(ch)*factor;
			setValue(XMLString::transcode("dcl_power"),powerElement,0  );
		}
		else if(str.find("RAT Integer Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("DynamicEnergy"),RATintElement,(atof(ch)*factor)/(rename_reads+rename_writes));
			total_power +=atof(ch)*factor;
		}
		else if(str.find("RAT Integer Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("ratint_leakagepower"),powerElement,atof(ch)  );
			setValue(XMLString::transcode("LeakageEnergy"),RATintElement,(atof(ch)*factor1)/core_frequency  );
		}
		else if(str.find("RAT Float Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("DynamicEnergy"),RATfltElement,(atof(ch)*factor)/(fp_rename_reads+fp_rename_writes)  );
			total_power +=atof(ch)*factor;
		}
		else if(str.find("RAT Float Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("ratflt_leakagepower"),powerElement,atof(ch)  );
			setValue(XMLString::transcode("LeakageEnergy"),RATfltElement,(atof(ch)*factor1)/core_frequency  );

		}

		else if(str.find("FreeList Integer Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			rename_accesses = rename_reads + rename_writes;
			setValue(XMLString::transcode("DynamicEnergy"),FreeintElement,(atof(ch)*factor)/(rename_reads + rename_writes) );
			total_power +=atof(ch)*factor;
		}

		else if(str.find("FreeList Float Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("DynamicEnergy"),FreefltElement,(atof(ch)*factor)/(fp_rename_reads+fp_rename_writes)  );
			total_power +=atof(ch)*factor;
		}
		
		else if(str.find("FreeList Integer Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("LeakageEnergy"),FreeintElement,(atof(ch)*factor1)/core_frequency  );
		}

		else if(str.find("FreeList Float Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("LeakageEnergy"),FreefltElement,(atof(ch)*factor1)/core_frequency  );
		}
		
		else if(str.find("Dcache Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
            setValue(XMLString::transcode("ReadDynamicEnergy"),L1CacheElement,(atof(ch)*factor)/(dcache_readaccesses+dcache_writeaccesses)  );
            setValue(XMLString::transcode("WriteDynamicEnergy"),L1CacheElement,(atof(ch)*factor)/(dcache_readaccesses+dcache_writeaccesses)  );
			total_power +=atof(ch)*factor;
		}
		else if(str.find("Dcache Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("dcache_leakagepower"),powerElement,atof(ch) );
			setValue(XMLString::transcode("LeakageEnergy"),L1CacheElement,(atof(ch)*factor1)/core_frequency );
		}
		else if(str.find("Load Buffer Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			load_dynamicenergy =(atof(ch)*factor)/(load_instructions+store_instructions);
		}
		else if(str.find("Load Buffer Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("loadbuffer_leakagepower"),powerElement,atof(ch) );
			load_leakagepower=atof(ch);
		}	
		else if(str.find("Store Buffer Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			store_dynamicenergy=(atof(ch)*factor)/(2*(load_instructions+store_instructions));
			setValue(XMLString::transcode("DynamicEnergy"),LSQElement,(load_dynamicenergy+store_dynamicenergy));
		}
		else if(str.find("Store Buffer Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("store_leakagepower"),powerElement,atof(ch));
			store_leakagepower=atof(ch);
			setValue(XMLString::transcode("LeakageEnergy"),LSQElement,((store_leakagepower+load_leakagepower)*factor1)/core_frequency);
		}
		
		else if(str.find("Itlb Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("DynamicEnergy"),ITLBElement,(atof(ch)*factor)/itlb_accesses  );
			total_power +=atof(ch)*factor;
		}
		else if(str.find("Itlb Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("itlb_leakagepower"),powerElement,atof(ch)  );
			setValue(XMLString::transcode("LeakageEnergy"),ITLBElement,(atof(ch)*factor1)/core_frequency  );
		}
		else if(str.find("Dtlb Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("DynamicEnergy"),DTLBElement,(atof(ch)*factor)/dtlb_accesses  );
			total_power +=atof(ch)*factor;
		}
		else if(str.find("Dtlb Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("dtlb_leakagepower"),powerElement,atof(ch)  );
			setValue(XMLString::transcode("LeakageEnergy"),DTLBElement,(atof(ch)*factor1)/core_frequency  );
		}
		else if(str.find("Register File Integer Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("DynamicEnergy"),RFintElement,(atof(ch)*factor)/(int_regfile_reads+int_regfile_writes) );
			total_power +=atof(ch)*factor;
		}
		else if(str.find("Register File Float Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("DynamicEnergy"),RFfltElement,(atof(ch)*factor)/(float_regfile_reads+float_regfile_writes) );
			total_power +=atof(ch)*factor;
		}
		else if(str.find("Register File Integer Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("regfileint_leakagepower"),powerElement,atof(ch) );
			setValue(XMLString::transcode("LeakageEnergy"),RFintElement,(atof(ch)*factor1)/core_frequency );
		}
		else if(str.find("Register File Float Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("regfileflt_leakagepower"),powerElement,atof(ch) );
			setValue(XMLString::transcode("LeakageEnergy"),RFfltElement,(atof(ch)*factor1)/core_frequency );
		}
		else if(str.find("Integer Instruction Window Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			int_IW_dynamicenergy=(atof(ch)*factor)/(inst_window_reads+inst_window_writes+inst_window_wakeup_accesses);
			total_power +=atof(ch)*factor;
		}
		else if(str.find("Integer Instruction Window Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			int_IW_leakagepower = atof(ch);
			setValue(XMLString::transcode("instwindow_leakagepower"),powerElement,atof(ch) );
		}

		else if(str.find("Float Instruction Window Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			flt_IW_dynamicenergy=(atof(ch)*factor)/(fp_inst_window_reads+fp_inst_window_wakeup_accesses+fp_inst_window_writes);
			setValue(XMLString::transcode("DynamicEnergy"),IWElement,flt_IW_dynamicenergy+int_IW_dynamicenergy );
			total_power +=atof(ch)*factor;
		}
		else if(str.find("Float Instruction Window Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			flt_IW_leakagepower = atof(ch);
			setValue(XMLString::transcode("instwindow_leakagepower"),powerElement,atof(ch) );
			setValue(XMLString::transcode("LeakageEnergy"),IWElement,((flt_IW_leakagepower+int_IW_leakagepower)*factor1)/core_frequency  );
		}

		else if(str.find("ROB Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("DynamicEnergy"),ROBElement,(atof(ch)*factor)/(ROB_reads+ROB_writes) );
		}
		else if(str.find("ROB Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("ROB_leakagepower"),powerElement,atof(ch));
			setValue(XMLString::transcode("LeakageEnergy"),ROBElement,(atof(ch)*factor1)/core_frequency  );
		}
		else if(str.find("Integer ALU Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("DynamicEnergy"),IntALUElement,(atof(ch)*factor)/ialu_accesses );
			total_power +=atof(ch)*factor;
		}
		else if(str.find("Integer ALU Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("ialu_leakagepower"),powerElement,atof(ch));
			setValue(XMLString::transcode("LeakageEnergy"),IntALUElement,(atof(ch)*factor1)/core_frequency  );
		}
		else if(str.find("FPU Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("DynamicEnergy"),FltALUElement,(atof(ch)*factor)/fpu_accesses );
			setValue(XMLString::transcode("DynamicEnergy"),FltMulElement,(atof(ch)*factor)/fpu_accesses );
			setValue(XMLString::transcode("DynamicEnergy"),FltDivElement,(atof(ch)*factor)/fpu_accesses);
			total_power +=atof(ch)*factor;
		}
		else if(str.find("FPU Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("falu_leakagepower"),powerElement,atof(ch));
			setValue(XMLString::transcode("LeakageEnergy"),FltALUElement,(atof(ch)*factor1)/core_frequency  );
			setValue(XMLString::transcode("LeakageEnergy"),FltMulElement,(atof(ch)*factor1)/core_frequency  );
			setValue(XMLString::transcode("LeakageEnergy"),FltDivElement,(atof(ch)*factor1)/core_frequency  );
			
		}
		else if(str.find("Integer MUL Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("DynamicEnergy"),IntMulElement,(atof(ch)*factor)/mul_accesses );
			setValue(XMLString::transcode("DynamicEnergy"),IntDivElement,(atof(ch)*factor)/mul_accesses);
			setValue(XMLString::transcode("DynamicEnergy"),JmpElement,(atof(ch)*factor)/mul_accesses);
			setValue(XMLString::transcode("DynamicEnergy"),MemElement,(atof(ch)*factor)/mul_accesses );
			total_power +=atof(ch)*factor;
		}
		else if(str.find("Integer MUL Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("imul_leakagepower"),powerElement,atof(ch));
			setValue(XMLString::transcode("LeakageEnergy"),IntMulElement,(atof(ch)*factor1)/core_frequency  );
			setValue(XMLString::transcode("LeakageEnergy"),IntDivElement,(atof(ch)*factor1)/core_frequency  );
			setValue(XMLString::transcode("LeakageEnergy"),JmpElement,(atof(ch)*factor1)/core_frequency  );
			setValue(XMLString::transcode("LeakageEnergy"),MemElement,(atof(ch)*factor1)/core_frequency  );
		}
		else if(str.find("ResultsBroadcastBus Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("DynamicEnergy"),ResultsBroadcastBusElement,(atof(ch)*factor)/(cdb_fpu_accesses+cdb_ialu_accesses+cdb_mul_accesses) );
			total_power +=atof(ch)*factor;
		}
		else if(str.find("ResultsBroadcastBus Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("resultsbroadbus_leakagepower"),powerElement,atof(ch));
			setValue(XMLString::transcode("LeakageEnergy"),ResultsBroadcastBusElement,(atof(ch)*factor1)/core_frequency  );

		}
		else if(str.find("MMU Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("mmu_dynamicenergy"),powerElement,atof(ch)*factor );
			total_power +=atof(ch)*factor;
		}
		else if(str.find("MMU Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("mmu_leakagepower"),powerElement,atof(ch));
		}
		else if(str.find("L2 Cache Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("ReadDynamicEnergy"),L2CacheElement,(atof(ch)*factor)/(l2_readaccesses+l2_writeaccesses) );
			setValue(XMLString::transcode("WriteDynamicEnergy"),L2CacheElement,(atof(ch)*factor)/(l2_readaccesses+l2_writeaccesses) );
			total_power +=atof(ch)*factor;
		}
		else if(str.find("L2 Cache Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("dcache2_leakagepower"),powerElement,atof(ch) );
			setValue(XMLString::transcode("LeakageEnergy"),L2CacheElement,(atof(ch)*factor1)/core_frequency  );

		}
		else if(str.find("L3 Cache Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("ReadDynamicEnergy"),L3CacheElement,(atof(ch)*factor)/(l3_readaccesses+l3_writeaccesses) );
			setValue(XMLString::transcode("WriteDynamicEnergy"),L3CacheElement,(atof(ch)*factor)/(l3_readaccesses+l3_writeaccesses) );
			total_power +=atof(ch)*factor;
		}
		else if(str.find("L3 Cache Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("dcache3_leakagepower"),powerElement,atof(ch) );
			setValue(XMLString::transcode("LeakageEnergy"),L3CacheElement,(atof(ch)*factor1)/core_frequency  );

		}
		else if(str.find("MemoryController Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("DynamicEnergy"),MainMemElement,(atof(ch)*factor)/(mc_accesses) );
			total_power +=atof(ch)*factor;
		}
		else if(str.find("MemoryController Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("memcntrl_leakagepower"),powerElement,atof(ch));
			setValue(XMLString::transcode("LeakageEnergy"),MainMemElement,(atof(ch)*factor1)/core_frequency );
		}
		

		else if(str.find("D1 Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("ReadDynamicEnergy"),D1Element,(atof(ch)*factor)/(dir1_readaccesses+dir1_writeaccesses) );
			setValue(XMLString::transcode("WriteDynamicEnergy"),D1Element,(atof(ch)*factor)/(dir1_readaccesses+dir1_writeaccesses) );
		}

		else if(str.find("D1 Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("D1leakagepower"),powerElement,atof(ch) );
			setValue(XMLString::transcode("LeakageEnergy"),D1Element,(atof(ch)*factor1)/core_frequency );
		}

		else if(str.find("Clock Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("DynamicEnergy"),ClockElement,(atof(ch)*factor) );
		}

		else if(str.find("Clock Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("LeakageEnergy"),ClockElement,(atof(ch)*factor1)/core_frequency );
		}


		else if(str.find("Router Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			router_dynamicenergy=(atof(ch)*factor);
		}
		else if(str.find("Router Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			router_leakagepower=atof(ch);
			setValue(XMLString::transcode("Routerleakagepower"),powerElement,atof(ch) );
		}
		else if(str.find("Link Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			link_dynamicenergy=(atof(ch)*factor);
			setValue(XMLString::transcode("DynamicEnergy"),NOCElement,link_dynamicenergy+router_dynamicenergy );
			setValue(XMLString::transcode("DynamicEnergy"),busElement,link_dynamicenergy );

		}
		else if(str.find("Link Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			link_leakagepower=atof(ch);
			setValue(XMLString::transcode("Linkleakagepower"),powerElement,atof(ch) );
			setValue(XMLString::transcode("LeakageEnergy"),NOCElement,((link_leakagepower+router_leakagepower)*factor1)/core_frequency );
            setValue(XMLString::transcode("LeakageEnergy"),busElement,((link_leakagepower)*factor1)/core_frequency );

		}

		
		getline(rf,str);
	}

	rf.close();
}

int main(int argC, char* argV[]) throw( std::runtime_error )
{
	cout<<"Started writing new power values!"<<endl;
	try
   	{
      	XMLPlatformUtils::Initialize();  // Initialize Xerces infrastructure
   	}
   	catch( XMLException& e )
   	{
	    char* message = XMLString::transcode( e.getMessage() );
     	cerr << "XML toolkit initialization error: " << message << endl;
      	XMLString::release( &message );
   		// throw exception here to return ERROR_XERCES_INIT
   	}
	//cout<<"XML initialization done!"<<endl;

	if (argC < 2)
   	{
	//  usage();
        XMLPlatformUtils::Terminate();
        return 1;
    }
	string configFile=argV[1];
   	xercesc::XercesDOMParser *ConfigFileParser=new xercesc::XercesDOMParser;
   	   	xercesc::XercesDOMParser *InputFileParser=new xercesc::XercesDOMParser;

	//cout<<"Config file found!"<<endl;

   // Configure DOM parser.
   	ConfigFileParser->setValidationScheme( XercesDOMParser::Val_Auto );
   	ConfigFileParser->setDoNamespaces( false );
   	ConfigFileParser->setDoSchema( false );
   InputFileParser->setValidationScheme( XercesDOMParser::Val_Auto );
   	InputFileParser->setDoNamespaces( false );
   	InputFileParser->setDoSchema( false );
    //ConfigFileParser->setLoadExternalDTD( false );
	//cout<<"DOM parser configured!"<<endl;

   	try
   	{
      	ConfigFileParser->parse( configFile.c_str() );
		InputFileParser->parse( "input.xml");
   	}
   	catch( xercesc::XMLException& e )
   	{
      	char* message = xercesc::XMLString::transcode( e.getMessage() );
      	ostringstream errBuf;
    	errBuf << "Error parsing file: " << message << flush;
      	XMLString::release( &message );
   	}

   	// no need to free this pointer - owned by the parent parser object
   	DOMDocument* doc = ConfigFileParser->getDocument();
	 DOMDocument* input = InputFileParser->getDocument();
	//cout<<"DOMDocument created!"<<endl;
      
	XMLCh tempStr[3] = {chLatin_L, chLatin_S, chNull};
	DOMImplementation *impl          = DOMImplementationRegistry::getDOMImplementation(tempStr);
    DOMLSSerializer   *theSerializer = ((DOMImplementationLS*)impl)->createLSSerializer();
    DOMLSOutput       *theOutputDesc = ((DOMImplementationLS*)impl)->createLSOutput();
	XMLFormatTarget *myFormTarget;
		
	string str = configFile;
    myFormTarget=new LocalFileFormatTarget(str.c_str());
    theOutputDesc->setByteStream(myFormTarget);
    cout<<"Setting new power values!"<<endl;
	getAccessValues(input);
//	cout<<"access value error!"<<endl;
    setConfigValues(doc);
    cout<<"New power values set!"<<endl;
	theSerializer->write(doc, theOutputDesc);
		
	theOutputDesc->release();
	theSerializer->release();
	cout<<"Done Writing!"<<endl;
		
    delete myFormTarget;
    delete ConfigFileParser;
    XMLPlatformUtils::Terminate();
	return 0;
}
