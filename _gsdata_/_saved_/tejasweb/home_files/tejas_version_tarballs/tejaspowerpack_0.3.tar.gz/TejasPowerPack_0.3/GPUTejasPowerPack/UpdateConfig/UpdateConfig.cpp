#include <string>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <list>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <xercesc/framework/LocalFileFormatTarget.hpp>

#include <xercesc/dom/DOM.hpp>
#include <xercesc/dom/DOMDocument.hpp>
#include <xercesc/dom/DOMDocumentType.hpp>
#include <xercesc/dom/DOMElement.hpp>
#include <xercesc/dom/DOMImplementation.hpp>
#include <xercesc/dom/DOMImplementationLS.hpp>
#include <xercesc/dom/DOMNodeIterator.hpp>
#include <xercesc/dom/DOMNodeList.hpp>
#include <xercesc/dom/DOMText.hpp>

#include <xercesc/parsers/XercesDOMParser.hpp>
#include <xercesc/util/XMLUni.hpp>

#include <fstream>
#include <stdexcept>
#include <typeinfo>
#include <cmath>
#include <cstdlib>

using namespace xercesc;
using namespace std;

const XMLCh* getValue(const XMLCh* tagName, DOMElement* parent) // Get the immediate string value of a particular tag name under a particular parent tag
{
		DOMNodeList* nodeLst = parent->getElementsByTagName(tagName);
		if (nodeLst->item(0) == NULL)
		{
			return NULL;
			//XERCES_STD_QUALIFIER cerr<<"XML Configuration error : Item \"" << tagName << "\" not found inside the \""
			//<< parent->getTagName()<< "\" tag in the configuration file!!"<< XERCES_STD_QUALIFIER endl;
		}
	    DOMElement* NodeElmnt = (DOMElement*) nodeLst->item(0);
	    DOMNodeList* resultNode = NodeElmnt->getChildNodes();
	    return ((DOMNode*) resultNode->item(0))->getNodeValue();
}

string to_string(double x)
{
  ostringstream ss;
  ss << x;
  return ss.str();
}

void setValue(const XMLCh* tagName, DOMElement* parent, double val) // Get the immediate string value of a particular tag name under a particular parent tag
{
		string str = to_string(val);
		const XMLCh* value=XMLString::transcode(str.c_str());
		DOMNodeList* nodeLst = parent->getElementsByTagName(tagName);
		if (nodeLst->item(0) == NULL)
		{
			XERCES_STD_QUALIFIER cerr<<"XML Configuration error : Item \"" << tagName << "\" not found inside the \""
			<< parent->getTagName()<< "\" tag in the configuration file!!"<< XERCES_STD_QUALIFIER endl;
		}
	    DOMElement* NodeElmnt = (DOMElement*) nodeLst->item(0);
	    DOMNodeList* resultNode = NodeElmnt->getChildNodes();
	    return ((DOMNode*) resultNode->item(0))->setNodeValue(value);
}
	

int baseline_technology;
int core_frequency;
int int_alu_num;
int int_mul_num;
int float_alu_num;

int constcache_blocksize;
int constcache_assoc;
int constcache_size;
int constcache_latency;

int icache_blocksize;
int icache_assoc;
int icache_size;
int icache_latency;

int dcache_blocksize;
int dcache_assoc;
int dcache_size;
int dcache_latency;

int l2cache_blocksize;
int l2cache_assoc;
int l2cache_size;
int l2cache_latency;

int sharedcache_blocksize;
int sharedcache_assoc;
int sharedcache_size;
int sharedcache_latency;

void getConfigValues(DOMDocument* doc)
{
	doc->normalize();
	DOMNodeList* simulationLst = doc->getElementsByTagName(XMLString::transcode("Simulation"));
	DOMElement* simulationElement = (DOMElement*)simulationLst->item(0);
	
	baseline_technology = XMLString::parseInt(getValue(XMLString::transcode("baseline_technology"),simulationElement));
	DOMNodeList* systemLst = doc->getElementsByTagName(XMLString::transcode("System"));
	DOMElement* systemElement = (DOMElement*)systemLst->item(0);
	DOMNodeList* tpcLst = systemElement->getElementsByTagName(XMLString::transcode("TPC"));
	DOMElement* tpcElement = (DOMElement*)tpcLst->item(0);
	DOMNodeList* smLst = tpcElement->getElementsByTagName(XMLString::transcode("SM"));
	DOMElement* smElement = (DOMElement*)smLst->item(0);
	core_frequency = XMLString::parseInt(getValue(XMLString::transcode("Frequency"),smElement));
	
	DOMNodeList* IntALULst = smElement->getElementsByTagName(XMLString::transcode("IntALU"));
	DOMElement* IntALUElement = (DOMElement*)IntALULst->item(0);
	int_alu_num = XMLString::parseInt(getValue(XMLString::transcode("Num"),IntALUElement));
	DOMNodeList* IntMulLst = smElement->getElementsByTagName(XMLString::transcode("IntMul"));
	DOMElement* IntMulElement = (DOMElement*)IntMulLst->item(0);
	int_mul_num = XMLString::parseInt(getValue(XMLString::transcode("Num"),IntMulElement));
	DOMNodeList* FloatALULst = smElement->getElementsByTagName(XMLString::transcode("FloatALU"));
	DOMElement* FloatALUElement = (DOMElement*)FloatALULst->item(0);
	float_alu_num = XMLString::parseInt(getValue(XMLString::transcode("Num"),FloatALUElement));
	
	
	DOMNodeList* libLst = doc->getElementsByTagName(XMLString::transcode("Library"));
	DOMElement* libElement = (DOMElement*)libLst->item(0);
	
	DOMNodeList* InstCacheLst = libElement->getElementsByTagName(XMLString::transcode("iCache"));
	DOMElement* InstCacheElement = (DOMElement*)InstCacheLst->item(0);
	icache_blocksize = XMLString::parseInt(getValue(XMLString::transcode("BlockSize"),InstCacheElement));
	icache_assoc = XMLString::parseInt(getValue(XMLString::transcode("Associativity"),InstCacheElement));
	icache_size = XMLString::parseInt(getValue(XMLString::transcode("Size"),InstCacheElement));
	icache_latency = XMLString::parseInt(getValue(XMLString::transcode("Latency"),InstCacheElement));
	
	DOMNodeList* constCacheLst = libElement->getElementsByTagName(XMLString::transcode("constantCache"));
	DOMElement* constCacheElement = (DOMElement*)constCacheLst->item(0);
	constcache_blocksize = XMLString::parseInt(getValue(XMLString::transcode("BlockSize"),constCacheElement));
	constcache_assoc = XMLString::parseInt(getValue(XMLString::transcode("Associativity"),constCacheElement));
	constcache_size = XMLString::parseInt(getValue(XMLString::transcode("Size"),constCacheElement));
	constcache_latency = XMLString::parseInt(getValue(XMLString::transcode("Latency"),constCacheElement));
	
	DOMNodeList* sharedCacheLst = libElement->getElementsByTagName(XMLString::transcode("sharedCache"));
	DOMElement* sharedCacheElement = (DOMElement*)sharedCacheLst->item(0);
	sharedcache_blocksize = XMLString::parseInt(getValue(XMLString::transcode("BlockSize"),sharedCacheElement));
	sharedcache_assoc = XMLString::parseInt(getValue(XMLString::transcode("Associativity"),sharedCacheElement));
	sharedcache_size = XMLString::parseInt(getValue(XMLString::transcode("Size"),sharedCacheElement));
	sharedcache_latency = XMLString::parseInt(getValue(XMLString::transcode("Latency"),sharedCacheElement));
	
	DOMNodeList* dcacheLst = libElement->getElementsByTagName(XMLString::transcode("dCache"));
	DOMElement* dcacheElement = (DOMElement*)dcacheLst->item(0);
	dcache_blocksize = XMLString::parseInt(getValue(XMLString::transcode("BlockSize"),dcacheElement));
	dcache_assoc = XMLString::parseInt(getValue(XMLString::transcode("Associativity"),dcacheElement));
	dcache_size = XMLString::parseInt(getValue(XMLString::transcode("Size"),dcacheElement));
	dcache_latency = XMLString::parseInt(getValue(XMLString::transcode("Latency"),dcacheElement));

	DOMNodeList* L2CacheLst = libElement->getElementsByTagName(XMLString::transcode("L2"));
	DOMElement* L2CacheElement = (DOMElement*)L2CacheLst->item(0);
	l2cache_blocksize = XMLString::parseInt(getValue(XMLString::transcode("BlockSize"),L2CacheElement));
	l2cache_assoc = XMLString::parseInt(getValue(XMLString::transcode("Associativity"),L2CacheElement));
	l2cache_size = XMLString::parseInt(getValue(XMLString::transcode("Size"),L2CacheElement));
	l2cache_latency = XMLString::parseInt(getValue(XMLString::transcode("Latency"),L2CacheElement));
	
}

void setInputValues(DOMDocument* doc)
{
	string str = "value";
	const XMLCh* attr=XMLString::transcode(str.c_str());
	
	DOMNodeList* inputLst = doc->getElementsByTagName(XMLString::transcode("component"));
	DOMElement* rootElement = (DOMElement*)inputLst->item(0);
	DOMNodeList* systemLst = rootElement->getElementsByTagName(XMLString::transcode("component"));
	DOMElement* systemElement = (DOMElement*)systemLst->item(0);
	DOMNodeList* paramLst = systemElement->getElementsByTagName(XMLString::transcode("param"));
	
	
	DOMElement* techElement = (DOMElement*)paramLst->item(14);
	techElement->setAttribute(attr,XMLString::transcode(to_string(baseline_technology).c_str()));
	
	DOMElement* coreFreqElement = (DOMElement*)paramLst->item(15);
	coreFreqElement->setAttribute(attr,XMLString::transcode(to_string(core_frequency).c_str()));
	
	DOMNodeList* componentLst = systemElement->getElementsByTagName(XMLString::transcode("component"));
	DOMElement* component0Element = (DOMElement*)componentLst->item(0);
	
	paramLst = component0Element->getElementsByTagName(XMLString::transcode("param"));
	coreFreqElement = (DOMElement*)paramLst->item(0);
	coreFreqElement->setAttribute(attr,XMLString::transcode(to_string(core_frequency).c_str()));
	
	
	DOMElement* aluPerCoreElement = (DOMElement*)paramLst->item(20);
	aluPerCoreElement->setAttribute(attr,XMLString::transcode(to_string(int_alu_num).c_str()));
	
	DOMElement* mulPerCoreElement = (DOMElement*)paramLst->item(21);
	mulPerCoreElement->setAttribute(attr,XMLString::transcode(to_string(int_mul_num).c_str()));
	
	DOMElement* floatPerCoreElement = (DOMElement*)paramLst->item(22);
	floatPerCoreElement->setAttribute(attr,XMLString::transcode(to_string(float_alu_num).c_str()));
	
	
	DOMNodeList* subcomponent0Lst = component0Element->getElementsByTagName(XMLString::transcode("component"));
	
	DOMElement* icacheElement = (DOMElement*)subcomponent0Lst->item(2);
	paramLst = icacheElement->getElementsByTagName(XMLString::transcode("param"));
	DOMElement* icacheconfigElement = (DOMElement*)paramLst->item(0);
	icacheconfigElement->setAttribute(attr,XMLString::transcode((to_string(icache_size)+"," + to_string(icache_blocksize) + "," + to_string(icache_assoc) + ",1,16," + to_string(icache_latency) + ",32,0").c_str()));
	
	DOMElement* constcacheElement = (DOMElement*)subcomponent0Lst->item(4);
	paramLst = constcacheElement->getElementsByTagName(XMLString::transcode("param"));
	DOMElement* constcacheconfigElement = (DOMElement*)paramLst->item(0);
	constcacheconfigElement->setAttribute(attr,XMLString::transcode((to_string(constcache_size)+"," + to_string(constcache_blocksize) + "," + to_string(constcache_assoc) + ",1,3," + to_string(constcache_latency) + ",16,1").c_str()));
	
	DOMElement* sharedcacheElement = (DOMElement*)subcomponent0Lst->item(6);
	paramLst = sharedcacheElement->getElementsByTagName(XMLString::transcode("param"));
	DOMElement* sharedcacheconfigElement = (DOMElement*)paramLst->item(0);
	sharedcacheconfigElement->setAttribute(attr,XMLString::transcode((to_string(sharedcache_size)+"," + to_string(sharedcache_blocksize) + "," + to_string(sharedcache_assoc) + ",1,3," + to_string(sharedcache_latency) + ",32,1").c_str()));
	
	DOMElement* dcacheElement = (DOMElement*)subcomponent0Lst->item(7);
	paramLst = dcacheElement->getElementsByTagName(XMLString::transcode("param"));
	DOMElement* dcacheconfigElement = (DOMElement*)paramLst->item(0);
	dcacheconfigElement->setAttribute(attr,XMLString::transcode((to_string(dcache_size)+"," + to_string(dcache_blocksize) + "," + to_string(dcache_assoc) + ",1,3," + to_string(dcache_latency) + ",32,1").c_str()));
	
	
	
	componentLst = systemElement->getElementsByTagName(XMLString::transcode("component"));
	DOMElement* component9Element = (DOMElement*)componentLst->item(12);
	paramLst = component9Element->getElementsByTagName(XMLString::transcode("param"));
	DOMElement* l2configElement = (DOMElement*)paramLst->item(0);
	l2configElement->setAttribute(attr,XMLString::transcode((to_string(l2cache_size)+"," + to_string(l2cache_blocksize) + "," + to_string(l2cache_assoc) + ",8,8," + to_string(l2cache_latency) + ",32,1").c_str()));
}

int main(int argC, char* argV[]) throw( std::runtime_error )
{
	cout<<"Updating mcpat input file!"<<endl;
	try
   	{
      	XMLPlatformUtils::Initialize();  // Initialize Xerces infrastructure
   	}
   	catch( XMLException& e )
   	{
	    char* message = XMLString::transcode( e.getMessage() );
     	cerr << "XML toolkit initialization error: " << message << endl;
      	XMLString::release( &message );
   		// throw exception here to return ERROR_XERCES_INIT
   	}
	//cout<<"Done 1"<<endl;

	if (argC < 2)
   	{
	//  usage();
       	XMLPlatformUtils::Terminate();
       	return 1;
    }
	string configFile=argV[1];
   	xercesc::XercesDOMParser *ConfigFileParser=new xercesc::XercesDOMParser;
   	xercesc::XercesDOMParser *InputFileParser=new xercesc::XercesDOMParser;

	//cout<<"Done 2"<<endl;

   // Configure DOM parser.

   	ConfigFileParser->setValidationScheme( XercesDOMParser::Val_Auto );
   	ConfigFileParser->setDoNamespaces( false );
   	ConfigFileParser->setDoSchema( false );
   
   	InputFileParser->setValidationScheme( XercesDOMParser::Val_Auto );
   	InputFileParser->setDoNamespaces( false );
   	InputFileParser->setDoSchema( false );
//   ConfigFileParser->setLoadExternalDTD( false );
	//cout<<"Done 3"<<endl;

   	try
   	{
      	ConfigFileParser->parse( configFile.c_str() );
      	InputFileParser->parse( "input.xml");
   	}
   	catch( xercesc::XMLException& e )
   	{
      	char* message = xercesc::XMLString::transcode( e.getMessage() );
      	ostringstream errBuf;
    	errBuf << "Error parsing file: " << message << flush;
      	XMLString::release( &message );
   	}

    // no need to free this pointer - owned by the parent parser object
    DOMDocument* doc = ConfigFileParser->getDocument();
    DOMDocument* input = InputFileParser->getDocument();

	cout<<"Getting values from config file!"<<endl;
	getConfigValues(doc);
	cout<<"Setting values in input file!"<<endl;	
	setInputValues(input);
		
      
	XMLCh tempStr[3] = {chLatin_L, chLatin_S, chNull};
	DOMImplementation *impl          = DOMImplementationRegistry::getDOMImplementation(tempStr);
    DOMLSSerializer   *theSerializer = ((DOMImplementationLS*)impl)->createLSSerializer();
    DOMLSOutput       *theOutputDesc = ((DOMImplementationLS*)impl)->createLSOutput();
	XMLFormatTarget *myFormTarget;
	
	string str = "input.xml";
    myFormTarget=new LocalFileFormatTarget(str.c_str());
    theOutputDesc->setByteStream(myFormTarget);
	
	theSerializer->write(input, theOutputDesc);
	cout<<"Done Writing!"<<endl;
	theOutputDesc->release();
	theSerializer->release();
	//cout<<"Add Done 8"<<endl;
		
    delete myFormTarget;
    delete ConfigFileParser;
    XMLPlatformUtils::Terminate();
	return 0;
}
