cd cacti/
make
cd ../
cp -r $(pwd)/cacti/obj_opt/ $(pwd)/obj_opt/
g++ -m32 -c main.cc
cp $(pwd)/main.o $(pwd)/obj_opt/main.o	
make
g++ -c -I/opt/include updateGPUParameters.cpp
g++ -o updateGPUParameters updateGPUParameters.o -L/opt/lib -lxerces-c 
./updateGPUParameters $(pwd)/config.xml
g++ -c -I/opt/include UpdateConfig.cpp
g++ -o updateConfig UpdateConfig.o -L/opt/lib -lxerces-c 
./updateConfig $(pwd)/config.xml
./mcpat -infile input.xml -print_level 5 >output13.txt
g++ -c -I/opt/include UpdatePower.cpp
g++ -o updatePower UpdatePower.o -L/opt/lib -lxerces-c 
cp -v $(pwd)/config.xml $(pwd)/config_Gtpp.xml
./updatePower $(pwd)/config_Gtpp.xml
rm -rf output_power.txt
