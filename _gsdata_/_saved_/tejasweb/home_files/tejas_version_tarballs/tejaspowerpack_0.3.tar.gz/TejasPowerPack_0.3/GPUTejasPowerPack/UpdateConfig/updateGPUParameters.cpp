#include <string>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <list>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <xercesc/framework/LocalFileFormatTarget.hpp>

#include <xercesc/dom/DOM.hpp>
#include <xercesc/dom/DOMDocument.hpp>
#include <xercesc/dom/DOMDocumentType.hpp>
#include <xercesc/dom/DOMElement.hpp>
#include <xercesc/dom/DOMImplementation.hpp>
#include <xercesc/dom/DOMImplementationLS.hpp>
#include <xercesc/dom/DOMNodeIterator.hpp>
#include <xercesc/dom/DOMNodeList.hpp>
#include <xercesc/dom/DOMText.hpp>

#include <xercesc/parsers/XercesDOMParser.hpp>
#include <xercesc/util/XMLUni.hpp>
#include <string.h>
#include <fstream>
#include <stdexcept>
#include <typeinfo>
#include <cmath>
#include <cstdlib>

using namespace xercesc;
using namespace std;

string to_string(double x)
{
  ostringstream ss;
  ss << x;
  return ss.str();
}

void setValue(const XMLCh* tagName, DOMElement* parent, double val) // Get the immediate string value of a particular tag name under a particular parent tag
{
		string str = to_string(val);
		const XMLCh* value=XMLString::transcode(str.c_str());
		DOMNodeList* nodeLst = parent->getElementsByTagName(tagName);
		if (nodeLst->item(0) == NULL)
		{
			XERCES_STD_QUALIFIER cerr<<"XML Configuration error : Item \"" << tagName << "\" not found inside the \""
					<< parent->getTagName()<< "\" tag in the configuration file!!"<< XERCES_STD_QUALIFIER endl;
		}
	    DOMElement* NodeElmnt = (DOMElement*) nodeLst->item(0);
	    DOMNodeList* resultNode = NodeElmnt->getChildNodes();
	    return ((DOMNode*) resultNode->item(0))->setNodeValue(value);
}



double nojavathreads,threadspercta,baseline_technology,nooftpc,noofsm,noofsp,numialu,numimul,numfalu,smfrequency,noofwarpschedulers,warpsize;
double icacheblocksize,icachesize,icacheassociativity;
double ccacheblocksize,ccachesize,ccacheassociativity;
double sharedcacheblocksize,sharedcachesize,sharedcacheassociativity;
double dcacheblocksize,dcachesize,dcacheassociativity;
double L2cacheblocksize,L2cachesize,L2cacheassociativity;

void setGPUparameters(DOMDocument* doc)
{
	doc->normalize();
	DOMNodeList* simulationLst = doc->getElementsByTagName(XMLString::transcode("Simulation"));
	DOMElement* simulationElement = (DOMElement*)simulationLst->item(0);
	setValue(XMLString::transcode("MaxNumJavaThreads"),simulationElement, nojavathreads);
	setValue(XMLString::transcode("ThreadsPerCTA"),simulationElement, threadspercta);
	setValue(XMLString::transcode("baseline_technology"),simulationElement, baseline_technology);


	DOMNodeList* systemLst = doc->getElementsByTagName(XMLString::transcode("System"));
	DOMElement* systemElement = (DOMElement*)systemLst->item(0);
	setValue(XMLString::transcode("NoOfTPC"),systemElement, nooftpc);

	DOMNodeList* tpcLst = systemElement->getElementsByTagName(XMLString::transcode("TPC"));
	DOMElement* tpcElement = (DOMElement*)tpcLst->item(0);
	setValue(XMLString::transcode("NoOfSM"),tpcElement, noofsm);

	DOMNodeList* smLst = tpcElement->getElementsByTagName(XMLString::transcode("SM"));
	DOMElement* smElement = (DOMElement*)smLst->item(0);
	setValue(XMLString::transcode("Frequency"),smElement, smfrequency);
	setValue(XMLString::transcode("NoOfWarpSchedulers"),smElement, noofwarpschedulers);
	setValue(XMLString::transcode("NoOfSP"),smElement, noofsp);
	setValue(XMLString::transcode("WarpSize"),smElement, warpsize);

	DOMNodeList* iALULst = smElement->getElementsByTagName(XMLString::transcode("IntALU"));
	DOMElement* iALUElement = (DOMElement*)iALULst->item(0);
	setValue(XMLString::transcode("Num"),iALUElement, numialu);

	DOMNodeList* iMULLst = smElement->getElementsByTagName(XMLString::transcode("IntMul"));
	DOMElement* iMULElement = (DOMElement*)iMULLst->item(0);
	setValue(XMLString::transcode("Num"),iMULElement, numimul);

	DOMNodeList* fALULst = smElement->getElementsByTagName(XMLString::transcode("FloatALU"));
	DOMElement* fALUElement = (DOMElement*)fALULst->item(0);
	setValue(XMLString::transcode("Num"),fALUElement, numfalu);

	DOMNodeList* libLst = doc->getElementsByTagName(XMLString::transcode("Library"));
	DOMElement* libElement = (DOMElement*)libLst->item(0);

	DOMNodeList* icacheLst = libElement->getElementsByTagName(XMLString::transcode("iCache"));
	DOMElement* icacheElement = (DOMElement*)icacheLst->item(0);
	setValue(XMLString::transcode("BlockSize"),icacheElement, icacheblocksize);
	setValue(XMLString::transcode("Associativity"),icacheElement, icacheassociativity);
	setValue(XMLString::transcode("Size"),icacheElement, icachesize);

	DOMNodeList* ccacheLst = libElement->getElementsByTagName(XMLString::transcode("constantCache"));
	DOMElement* ccacheElement = (DOMElement*)ccacheLst->item(0);
	setValue(XMLString::transcode("BlockSize"),ccacheElement, ccacheblocksize);
	setValue(XMLString::transcode("Associativity"),ccacheElement, ccacheassociativity);
	setValue(XMLString::transcode("Size"),ccacheElement, ccachesize);	

	DOMNodeList* sharedcacheLst = libElement->getElementsByTagName(XMLString::transcode("sharedCache"));
	DOMElement* sharedcacheElement = (DOMElement*)sharedcacheLst->item(0);
	setValue(XMLString::transcode("BlockSize"),sharedcacheElement, sharedcacheblocksize);
	setValue(XMLString::transcode("Associativity"),sharedcacheElement, sharedcacheassociativity);
	setValue(XMLString::transcode("Size"),sharedcacheElement, sharedcachesize);

	DOMNodeList* dcacheLst = libElement->getElementsByTagName(XMLString::transcode("dCache"));
	DOMElement* dcacheElement = (DOMElement*)dcacheLst->item(0);
	setValue(XMLString::transcode("BlockSize"),dcacheElement, dcacheblocksize);
	setValue(XMLString::transcode("Associativity"),dcacheElement, dcacheassociativity);
	setValue(XMLString::transcode("Size"),dcacheElement, dcachesize);

	DOMNodeList* L2cacheLst = libElement->getElementsByTagName(XMLString::transcode("L2"));
	DOMElement* L2cacheElement = (DOMElement*)L2cacheLst->item(0);
	setValue(XMLString::transcode("BlockSize"),L2cacheElement, L2cacheblocksize);
	setValue(XMLString::transcode("Associativity"),L2cacheElement, L2cacheassociativity);
	setValue(XMLString::transcode("Size"),L2cacheElement, L2cachesize);

}


int main(int argC, char* argV[]) throw( std::runtime_error )
{
	char *ch=NULL;
	cout<<"Started writing new power values!"<<endl;
	try
   	{
      	XMLPlatformUtils::Initialize();  // Initialize Xerces infrastructure
   	}
   	catch( XMLException& e )
   	{
	    char* message = XMLString::transcode( e.getMessage() );
     	cerr << "XML toolkit initialization error: " << message << endl;
      	XMLString::release( &message );
   		// throw exception here to return ERROR_XERCES_INIT
   	}
	//cout<<"XML initialization done!"<<endl;

	if (argC < 2)
   	{
		//  usage();
		XMLPlatformUtils::Terminate();
		return 1;
   	 }

	
	/*cout << "Enter the No of TPC: "; 
       	cin >> nooftpc;
	cout << "Enter the No of SM per TPC: "; 
       	cin >> noofsm;
	cout << "Enter the No of SP per SM: "; 
       	cin >> noofsp;
	cout << "Enter the No of iALU per SM: "; 
       	cin >> numialu;
	cout << "Enter the No of fALU per SM: "; 
       	cin >> numfalu;
	cout << "Enter the No of iMUL per SM: "; 
       	cin >> numimul;
	cout << "Enter the size of sharedCache: "; 
       	cin >> sharedcachesize;
	cout << "Enter the size of iCache: "; 
       	cin >> icachesize;
	cout << "Enter the size of constantCache: "; 
       	cin >> ccachesize;
	cout << "Enter the number of SMs you want to run: "; 
       	cin >> nojavathreads;*/
	string  str;
	ifstream rf;
	rf.open("expectedconfig.cfg");
	getline(rf,str);
	while(rf){
		char* buf=(char *)str.c_str();
		if(str.find("Max no of java threads")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			nojavathreads = atof(ch);
		}
		else if(str.find("Threads per CTA")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			threadspercta = atof(ch);
		}
		else if(str.find("baseline_technology(nm)")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			baseline_technology = atof(ch);
		}
		else if(str.find("No of tpc")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			nooftpc = atof(ch);
		}
		else if(str.find("No of SM per TPC")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			noofsm = atof(ch);
		}
		else if(str.find("SM frequency(MHz)")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			smfrequency = atof(ch);
		}
		else if(str.find("No of WarpSchedulers per SM")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			noofwarpschedulers = atof(ch);
		}
		else if(str.find("No of SP")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			noofsp = atof(ch);
		}
		else if(str.find("WarpSize")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			warpsize = atof(ch);
		}
		else if(str.find("No of ialu per SM")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			numialu = atof(ch);
		}
		else if(str.find("No of falu per SM")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			numfalu = atof(ch);
		}
		else if(str.find("No of imul per SM")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			numimul = atof(ch);
		}
		else if(str.find("icachesize(bytes)")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			icachesize = atof(ch);
		}
		else if(str.find("icacheblocksize(bytes)")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			icacheblocksize = atof(ch);
		}
		else if(str.find("icacheassociativity")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			icacheassociativity = atof(ch);
		}
		else if(str.find("sharedcachesize(bytes)")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			sharedcachesize = atof(ch);
		}
		else if(str.find("sharedcacheblocksize(bytes)")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			sharedcacheblocksize = atof(ch);
		}
		else if(str.find("sharedcacheassociativity")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			sharedcacheassociativity = atof(ch);
		}
		else if(str.find("ccachesize(bytes)")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			ccachesize = atof(ch);
		}
		else if(str.find("ccacheblocksize(bytes)")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			ccacheblocksize = atof(ch);
		}
		else if(str.find("ccacheassociativity")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			ccacheassociativity = atof(ch);
		}
		else if(str.find("dcachesize(bytes)")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			dcachesize = atof(ch);
		}
		else if(str.find("dcacheblocksize(bytes)")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			dcacheblocksize = atof(ch);
		}
		else if(str.find("dcacheassociativity")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			dcacheassociativity = atof(ch);
		}
		else if(str.find("L2cachesize(bytes)")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			L2cachesize = atof(ch);
		}
		else if(str.find("L2cacheblocksize(bytes)")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			L2cacheblocksize = atof(ch);
		}
		else if(str.find("L2cacheassociativity")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			L2cacheassociativity = atof(ch);
		}

		getline(rf,str);
	}

	rf.close();

	if(nojavathreads > nooftpc*noofsm){
		cout << "ERROR: Number of java threads should be less than or equal to the total number of SMs" << endl;
		return 1;
	}	
	
	string configFile=argV[1];
   	xercesc::XercesDOMParser *ConfigFileParser=new xercesc::XercesDOMParser;
	ConfigFileParser->setValidationScheme( XercesDOMParser::Val_Auto );
   	ConfigFileParser->setDoNamespaces( false );
   	ConfigFileParser->setDoSchema( false );
	try
   	{
      		ConfigFileParser->parse( configFile.c_str() );
	}
	catch( xercesc::XMLException& e )
   	{
	      	char* message = xercesc::XMLString::transcode( e.getMessage() );
	      	ostringstream errBuf;
	    	errBuf << "Error parsing file: " << message << flush;
	      	XMLString::release( &message );
   	}
	DOMDocument* doc = ConfigFileParser->getDocument();
	XMLCh tempStr[3] = {chLatin_L, chLatin_S, chNull};
	DOMImplementation *impl          = DOMImplementationRegistry::getDOMImplementation(tempStr);
    	DOMLSSerializer   *theSerializer = ((DOMImplementationLS*)impl)->createLSSerializer();
    	DOMLSOutput       *theOutputDesc = ((DOMImplementationLS*)impl)->createLSOutput();
	XMLFormatTarget *myFormTarget;
		
	string str1 = configFile;
    	myFormTarget=new LocalFileFormatTarget(str1.c_str());
    	theOutputDesc->setByteStream(myFormTarget);

	cout<<"Setting values in config file!"<<endl;
	setGPUparameters(doc);
	theSerializer->write(doc, theOutputDesc);
		
	theOutputDesc->release();
	theSerializer->release();
	cout<<"Done Writing!"<<endl;

 	delete myFormTarget;
    	delete ConfigFileParser;
    	XMLPlatformUtils::Terminate();
	return 0;
}
