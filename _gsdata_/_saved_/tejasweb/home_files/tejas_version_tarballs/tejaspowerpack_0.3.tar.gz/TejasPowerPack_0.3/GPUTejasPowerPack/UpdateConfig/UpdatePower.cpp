#include <string>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <list>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <xercesc/framework/LocalFileFormatTarget.hpp>

#include <xercesc/dom/DOM.hpp>
#include <xercesc/dom/DOMDocument.hpp>
#include <xercesc/dom/DOMDocumentType.hpp>
#include <xercesc/dom/DOMElement.hpp>
#include <xercesc/dom/DOMImplementation.hpp>
#include <xercesc/dom/DOMImplementationLS.hpp>
#include <xercesc/dom/DOMNodeIterator.hpp>
#include <xercesc/dom/DOMNodeList.hpp>
#include <xercesc/dom/DOMText.hpp>

#include <xercesc/parsers/XercesDOMParser.hpp>
#include <xercesc/util/XMLUni.hpp>
#include <string.h>
#include <fstream>
#include <stdexcept>
#include <typeinfo>
#include <cmath>
#include <cstdlib>


using namespace xercesc;
using namespace std;

const XMLCh* getValue(const XMLCh* tagName, DOMElement* parent) // Get the immediate string value of a particular tag name under a particular parent tag
{
		DOMNodeList* nodeLst = parent->getElementsByTagName(tagName);
		if (nodeLst->item(0) == NULL)
		{
			return NULL;
			//XERCES_STD_QUALIFIER cerr<<"XML Configuration error : Item \"" << tagName << "\" not found inside the \""
			//<< parent->getTagName()<< "\" tag in the configuration file!!"<< XERCES_STD_QUALIFIER endl;
		}
	    DOMElement* NodeElmnt = (DOMElement*) nodeLst->item(0);
	    DOMNodeList* resultNode = NodeElmnt->getChildNodes();
	    return ((DOMNode*) resultNode->item(0))->getNodeValue();
}

string to_string(double x)
{
  ostringstream ss;
  ss << x;
  return ss.str();
}

void setValue(const XMLCh* tagName, DOMElement* parent, double val) // Get the immediate string value of a particular tag name under a particular parent tag
{
		string str = to_string(val);
		const XMLCh* value=XMLString::transcode(str.c_str());
		DOMNodeList* nodeLst = parent->getElementsByTagName(tagName);
		if (nodeLst->item(0) == NULL)
		{
			XERCES_STD_QUALIFIER cerr<<"XML Configuration error : Item \"" << tagName << "\" not found inside the \""
					<< parent->getTagName()<< "\" tag in the configuration file!!"<< XERCES_STD_QUALIFIER endl;
		}
	    DOMElement* NodeElmnt = (DOMElement*) nodeLst->item(0);
	    DOMNodeList* resultNode = NodeElmnt->getChildNodes();
	    return ((DOMNode*) resultNode->item(0))->setNodeValue(value);
}


long ialu_accesses;
long fpu_accesses;
long mul_accesses;

long icache_accesses;

long dcache_readaccesses;
long dcache_writeaccesses;
long ccache_readaccesses;
long ccache_writeaccesses;
long sharedcache_readaccesses;
long sharedcache_writeaccesses;
long l2_readaccesses;
long l2_writeaccesses;

char const* temp;

void getAccessValues(DOMDocument* doc)
{
	doc->normalize();
	DOMNodeList* inputLst = doc->getElementsByTagName(XMLString::transcode("component"));
	DOMElement* rootElement = (DOMElement*)inputLst->item(0);
	DOMNodeList* systemLst = rootElement->getElementsByTagName(XMLString::transcode("component"));
	DOMElement* systemElement = (DOMElement*)systemLst->item(0);

	DOMNodeList* componentLst = systemElement->getElementsByTagName(XMLString::transcode("component"));
	DOMElement* component0Element = (DOMElement*)componentLst->item(0);
	
	DOMNodeList* statLst = component0Element->getElementsByTagName(XMLString::transcode("stat"));
	
	DOMElement* statElement = (DOMElement*)statLst->item(32);
	if( statElement){
		temp = "ialu_accesses";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			ialu_accesses = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));
	}
	statElement = (DOMElement*)statLst->item(34);
	if( statElement){
		temp = "mul_accesses";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			mul_accesses = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));
	}
	statElement = (DOMElement*)statLst->item(33);
	if( statElement){
		temp = "fpu_accesses";
		if(strcmp(XMLString::transcode(statElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			fpu_accesses = (long) XMLString::parseInt(statElement->getAttribute(XMLString::transcode("value")));
	}
	
	
	DOMNodeList* subcomponent0Lst = component0Element->getElementsByTagName(XMLString::transcode("component"));

	DOMElement* icacheElement = (DOMElement*)subcomponent0Lst->item(2);
	DOMNodeList* staticacheLst = icacheElement->getElementsByTagName(XMLString::transcode("stat"));
	DOMElement* staticacheElement = (DOMElement*)staticacheLst->item(0);
	if(staticacheElement){
		temp = "read_accesses";
		if(strcmp(XMLString::transcode(staticacheElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			icache_accesses = (long) XMLString::parseInt(staticacheElement->getAttribute(XMLString::transcode("value")));
	}
	 

	DOMElement* ccacheElement = (DOMElement*)subcomponent0Lst->item(4);
	DOMNodeList* statccacheLst = ccacheElement->getElementsByTagName(XMLString::transcode("stat"));
	DOMElement* statccacheElement = (DOMElement*)statccacheLst->item(0);
	if(statccacheElement){
		temp = "read_accesses";
		if(strcmp(XMLString::transcode(statccacheElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			ccache_readaccesses = (long) XMLString::parseInt(statccacheElement->getAttribute(XMLString::transcode("value")));
		temp = "write_accesses";
		if(strcmp(XMLString::transcode(statccacheElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			ccache_writeaccesses = (long) XMLString::parseInt(statccacheElement->getAttribute(XMLString::transcode("value")));
	
	}
	
	DOMElement* sharedcacheElement = (DOMElement*)subcomponent0Lst->item(6);
	DOMNodeList* statsharedcacheLst = sharedcacheElement->getElementsByTagName(XMLString::transcode("stat"));
	DOMElement* statsharedcacheElement = (DOMElement*)statsharedcacheLst->item(0);
	if(statsharedcacheElement){
		temp = "read_accesses";
		if(strcmp(XMLString::transcode(statsharedcacheElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			sharedcache_readaccesses = (long) XMLString::parseInt(statsharedcacheElement->getAttribute(XMLString::transcode("value")));
		temp = "write_accesses";
		if(strcmp(XMLString::transcode(statccacheElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			sharedcache_writeaccesses = (long) XMLString::parseInt(statsharedcacheElement->getAttribute(XMLString::transcode("value")));
	
	}
	
	
	DOMElement* dcacheElement = (DOMElement*)subcomponent0Lst->item(7);
	DOMNodeList* statdcacheLst = dcacheElement->getElementsByTagName(XMLString::transcode("stat"));
	DOMElement* statdcacheElement = (DOMElement*)statdcacheLst->item(0);
	if(statdcacheElement){
		temp = "read_accesses";
		if(strcmp(XMLString::transcode(statdcacheElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			dcache_readaccesses = (long) XMLString::parseInt(statdcacheElement->getAttribute(XMLString::transcode("value")));
		temp = "write_accesses";
		if(strcmp(XMLString::transcode(statdcacheElement->getAttribute(XMLString::transcode("name"))),temp)==0)
			dcache_writeaccesses = (long) XMLString::parseInt(statdcacheElement->getAttribute(XMLString::transcode("value")));
	}

	

	DOMNodeList* l2Lst = systemElement->getElementsByTagName(XMLString::transcode("component"));
	DOMElement* l2Element = (DOMElement*)l2Lst->item(12);
	DOMNodeList* statl2Lst = l2Element->getElementsByTagName(XMLString::transcode("stat"));
	DOMElement* statl2Element = (DOMElement*)statl2Lst->item(0);
	if(statl2Element){
		temp = "read_accesses";
		if(strcmp(XMLString::transcode(statl2Element->getAttribute(XMLString::transcode("name"))),temp)==0)
			l2_readaccesses = (long) XMLString::parseInt(statl2Element->getAttribute(XMLString::transcode("value")));
		temp = "write_accesses";
		if(strcmp(XMLString::transcode(statl2Element->getAttribute(XMLString::transcode("name"))),temp)==0)
			l2_writeaccesses = (long) XMLString::parseInt(statl2Element->getAttribute(XMLString::transcode("value")));
	}
	
	
}
void setConfigValues(DOMDocument* doc)
{
	string  str;
	ifstream rf;
	int core_frequency;
	double load_dynamicenergy,store_dynamicenergy,load_leakagepower,store_leakagepower,int_IW_dynamicenergy,flt_IW_dynamicenergy,int_IW_leakagepower,flt_IW_leakagepower;
	double link_dynamicenergy,link_leakagepower,router_dynamicenergy,router_leakagepower;
	double factor =1E+9;
	double factor1 = 1E+3;
	double total_power=0.0,b_pred=0.0,dummy;
	char *ch=NULL;
	

	doc->normalize();
	
	DOMNodeList* systemLst = doc->getElementsByTagName(XMLString::transcode("System"));
	DOMElement* systemElement = (DOMElement*)systemLst->item(0);
	DOMNodeList* libLst = doc->getElementsByTagName(XMLString::transcode("Library"));
	DOMElement* libElement = (DOMElement*)libLst->item(0);
	
	DOMNodeList* tpcLst = systemElement->getElementsByTagName(XMLString::transcode("TPC"));
	DOMElement* tpcElement = (DOMElement*)tpcLst->item(0);
	DOMNodeList* SMLst = tpcElement->getElementsByTagName(XMLString::transcode("SM"));
	DOMElement* SMElement = (DOMElement*)SMLst->item(0);
	
	core_frequency = XMLString::parseInt(getValue(XMLString::transcode("Frequency"),SMElement));
	DOMNodeList* IntALULst = SMElement->getElementsByTagName(XMLString::transcode("IntALU"));
	DOMElement* IntALUElement = (DOMElement*)IntALULst->item(0);
	DOMNodeList* IntMulLst = SMElement->getElementsByTagName(XMLString::transcode("IntMul"));
	DOMElement* IntMulElement = (DOMElement*)IntMulLst->item(0);
	DOMNodeList* FltALULst = SMElement->getElementsByTagName(XMLString::transcode("FloatALU"));
	DOMElement* FltALUElement = (DOMElement*)FltALULst->item(0);
	
	
	DOMNodeList* ICacheLst = libElement->getElementsByTagName(XMLString::transcode("iCache"));
	DOMElement* ICacheElement = (DOMElement*)ICacheLst->item(0);
	DOMNodeList* constCacheLst = libElement->getElementsByTagName(XMLString::transcode("constantCache"));
	DOMElement* constCacheElement = (DOMElement*)constCacheLst->item(0);
	DOMNodeList* sharedCacheLst = libElement->getElementsByTagName(XMLString::transcode("sharedCache"));
	DOMElement* sharedCacheElement = (DOMElement*)sharedCacheLst->item(0);
	DOMNodeList* L1CacheLst = libElement->getElementsByTagName(XMLString::transcode("dCache"));
	DOMElement* L1CacheElement = (DOMElement*)L1CacheLst->item(0);
	DOMNodeList* L2CacheLst = libElement->getElementsByTagName(XMLString::transcode("L2"));
	DOMElement* L2CacheElement = (DOMElement*)L2CacheLst->item(0);
	
	rf.open("output_power.txt");
	getline(rf,str);
	
	while(rf){
		char* buf=(char *)str.c_str();
		if(str.find("ICache Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("ReadDynamicEnergy"),ICacheElement,(atof(ch)*factor)/icache_accesses );
			setValue(XMLString::transcode("WriteDynamicEnergy"),ICacheElement,(atof(ch)*factor)/icache_accesses  );
			total_power +=atof(ch)*factor;
		}
		
		else if(str.find("ICache Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("LeakageEnergy"),ICacheElement,(atof(ch)*factor1)/core_frequency);
			
		}
		
		if(str.find("SharedMemory Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("ReadDynamicEnergy"),sharedCacheElement,(atof(ch)*factor)/(sharedcache_readaccesses+sharedcache_writeaccesses) );
			setValue(XMLString::transcode("WriteDynamicEnergy"),sharedCacheElement,(atof(ch)*factor)/(sharedcache_readaccesses+sharedcache_writeaccesses)  );
			total_power +=atof(ch)*factor;
		}
		
		else if(str.find("SharedMemory Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("LeakageEnergy"),sharedCacheElement,(atof(ch)*factor1)/core_frequency);
			
		}
		
		else if(str.find("Dcache Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("ReadDynamicEnergy"),L1CacheElement,(atof(ch)*factor)/(dcache_readaccesses+dcache_writeaccesses)  );
			setValue(XMLString::transcode("WriteDynamicEnergy"),L1CacheElement,(atof(ch)*factor)/(dcache_readaccesses+dcache_writeaccesses)  );
			total_power +=atof(ch)*factor;
		}
		else if(str.find("Dcache Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("LeakageEnergy"),L1CacheElement,(atof(ch)*factor1)/core_frequency );
		}
		
		else if(str.find("Constantcache Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("ReadDynamicEnergy"),constCacheElement,(atof(ch)*factor)/(ccache_readaccesses+ccache_writeaccesses)  );
			setValue(XMLString::transcode("WriteDynamicEnergy"),constCacheElement,(atof(ch)*factor)/(ccache_readaccesses+ccache_writeaccesses)  );
			total_power +=atof(ch)*factor;
		}
		else if(str.find("Constantcache Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("LeakageEnergy"),constCacheElement,(atof(ch)*factor1)/core_frequency );
		}
		
		else if(str.find("Integer ALU Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("DynamicEnergy"),IntALUElement,(atof(ch)*factor)/ialu_accesses );
			total_power +=atof(ch)*factor;
		}
		else if(str.find("Integer ALU Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("LeakageEnergy"),IntALUElement,(atof(ch)*factor1)/core_frequency  );
		}
		else if(str.find("FPU Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("DynamicEnergy"),FltALUElement,(atof(ch)*factor)/fpu_accesses );
		}
		else if(str.find("FPU Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("LeakageEnergy"),FltALUElement,(atof(ch)*factor1)/core_frequency  );
			
		}
		else if(str.find("Integer MUL Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("DynamicEnergy"),IntMulElement,(atof(ch)*factor)/mul_accesses );
			
		}
		else if(str.find("Integer MUL Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("LeakageEnergy"),IntMulElement,(atof(ch)*factor1)/core_frequency  );
		}
		
		else if(str.find("L2 Cache Dynamic Energy")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("ReadDynamicEnergy"),L2CacheElement,(atof(ch)*factor)/(l2_readaccesses+l2_writeaccesses) );
			setValue(XMLString::transcode("WriteDynamicEnergy"),L2CacheElement,(atof(ch)*factor)/(l2_readaccesses+l2_writeaccesses) );
			total_power +=atof(ch)*factor;
		}
		else if(str.find("L2 Cache Leakage Power")==0){
			ch = strtok(buf,":");
			ch = strtok(NULL,":");
			setValue(XMLString::transcode("LeakageEnergy"),L2CacheElement,(atof(ch)*factor1)/core_frequency  );

		}
		

		
		getline(rf,str);
	}

	rf.close();
}

int main(int argC, char* argV[]) throw( std::runtime_error )
{
	cout<<"Started writing new power values!"<<endl;
	try
   	{
      	XMLPlatformUtils::Initialize();  // Initialize Xerces infrastructure
   	}
   	catch( XMLException& e )
   	{
	    char* message = XMLString::transcode( e.getMessage() );
     	cerr << "XML toolkit initialization error: " << message << endl;
      	XMLString::release( &message );
   		// throw exception here to return ERROR_XERCES_INIT
   	}
	//cout<<"XML initialization done!"<<endl;

	if (argC < 2)
   	{
	//  usage();
        XMLPlatformUtils::Terminate();
        return 1;
    }
	string configFile=argV[1];
   	xercesc::XercesDOMParser *ConfigFileParser=new xercesc::XercesDOMParser;
   	   	xercesc::XercesDOMParser *InputFileParser=new xercesc::XercesDOMParser;

	//cout<<"Config file found!"<<endl;

   // Configure DOM parser.
   	ConfigFileParser->setValidationScheme( XercesDOMParser::Val_Auto );
   	ConfigFileParser->setDoNamespaces( false );
   	ConfigFileParser->setDoSchema( false );
   InputFileParser->setValidationScheme( XercesDOMParser::Val_Auto );
   	InputFileParser->setDoNamespaces( false );
   	InputFileParser->setDoSchema( false );
    //ConfigFileParser->setLoadExternalDTD( false );
	//cout<<"DOM parser configured!"<<endl;

   	try
   	{
      	ConfigFileParser->parse( configFile.c_str() );
		InputFileParser->parse( "input.xml");
   	}
   	catch( xercesc::XMLException& e )
   	{
      	char* message = xercesc::XMLString::transcode( e.getMessage() );
      	ostringstream errBuf;
    	errBuf << "Error parsing file: " << message << flush;
      	XMLString::release( &message );
   	}

   	// no need to free this pointer - owned by the parent parser object
   	DOMDocument* doc = ConfigFileParser->getDocument();
	 DOMDocument* input = InputFileParser->getDocument();
	//cout<<"DOMDocument created!"<<endl;
      
	XMLCh tempStr[3] = {chLatin_L, chLatin_S, chNull};
	DOMImplementation *impl          = DOMImplementationRegistry::getDOMImplementation(tempStr);
    DOMLSSerializer   *theSerializer = ((DOMImplementationLS*)impl)->createLSSerializer();
    DOMLSOutput       *theOutputDesc = ((DOMImplementationLS*)impl)->createLSOutput();
	XMLFormatTarget *myFormTarget;
		
	string str = configFile;
    myFormTarget=new LocalFileFormatTarget(str.c_str());
    theOutputDesc->setByteStream(myFormTarget);
    cout<<"Setting new power values!"<<endl;
	getAccessValues(input);
//	cout<<"access value error!"<<endl;
    setConfigValues(doc);
    cout<<"New power values set!"<<endl;
	theSerializer->write(doc, theOutputDesc);
		
	theOutputDesc->release();
	theSerializer->release();
	cout<<"Done Writing!"<<endl;
		
    delete myFormTarget;
    delete ConfigFileParser;
    XMLPlatformUtils::Terminate();
	return 0;
}
