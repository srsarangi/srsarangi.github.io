package config;

public enum CacheDataType {
	Instruction,
	Data,
	Unified
}
