package dram;

public class BusPacketQueue1D {

}
