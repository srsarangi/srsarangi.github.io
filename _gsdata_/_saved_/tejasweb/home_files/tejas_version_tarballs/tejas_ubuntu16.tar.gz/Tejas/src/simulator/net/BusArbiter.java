package net;

public class BusArbiter {
	
	private boolean isSpace;
	public BusArbiter() {
		// TODO Auto-generated constructor stub
		isSpace = true;
	}
	
	
	public boolean isSpaceInArbiter()
	{
		return isSpace;
	}
}
