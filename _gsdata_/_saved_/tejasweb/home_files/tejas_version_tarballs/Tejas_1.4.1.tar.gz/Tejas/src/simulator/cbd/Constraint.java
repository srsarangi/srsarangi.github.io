
package cbd;

import java.util.Vector;

public class Constraint {
	public String class_name;
	public String method_name;
	public Vector<Object> arguments;
}
