typedef union {
	char op; 
	int num;
} opnum;

#define DTYPE opnum
